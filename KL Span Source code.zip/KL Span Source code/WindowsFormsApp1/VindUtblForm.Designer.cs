﻿using System;

namespace KLAppGlobal
{
    partial class VindUtblForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(VindUtblForm));
            this.picVindUtbl = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picVindUtbl)).BeginInit();
            this.SuspendLayout();
            // 
            // picVindUtbl
            // 
            this.picVindUtbl.Image = ((System.Drawing.Image)(resources.GetObject("picVindUtbl.Image")));
            this.picVindUtbl.ImageLocation = "";
            this.picVindUtbl.Location = new System.Drawing.Point(0, -1);
            this.picVindUtbl.Name = "picVindUtbl";
            this.picVindUtbl.Size = new System.Drawing.Size(464, 270);
            this.picVindUtbl.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picVindUtbl.TabIndex = 0;
            this.picVindUtbl.TabStop = false;
            // 
            // VindUtblForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(464, 270);
            this.Controls.Add(this.picVindUtbl);
            this.Name = "VindUtblForm";
            this.Text = "FormVindUtbl";
            ((System.ComponentModel.ISupportInitialize)(this.picVindUtbl)).EndInit();
            this.ResumeLayout(false);

        }
        public void Change_E_R(int E_type)
        {
            //this.picVindUtbl.Image = ((System.Drawing.Image)(this.resources.GetObject("picVindUtbl.Image")));
            if (E_type == 1) { this.picVindUtbl.ImageLocation = @".\Images\E2.png"; }
            else if (E_type == 2) { this.picVindUtbl.ImageLocation = @".\Images\E3.png"; }
            else { this.picVindUtbl.ImageLocation = @".\Images\E1.png"; }
        }

        #endregion

        private System.Windows.Forms.PictureBox picVindUtbl;
    }
}