﻿namespace KLAppGlobal
{
    partial class FrontForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabDataEntry = new System.Windows.Forms.TabPage();
            this.btnLagreledpartdata = new System.Windows.Forms.Button();
            this.btnLagreTrasedata = new System.Windows.Forms.Button();
            this.btnOppdaterTraseLeng = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.cmbE_R = new System.Windows.Forms.ComboBox();
            this.txtVind_kast = new System.Windows.Forms.TextBox();
            this.numUpDnVbo = new System.Windows.Forms.NumericUpDown();
            this.lbl_Vb_kast_bkast = new System.Windows.Forms.Label();
            this.lblVbkast_V = new System.Windows.Forms.Label();
            this.btnVindKart = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.rdbtnImport = new System.Windows.Forms.RadioButton();
            this.rdbtnSkrive = new System.Windows.Forms.RadioButton();
            this.btnHentData = new System.Windows.Forms.Button();
            this.pnlSKriv = new System.Windows.Forms.Panel();
            this.ckBxkm = new System.Windows.Forms.CheckBox();
            this.antall_ledd = new System.Windows.Forms.NumericUpDown();
            this.label16 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.numUpDnR_3_5spenn = new System.Windows.Forms.NumericUpDown();
            this.lbl3_5_spenn = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.numUpDnseksjPos = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.lblTraseLedd = new System.Windows.Forms.Label();
            this.numUpDnOffset = new System.Windows.Forms.NumericUpDown();
            this.lbl_offset = new System.Windows.Forms.Label();
            this.cmbLo = new System.Windows.Forms.ComboBox();
            this.numUpDnFmin = new System.Windows.Forms.NumericUpDown();
            this.btnVindUtb = new System.Windows.Forms.Button();
            this.lbl_m_s = new System.Windows.Forms.Label();
            this.lbl_Vbo_bo = new System.Windows.Forms.Label();
            this.lbl_Vw_V = new System.Windows.Forms.Label();
            this.lbl_N = new System.Windows.Forms.Label();
            this.lbl_Fw_w = new System.Windows.Forms.Label();
            this.lbl_Fw_F = new System.Windows.Forms.Label();
            this.txtVindKraft = new System.Windows.Forms.TextBox();
            this.txtHcw = new System.Windows.Forms.TextBox();
            this.txtHca = new System.Windows.Forms.TextBox();
            this.lbl_cm1 = new System.Windows.Forms.Label();
            this.lbl_N2 = new System.Windows.Forms.Label();
            this.lbl_kN2 = new System.Windows.Forms.Label();
            this.lbl_kN = new System.Windows.Forms.Label();
            this.lbl_m2 = new System.Windows.Forms.Label();
            this.lblTillatVinUt = new System.Windows.Forms.Label();
            this.lbl_Fmin_min = new System.Windows.Forms.Label();
            this.lbl_Fmin_F = new System.Windows.Forms.Label();
            this.lbl_HCW_CW = new System.Windows.Forms.Label();
            this.lbl_HCA_CA = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.lbl_HCW_H = new System.Windows.Forms.Label();
            this.lbl_HCA_H = new System.Windows.Forms.Label();
            this.lbl_Lo_o = new System.Windows.Forms.Label();
            this.cmbSystemType = new System.Windows.Forms.ComboBox();
            this.lblSystemType = new System.Windows.Forms.Label();
            this.btnBeregn = new System.Windows.Forms.Button();
            this.pnlLeddParams = new System.Windows.Forms.Panel();
            this.LeddRetn10 = new System.Windows.Forms.ComboBox();
            this.LeddRetn9 = new System.Windows.Forms.ComboBox();
            this.LeddRetn8 = new System.Windows.Forms.ComboBox();
            this.LeddRetn7 = new System.Windows.Forms.ComboBox();
            this.LeddRetn6 = new System.Windows.Forms.ComboBox();
            this.LeddRetn5 = new System.Windows.Forms.ComboBox();
            this.LeddRetn4 = new System.Windows.Forms.ComboBox();
            this.LeddRetn3 = new System.Windows.Forms.ComboBox();
            this.LeddRetn2 = new System.Windows.Forms.ComboBox();
            this.comboBox9 = new System.Windows.Forms.ComboBox();
            this.LeddRetn1 = new System.Windows.Forms.ComboBox();
            this.TypeKurve10 = new System.Windows.Forms.ComboBox();
            this.LeddRad10 = new System.Windows.Forms.NumericUpDown();
            this.TypeKurve9 = new System.Windows.Forms.ComboBox();
            this.LeddRad9 = new System.Windows.Forms.NumericUpDown();
            this.TypeKurve8 = new System.Windows.Forms.ComboBox();
            this.LeddRad8 = new System.Windows.Forms.NumericUpDown();
            this.TypeKurve7 = new System.Windows.Forms.ComboBox();
            this.LeddRad7 = new System.Windows.Forms.NumericUpDown();
            this.TypeKurve6 = new System.Windows.Forms.ComboBox();
            this.LeddRad6 = new System.Windows.Forms.NumericUpDown();
            this.TypeKurve5 = new System.Windows.Forms.ComboBox();
            this.LeddRad5 = new System.Windows.Forms.NumericUpDown();
            this.TypeKurve4 = new System.Windows.Forms.ComboBox();
            this.LeddRad4 = new System.Windows.Forms.NumericUpDown();
            this.TypeKurve3 = new System.Windows.Forms.ComboBox();
            this.LeddRad3 = new System.Windows.Forms.NumericUpDown();
            this.TypeKurve2 = new System.Windows.Forms.ComboBox();
            this.LeddRad2 = new System.Windows.Forms.NumericUpDown();
            this.LeddLeng10 = new System.Windows.Forms.NumericUpDown();
            this.LeddLeng9 = new System.Windows.Forms.NumericUpDown();
            this.LeddLeng8 = new System.Windows.Forms.NumericUpDown();
            this.LeddLeng7 = new System.Windows.Forms.NumericUpDown();
            this.LeddLeng6 = new System.Windows.Forms.NumericUpDown();
            this.LeddLeng5 = new System.Windows.Forms.NumericUpDown();
            this.LeddLeng4 = new System.Windows.Forms.NumericUpDown();
            this.LeddLeng3 = new System.Windows.Forms.NumericUpDown();
            this.LeddLeng2 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.LeddLeng1 = new System.Windows.Forms.NumericUpDown();
            this.LeddEnd10 = new System.Windows.Forms.TextBox();
            this.LeddStart10 = new System.Windows.Forms.TextBox();
            this.lblLedd10 = new System.Windows.Forms.Label();
            this.LeddEnd9 = new System.Windows.Forms.TextBox();
            this.LeddStart9 = new System.Windows.Forms.TextBox();
            this.lblLedd9 = new System.Windows.Forms.Label();
            this.LeddEnd8 = new System.Windows.Forms.TextBox();
            this.LeddStart8 = new System.Windows.Forms.TextBox();
            this.lblLedd8 = new System.Windows.Forms.Label();
            this.LeddEnd7 = new System.Windows.Forms.TextBox();
            this.LeddStart7 = new System.Windows.Forms.TextBox();
            this.lblLedd7 = new System.Windows.Forms.Label();
            this.LeddEnd6 = new System.Windows.Forms.TextBox();
            this.LeddStart6 = new System.Windows.Forms.TextBox();
            this.lblLedd6 = new System.Windows.Forms.Label();
            this.LeddEnd5 = new System.Windows.Forms.TextBox();
            this.LeddStart5 = new System.Windows.Forms.TextBox();
            this.lblLedd5 = new System.Windows.Forms.Label();
            this.LeddEnd4 = new System.Windows.Forms.TextBox();
            this.LeddStart4 = new System.Windows.Forms.TextBox();
            this.lblLedd4 = new System.Windows.Forms.Label();
            this.LeddEnd3 = new System.Windows.Forms.TextBox();
            this.LeddStart3 = new System.Windows.Forms.TextBox();
            this.lblLedd3 = new System.Windows.Forms.Label();
            this.LeddEnd2 = new System.Windows.Forms.TextBox();
            this.LeddStart2 = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.lblLedd2 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.TypeKurve1 = new System.Windows.Forms.ComboBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.LeddEnd1 = new System.Windows.Forms.TextBox();
            this.LeddStart1 = new System.Windows.Forms.TextBox();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.lblLedd1 = new System.Windows.Forms.Label();
            this.LeddRad1 = new System.Windows.Forms.NumericUpDown();
            this.PlotSelector = new System.Windows.Forms.Panel();
            this.btnLagrePlot = new System.Windows.Forms.Button();
            this.nrUpDnSpennNr = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.rdBtnVUtbSpan = new System.Windows.Forms.RadioButton();
            this.rdBtnVUtbLedPart = new System.Windows.Forms.RadioButton();
            this.rdBtnTrase = new System.Windows.Forms.RadioButton();
            this.nrUpDnLedpartNr = new System.Windows.Forms.NumericUpDown();
            this.lblLedpartNr = new System.Windows.Forms.Label();
            this.btnTrasePlot = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnLeddPart5 = new System.Windows.Forms.Button();
            this.btnLeddPart4 = new System.Windows.Forms.Button();
            this.btnLeddPart3 = new System.Windows.Forms.Button();
            this.btnLeddPart2 = new System.Windows.Forms.Button();
            this.btnLeddPart1 = new System.Windows.Forms.Button();
            this.LedPart5LøpRet = new System.Windows.Forms.ComboBox();
            this.LedPart4LøpRet = new System.Windows.Forms.ComboBox();
            this.LedPart3LøpRet = new System.Windows.Forms.ComboBox();
            this.LedPart2LøpRet = new System.Windows.Forms.ComboBox();
            this.LedPart1LøpRet = new System.Windows.Forms.ComboBox();
            this.LedPart5MaksLeng = new System.Windows.Forms.NumericUpDown();
            this.LedPart4MaksLeng = new System.Windows.Forms.NumericUpDown();
            this.LedPart3MaksLeng = new System.Windows.Forms.NumericUpDown();
            this.LedPart2MaksLeng = new System.Windows.Forms.NumericUpDown();
            this.LedPart1MaksLeng = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.LedPart5MaksTall = new System.Windows.Forms.NumericUpDown();
            this.LedPart4MaksTall = new System.Windows.Forms.NumericUpDown();
            this.LedPart3MaksTall = new System.Windows.Forms.NumericUpDown();
            this.LedPart2MaksTall = new System.Windows.Forms.NumericUpDown();
            this.LedPart1MaksTall = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.LedPart5TallSpn = new System.Windows.Forms.TextBox();
            this.LedPart4TallSpn = new System.Windows.Forms.TextBox();
            this.LedPart3TallSpn = new System.Windows.Forms.TextBox();
            this.LedPart2TallSpn = new System.Windows.Forms.TextBox();
            this.LedPart1TallSpn = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.LedPart5_leng = new System.Windows.Forms.TextBox();
            this.LedPart4_leng = new System.Windows.Forms.TextBox();
            this.LedPart3_leng = new System.Windows.Forms.TextBox();
            this.LedPart2_leng = new System.Windows.Forms.TextBox();
            this.LedPart1_leng = new System.Windows.Forms.TextBox();
            this.LedPart5_end = new System.Windows.Forms.TextBox();
            this.LedPart5_start = new System.Windows.Forms.TextBox();
            this.LedPart4_end = new System.Windows.Forms.TextBox();
            this.LedPart4_start = new System.Windows.Forms.TextBox();
            this.LedPart3_end = new System.Windows.Forms.TextBox();
            this.LedPart3_start = new System.Windows.Forms.TextBox();
            this.LedPart2_end = new System.Windows.Forms.TextBox();
            this.LedPart2_start = new System.Windows.Forms.TextBox();
            this.LedPart1_end = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.LedPart1_start = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.lblKurveLengde = new System.Windows.Forms.Label();
            this.lblTraseSammenstilling = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.numUpDnStrekHast = new System.Windows.Forms.NumericUpDown();
            this.btnLagreProsjektInfo = new System.Windows.Forms.Button();
            this.btnHentProsjektInfo = new System.Windows.Forms.Button();
            this.lblEksportmappe = new System.Windows.Forms.Label();
            this.btnExportmappe = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.txtSluttpkt = new System.Windows.Forms.TextBox();
            this.lblToMast = new System.Windows.Forms.Label();
            this.lblFromMast = new System.Windows.Forms.Label();
            this.txtUtfortdato = new System.Windows.Forms.TextBox();
            this.txtUtfortav = new System.Windows.Forms.TextBox();
            this.txtStartpkt = new System.Windows.Forms.TextBox();
            this.txtProjectNumber = new System.Windows.Forms.TextBox();
            this.txtProjectName = new System.Windows.Forms.TextBox();
            this.lblDateOfDesign = new System.Windows.Forms.Label();
            this.lblNameOfDesigner = new System.Windows.Forms.Label();
            this.lblSpanLocation = new System.Windows.Forms.Label();
            this.lblProjectNo = new System.Windows.Forms.Label();
            this.lblProjectName = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tabFrontForm = new System.Windows.Forms.TabControl();
            this.OpenTraseFile = new System.Windows.Forms.OpenFileDialog();
            this.OpenProsjektFile = new System.Windows.Forms.OpenFileDialog();
            this.SaveResultsTo = new System.Windows.Forms.FolderBrowserDialog();
            this.tabDataEntry.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDnVbo)).BeginInit();
            this.panel3.SuspendLayout();
            this.pnlSKriv.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.antall_ledd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDnR_3_5spenn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDnseksjPos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDnOffset)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDnFmin)).BeginInit();
            this.pnlLeddParams.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LeddRad10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeddRad9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeddRad8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeddRad7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeddRad6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeddRad5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeddRad4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeddRad3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeddRad2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeddLeng10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeddLeng9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeddLeng8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeddLeng7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeddLeng6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeddLeng5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeddLeng4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeddLeng3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeddLeng2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeddLeng1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeddRad1)).BeginInit();
            this.PlotSelector.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nrUpDnSpennNr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nrUpDnLedpartNr)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LedPart5MaksLeng)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LedPart4MaksLeng)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LedPart3MaksLeng)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LedPart2MaksLeng)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LedPart1MaksLeng)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LedPart5MaksTall)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LedPart4MaksTall)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LedPart3MaksTall)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LedPart2MaksTall)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LedPart1MaksTall)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDnStrekHast)).BeginInit();
            this.tabFrontForm.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabDataEntry
            // 
            this.tabDataEntry.AutoScroll = true;
            this.tabDataEntry.BackColor = System.Drawing.Color.Transparent;
            this.tabDataEntry.Controls.Add(this.btnLagreledpartdata);
            this.tabDataEntry.Controls.Add(this.btnLagreTrasedata);
            this.tabDataEntry.Controls.Add(this.btnOppdaterTraseLeng);
            this.tabDataEntry.Controls.Add(this.label14);
            this.tabDataEntry.Controls.Add(this.cmbE_R);
            this.tabDataEntry.Controls.Add(this.txtVind_kast);
            this.tabDataEntry.Controls.Add(this.numUpDnVbo);
            this.tabDataEntry.Controls.Add(this.lbl_Vb_kast_bkast);
            this.tabDataEntry.Controls.Add(this.lblVbkast_V);
            this.tabDataEntry.Controls.Add(this.btnVindKart);
            this.tabDataEntry.Controls.Add(this.panel3);
            this.tabDataEntry.Controls.Add(this.btnHentData);
            this.tabDataEntry.Controls.Add(this.pnlSKriv);
            this.tabDataEntry.Controls.Add(this.label8);
            this.tabDataEntry.Controls.Add(this.numUpDnR_3_5spenn);
            this.tabDataEntry.Controls.Add(this.lbl3_5_spenn);
            this.tabDataEntry.Controls.Add(this.label53);
            this.tabDataEntry.Controls.Add(this.numUpDnseksjPos);
            this.tabDataEntry.Controls.Add(this.label6);
            this.tabDataEntry.Controls.Add(this.lblTraseLedd);
            this.tabDataEntry.Controls.Add(this.numUpDnOffset);
            this.tabDataEntry.Controls.Add(this.lbl_offset);
            this.tabDataEntry.Controls.Add(this.cmbLo);
            this.tabDataEntry.Controls.Add(this.numUpDnFmin);
            this.tabDataEntry.Controls.Add(this.btnVindUtb);
            this.tabDataEntry.Controls.Add(this.lbl_m_s);
            this.tabDataEntry.Controls.Add(this.lbl_Vbo_bo);
            this.tabDataEntry.Controls.Add(this.lbl_Vw_V);
            this.tabDataEntry.Controls.Add(this.lbl_N);
            this.tabDataEntry.Controls.Add(this.lbl_Fw_w);
            this.tabDataEntry.Controls.Add(this.lbl_Fw_F);
            this.tabDataEntry.Controls.Add(this.txtVindKraft);
            this.tabDataEntry.Controls.Add(this.txtHcw);
            this.tabDataEntry.Controls.Add(this.txtHca);
            this.tabDataEntry.Controls.Add(this.lbl_cm1);
            this.tabDataEntry.Controls.Add(this.lbl_N2);
            this.tabDataEntry.Controls.Add(this.lbl_kN2);
            this.tabDataEntry.Controls.Add(this.lbl_kN);
            this.tabDataEntry.Controls.Add(this.lbl_m2);
            this.tabDataEntry.Controls.Add(this.lblTillatVinUt);
            this.tabDataEntry.Controls.Add(this.lbl_Fmin_min);
            this.tabDataEntry.Controls.Add(this.lbl_Fmin_F);
            this.tabDataEntry.Controls.Add(this.lbl_HCW_CW);
            this.tabDataEntry.Controls.Add(this.lbl_HCA_CA);
            this.tabDataEntry.Controls.Add(this.label18);
            this.tabDataEntry.Controls.Add(this.lbl_HCW_H);
            this.tabDataEntry.Controls.Add(this.lbl_HCA_H);
            this.tabDataEntry.Controls.Add(this.lbl_Lo_o);
            this.tabDataEntry.Controls.Add(this.cmbSystemType);
            this.tabDataEntry.Controls.Add(this.lblSystemType);
            this.tabDataEntry.Controls.Add(this.btnBeregn);
            this.tabDataEntry.Controls.Add(this.pnlLeddParams);
            this.tabDataEntry.Controls.Add(this.PlotSelector);
            this.tabDataEntry.Controls.Add(this.label12);
            this.tabDataEntry.Controls.Add(this.panel4);
            this.tabDataEntry.Controls.Add(this.label31);
            this.tabDataEntry.Controls.Add(this.label21);
            this.tabDataEntry.Controls.Add(this.label30);
            this.tabDataEntry.Controls.Add(this.label20);
            this.tabDataEntry.Controls.Add(this.label13);
            this.tabDataEntry.Controls.Add(this.lblKurveLengde);
            this.tabDataEntry.Controls.Add(this.lblTraseSammenstilling);
            this.tabDataEntry.Controls.Add(this.panel2);
            this.tabDataEntry.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabDataEntry.Location = new System.Drawing.Point(4, 24);
            this.tabDataEntry.Name = "tabDataEntry";
            this.tabDataEntry.Padding = new System.Windows.Forms.Padding(1);
            this.tabDataEntry.Size = new System.Drawing.Size(1094, 597);
            this.tabDataEntry.TabIndex = 5;
            this.tabDataEntry.Text = "Main Data Entry";
            // 
            // btnLagreledpartdata
            // 
            this.btnLagreledpartdata.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLagreledpartdata.Location = new System.Drawing.Point(662, 389);
            this.btnLagreledpartdata.Margin = new System.Windows.Forms.Padding(0);
            this.btnLagreledpartdata.Name = "btnLagreledpartdata";
            this.btnLagreledpartdata.Size = new System.Drawing.Size(115, 26);
            this.btnLagreledpartdata.TabIndex = 679;
            this.btnLagreledpartdata.Text = "Lagre ledpart data";
            this.btnLagreledpartdata.UseVisualStyleBackColor = true;
            this.btnLagreledpartdata.Click += new System.EventHandler(this.btnLagreledpartdata_Click);
            // 
            // btnLagreTrasedata
            // 
            this.btnLagreTrasedata.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLagreTrasedata.Location = new System.Drawing.Point(325, 539);
            this.btnLagreTrasedata.Margin = new System.Windows.Forms.Padding(0);
            this.btnLagreTrasedata.Name = "btnLagreTrasedata";
            this.btnLagreTrasedata.Size = new System.Drawing.Size(124, 34);
            this.btnLagreTrasedata.TabIndex = 678;
            this.btnLagreTrasedata.Text = "Lagre trasedata";
            this.btnLagreTrasedata.UseVisualStyleBackColor = true;
            this.btnLagreTrasedata.Click += new System.EventHandler(this.btnLagreTrasedata_Click);
            // 
            // btnOppdaterTraseLeng
            // 
            this.btnOppdaterTraseLeng.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOppdaterTraseLeng.Location = new System.Drawing.Point(146, 537);
            this.btnOppdaterTraseLeng.Name = "btnOppdaterTraseLeng";
            this.btnOppdaterTraseLeng.Size = new System.Drawing.Size(83, 39);
            this.btnOppdaterTraseLeng.TabIndex = 677;
            this.btnOppdaterTraseLeng.Text = "     Oppdater\r\ntraseledd lengder";
            this.btnOppdaterTraseLeng.UseVisualStyleBackColor = true;
            this.btnOppdaterTraseLeng.Visible = false;
            this.btnOppdaterTraseLeng.Click += new System.EventHandler(this.btnOppdaterTraseLeng_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(111, 342);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(30, 17);
            this.label14.TabIndex = 676;
            this.label14.Text = "m/s";
            // 
            // cmbE_R
            // 
            this.cmbE_R.DisplayMember = "1";
            this.cmbE_R.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbE_R.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbE_R.FormattingEnabled = true;
            this.cmbE_R.Items.AddRange(new object[] {
            "Type 1",
            "Type 2",
            "Type 3"});
            this.cmbE_R.Location = new System.Drawing.Point(18, 285);
            this.cmbE_R.Margin = new System.Windows.Forms.Padding(0);
            this.cmbE_R.Name = "cmbE_R";
            this.cmbE_R.Size = new System.Drawing.Size(57, 21);
            this.cmbE_R.TabIndex = 675;
            this.cmbE_R.SelectedIndexChanged += new System.EventHandler(this.cmbE_R_SelectedIndexChanged);
            // 
            // txtVind_kast
            // 
            this.txtVind_kast.Enabled = false;
            this.txtVind_kast.Location = new System.Drawing.Point(71, 370);
            this.txtVind_kast.Name = "txtVind_kast";
            this.txtVind_kast.Size = new System.Drawing.Size(42, 21);
            this.txtVind_kast.TabIndex = 674;
            this.txtVind_kast.Text = "30";
            // 
            // numUpDnVbo
            // 
            this.numUpDnVbo.Location = new System.Drawing.Point(71, 342);
            this.numUpDnVbo.Maximum = new decimal(new int[] {
            29,
            0,
            0,
            0});
            this.numUpDnVbo.Minimum = new decimal(new int[] {
            22,
            0,
            0,
            0});
            this.numUpDnVbo.Name = "numUpDnVbo";
            this.numUpDnVbo.Size = new System.Drawing.Size(42, 21);
            this.numUpDnVbo.TabIndex = 673;
            this.numUpDnVbo.Value = new decimal(new int[] {
            22,
            0,
            0,
            0});
            this.numUpDnVbo.ValueChanged += new System.EventHandler(this.nmUpDnVbo_ValueChanged);
            // 
            // lbl_Vb_kast_bkast
            // 
            this.lbl_Vb_kast_bkast.AutoSize = true;
            this.lbl_Vb_kast_bkast.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Vb_kast_bkast.Location = new System.Drawing.Point(13, 376);
            this.lbl_Vb_kast_bkast.Name = "lbl_Vb_kast_bkast";
            this.lbl_Vb_kast_bkast.Size = new System.Drawing.Size(39, 13);
            this.lbl_Vb_kast_bkast.TabIndex = 672;
            this.lbl_Vb_kast_bkast.Text = "b_kast";
            // 
            // lblVbkast_V
            // 
            this.lblVbkast_V.AutoSize = true;
            this.lblVbkast_V.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVbkast_V.Location = new System.Drawing.Point(3, 368);
            this.lblVbkast_V.Name = "lblVbkast_V";
            this.lblVbkast_V.Size = new System.Drawing.Size(17, 17);
            this.lblVbkast_V.TabIndex = 671;
            this.lblVbkast_V.Text = "V";
            // 
            // btnVindKart
            // 
            this.btnVindKart.BackColor = System.Drawing.Color.Peru;
            this.btnVindKart.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVindKart.Location = new System.Drawing.Point(23, 313);
            this.btnVindKart.Margin = new System.Windows.Forms.Padding(0);
            this.btnVindKart.Name = "btnVindKart";
            this.btnVindKart.Padding = new System.Windows.Forms.Padding(1);
            this.btnVindKart.Size = new System.Drawing.Size(90, 26);
            this.btnVindKart.TabIndex = 670;
            this.btnVindKart.Text = "Vind Kart";
            this.btnVindKart.UseVisualStyleBackColor = false;
            this.btnVindKart.Click += new System.EventHandler(this.btnVindKart_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.rdbtnImport);
            this.panel3.Controls.Add(this.rdbtnSkrive);
            this.panel3.Location = new System.Drawing.Point(211, 144);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(325, 21);
            this.panel3.TabIndex = 669;
            // 
            // rdbtnImport
            // 
            this.rdbtnImport.AutoSize = true;
            this.rdbtnImport.Location = new System.Drawing.Point(194, 1);
            this.rdbtnImport.Name = "rdbtnImport";
            this.rdbtnImport.Size = new System.Drawing.Size(114, 19);
            this.rdbtnImport.TabIndex = 670;
            this.rdbtnImport.Text = "Import trasedata";
            this.rdbtnImport.UseVisualStyleBackColor = true;
            this.rdbtnImport.CheckedChanged += new System.EventHandler(this.rdbtnImport_CheckedChanged);
            // 
            // rdbtnSkrive
            // 
            this.rdbtnSkrive.AutoSize = true;
            this.rdbtnSkrive.Checked = true;
            this.rdbtnSkrive.Location = new System.Drawing.Point(6, 1);
            this.rdbtnSkrive.Name = "rdbtnSkrive";
            this.rdbtnSkrive.Size = new System.Drawing.Size(125, 19);
            this.rdbtnSkrive.TabIndex = 0;
            this.rdbtnSkrive.TabStop = true;
            this.rdbtnSkrive.Text = "Skriv inn trasedata";
            this.rdbtnSkrive.UseVisualStyleBackColor = true;
            this.rdbtnSkrive.CheckedChanged += new System.EventHandler(this.rdbtnImport_CheckedChanged);
            // 
            // btnHentData
            // 
            this.btnHentData.BackColor = System.Drawing.Color.Thistle;
            this.btnHentData.Enabled = false;
            this.btnHentData.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHentData.Location = new System.Drawing.Point(448, 168);
            this.btnHentData.Margin = new System.Windows.Forms.Padding(0);
            this.btnHentData.Name = "btnHentData";
            this.btnHentData.Size = new System.Drawing.Size(89, 44);
            this.btnHentData.TabIndex = 668;
            this.btnHentData.Text = "Hent trasedata\r\n  fra excel fil";
            this.btnHentData.UseVisualStyleBackColor = false;
            this.btnHentData.Click += new System.EventHandler(this.btnHentData_Click);
            // 
            // pnlSKriv
            // 
            this.pnlSKriv.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.pnlSKriv.Controls.Add(this.ckBxkm);
            this.pnlSKriv.Controls.Add(this.antall_ledd);
            this.pnlSKriv.Controls.Add(this.label16);
            this.pnlSKriv.Location = new System.Drawing.Point(211, 167);
            this.pnlSKriv.Name = "pnlSKriv";
            this.pnlSKriv.Size = new System.Drawing.Size(223, 43);
            this.pnlSKriv.TabIndex = 666;
            // 
            // ckBxkm
            // 
            this.ckBxkm.AutoSize = true;
            this.ckBxkm.Location = new System.Drawing.Point(6, 6);
            this.ckBxkm.Name = "ckBxkm";
            this.ckBxkm.Size = new System.Drawing.Size(98, 34);
            this.ckBxkm.TabIndex = 660;
            this.ckBxkm.Text = "       Bruk \r\nkilometrering";
            this.ckBxkm.UseVisualStyleBackColor = true;
            this.ckBxkm.CheckedChanged += new System.EventHandler(this.ckBxkm_Click);
            // 
            // antall_ledd
            // 
            this.antall_ledd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.antall_ledd.Location = new System.Drawing.Point(173, 10);
            this.antall_ledd.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.antall_ledd.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.antall_ledd.Name = "antall_ledd";
            this.antall_ledd.Size = new System.Drawing.Size(44, 21);
            this.antall_ledd.TabIndex = 617;
            this.antall_ledd.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.antall_ledd.ValueChanged += new System.EventHandler(this.answer_antalLedd_enter);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(112, 6);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(58, 30);
            this.label16.TabIndex = 85;
            this.label16.Text = "Antall \r\ntraseledd";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(115, 523);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(19, 17);
            this.label8.TabIndex = 665;
            this.label8.Text = "m";
            // 
            // numUpDnR_3_5spenn
            // 
            this.numUpDnR_3_5spenn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numUpDnR_3_5spenn.Location = new System.Drawing.Point(68, 522);
            this.numUpDnR_3_5spenn.Maximum = new decimal(new int[] {
            2000,
            0,
            0,
            0});
            this.numUpDnR_3_5spenn.Minimum = new decimal(new int[] {
            900,
            0,
            0,
            0});
            this.numUpDnR_3_5spenn.Name = "numUpDnR_3_5spenn";
            this.numUpDnR_3_5spenn.Size = new System.Drawing.Size(49, 22);
            this.numUpDnR_3_5spenn.TabIndex = 664;
            this.numUpDnR_3_5spenn.Value = new decimal(new int[] {
            1300,
            0,
            0,
            0});
            // 
            // lbl3_5_spenn
            // 
            this.lbl3_5_spenn.AutoSize = true;
            this.lbl3_5_spenn.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl3_5_spenn.Location = new System.Drawing.Point(1, 513);
            this.lbl3_5_spenn.Name = "lbl3_5_spenn";
            this.lbl3_5_spenn.Size = new System.Drawing.Size(65, 26);
            this.lbl3_5_spenn.TabIndex = 663;
            this.lbl3_5_spenn.Text = "5-spenn \r\navsp.for R <";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.Location = new System.Drawing.Point(717, 419);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(127, 17);
            this.label53.TabIndex = 193;
            this.label53.Text = "Ledningspart trase";
            // 
            // numUpDnseksjPos
            // 
            this.numUpDnseksjPos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.numUpDnseksjPos.Location = new System.Drawing.Point(471, 218);
            this.numUpDnseksjPos.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.numUpDnseksjPos.Name = "numUpDnseksjPos";
            this.numUpDnseksjPos.Size = new System.Drawing.Size(64, 21);
            this.numUpDnseksjPos.TabIndex = 658;
            this.numUpDnseksjPos.Value = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(357, 218);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(109, 15);
            this.label6.TabIndex = 657;
            this.label6.Text = "Seksjonering etter:";
            // 
            // lblTraseLedd
            // 
            this.lblTraseLedd.AutoSize = true;
            this.lblTraseLedd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTraseLedd.Location = new System.Drawing.Point(147, 245);
            this.lblTraseLedd.Name = "lblTraseLedd";
            this.lblTraseLedd.Size = new System.Drawing.Size(65, 15);
            this.lblTraseLedd.TabIndex = 655;
            this.lblTraseLedd.Text = "Trase ledd";
            // 
            // numUpDnOffset
            // 
            this.numUpDnOffset.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.numUpDnOffset.Location = new System.Drawing.Point(246, 219);
            this.numUpDnOffset.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.numUpDnOffset.Name = "numUpDnOffset";
            this.numUpDnOffset.Size = new System.Drawing.Size(69, 21);
            this.numUpDnOffset.TabIndex = 654;
            // 
            // lbl_offset
            // 
            this.lbl_offset.AutoSize = true;
            this.lbl_offset.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_offset.Location = new System.Drawing.Point(206, 219);
            this.lbl_offset.Name = "lbl_offset";
            this.lbl_offset.Size = new System.Drawing.Size(38, 15);
            this.lbl_offset.TabIndex = 653;
            this.lbl_offset.Text = "Offset";
            // 
            // cmbLo
            // 
            this.cmbLo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbLo.FormattingEnabled = true;
            this.cmbLo.Items.AddRange(new object[] {
            "65",
            "70",
            "75"});
            this.cmbLo.Location = new System.Drawing.Point(71, 255);
            this.cmbLo.Name = "cmbLo";
            this.cmbLo.Size = new System.Drawing.Size(42, 23);
            this.cmbLo.TabIndex = 652;
            // 
            // numUpDnFmin
            // 
            this.numUpDnFmin.Location = new System.Drawing.Point(71, 430);
            this.numUpDnFmin.Minimum = new decimal(new int[] {
            80,
            0,
            0,
            0});
            this.numUpDnFmin.Name = "numUpDnFmin";
            this.numUpDnFmin.Size = new System.Drawing.Size(42, 21);
            this.numUpDnFmin.TabIndex = 621;
            this.numUpDnFmin.Value = new decimal(new int[] {
            80,
            0,
            0,
            0});
            this.numUpDnFmin.ValueChanged += new System.EventHandler(this.numUpDnFmin_TextChanged);
            // 
            // btnVindUtb
            // 
            this.btnVindUtb.BackColor = System.Drawing.Color.Peru;
            this.btnVindUtb.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVindUtb.Location = new System.Drawing.Point(76, 284);
            this.btnVindUtb.Margin = new System.Windows.Forms.Padding(0);
            this.btnVindUtb.Name = "btnVindUtb";
            this.btnVindUtb.Padding = new System.Windows.Forms.Padding(1);
            this.btnVindUtb.Size = new System.Drawing.Size(38, 24);
            this.btnVindUtb.TabIndex = 641;
            this.btnVindUtb.Text = "E(R)";
            this.btnVindUtb.UseVisualStyleBackColor = false;
            this.btnVindUtb.Click += new System.EventHandler(this.btnVindUtb_Click);
            // 
            // lbl_m_s
            // 
            this.lbl_m_s.AutoSize = true;
            this.lbl_m_s.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_m_s.Location = new System.Drawing.Point(111, 369);
            this.lbl_m_s.Name = "lbl_m_s";
            this.lbl_m_s.Size = new System.Drawing.Size(30, 17);
            this.lbl_m_s.TabIndex = 650;
            this.lbl_m_s.Text = "m/s";
            // 
            // lbl_Vbo_bo
            // 
            this.lbl_Vbo_bo.AutoSize = true;
            this.lbl_Vbo_bo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Vbo_bo.Location = new System.Drawing.Point(13, 350);
            this.lbl_Vbo_bo.Name = "lbl_Vbo_bo";
            this.lbl_Vbo_bo.Size = new System.Drawing.Size(19, 13);
            this.lbl_Vbo_bo.TabIndex = 649;
            this.lbl_Vbo_bo.Text = "bo";
            // 
            // lbl_Vw_V
            // 
            this.lbl_Vw_V.AutoSize = true;
            this.lbl_Vw_V.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Vw_V.Location = new System.Drawing.Point(3, 342);
            this.lbl_Vw_V.Name = "lbl_Vw_V";
            this.lbl_Vw_V.Size = new System.Drawing.Size(17, 17);
            this.lbl_Vw_V.TabIndex = 648;
            this.lbl_Vw_V.Text = "V";
            // 
            // lbl_N
            // 
            this.lbl_N.AutoSize = true;
            this.lbl_N.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_N.Location = new System.Drawing.Point(111, 399);
            this.lbl_N.Name = "lbl_N";
            this.lbl_N.Size = new System.Drawing.Size(33, 17);
            this.lbl_N.TabIndex = 647;
            this.lbl_N.Text = "N/m";
            // 
            // lbl_Fw_w
            // 
            this.lbl_Fw_w.AutoSize = true;
            this.lbl_Fw_w.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Fw_w.Location = new System.Drawing.Point(14, 405);
            this.lbl_Fw_w.Name = "lbl_Fw_w";
            this.lbl_Fw_w.Size = new System.Drawing.Size(15, 13);
            this.lbl_Fw_w.TabIndex = 645;
            this.lbl_Fw_w.Text = "w";
            // 
            // lbl_Fw_F
            // 
            this.lbl_Fw_F.AutoSize = true;
            this.lbl_Fw_F.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Fw_F.Location = new System.Drawing.Point(2, 398);
            this.lbl_Fw_F.Name = "lbl_Fw_F";
            this.lbl_Fw_F.Size = new System.Drawing.Size(16, 17);
            this.lbl_Fw_F.TabIndex = 646;
            this.lbl_Fw_F.Text = "F";
            // 
            // txtVindKraft
            // 
            this.txtVindKraft.Enabled = false;
            this.txtVindKraft.Location = new System.Drawing.Point(71, 399);
            this.txtVindKraft.Name = "txtVindKraft";
            this.txtVindKraft.Size = new System.Drawing.Size(42, 21);
            this.txtVindKraft.TabIndex = 644;
            this.txtVindKraft.Text = "15";
            // 
            // txtHcw
            // 
            this.txtHcw.Enabled = false;
            this.txtHcw.Location = new System.Drawing.Point(71, 491);
            this.txtHcw.Name = "txtHcw";
            this.txtHcw.Size = new System.Drawing.Size(42, 21);
            this.txtHcw.TabIndex = 629;
            this.txtHcw.Text = "10";
            // 
            // txtHca
            // 
            this.txtHca.Enabled = false;
            this.txtHca.Location = new System.Drawing.Point(71, 461);
            this.txtHca.Name = "txtHca";
            this.txtHca.Size = new System.Drawing.Size(42, 21);
            this.txtHca.TabIndex = 626;
            this.txtHca.Text = "10";
            // 
            // lbl_cm1
            // 
            this.lbl_cm1.AutoSize = true;
            this.lbl_cm1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_cm1.Location = new System.Drawing.Point(313, 217);
            this.lbl_cm1.Name = "lbl_cm1";
            this.lbl_cm1.Size = new System.Drawing.Size(19, 17);
            this.lbl_cm1.TabIndex = 639;
            this.lbl_cm1.Text = "m";
            // 
            // lbl_N2
            // 
            this.lbl_N2.AutoSize = true;
            this.lbl_N2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_N2.Location = new System.Drawing.Point(111, 429);
            this.lbl_N2.Name = "lbl_N2";
            this.lbl_N2.Size = new System.Drawing.Size(18, 17);
            this.lbl_N2.TabIndex = 642;
            this.lbl_N2.Text = "N";
            // 
            // lbl_kN2
            // 
            this.lbl_kN2.AutoSize = true;
            this.lbl_kN2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_kN2.Location = new System.Drawing.Point(111, 493);
            this.lbl_kN2.Name = "lbl_kN2";
            this.lbl_kN2.Size = new System.Drawing.Size(25, 17);
            this.lbl_kN2.TabIndex = 643;
            this.lbl_kN2.Text = "kN";
            // 
            // lbl_kN
            // 
            this.lbl_kN.AutoSize = true;
            this.lbl_kN.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_kN.Location = new System.Drawing.Point(111, 462);
            this.lbl_kN.Name = "lbl_kN";
            this.lbl_kN.Size = new System.Drawing.Size(25, 17);
            this.lbl_kN.TabIndex = 638;
            this.lbl_kN.Text = "kN";
            // 
            // lbl_m2
            // 
            this.lbl_m2.AutoSize = true;
            this.lbl_m2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_m2.Location = new System.Drawing.Point(111, 254);
            this.lbl_m2.Name = "lbl_m2";
            this.lbl_m2.Size = new System.Drawing.Size(19, 17);
            this.lbl_m2.TabIndex = 637;
            this.lbl_m2.Text = "m";
            // 
            // lblTillatVinUt
            // 
            this.lblTillatVinUt.AutoSize = true;
            this.lblTillatVinUt.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTillatVinUt.Location = new System.Drawing.Point(3, 285);
            this.lblTillatVinUt.Name = "lblTillatVinUt";
            this.lblTillatVinUt.Size = new System.Drawing.Size(17, 17);
            this.lblTillatVinUt.TabIndex = 636;
            this.lblTillatVinUt.Text = "E";
            // 
            // lbl_Fmin_min
            // 
            this.lbl_Fmin_min.AutoSize = true;
            this.lbl_Fmin_min.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Fmin_min.Location = new System.Drawing.Point(14, 435);
            this.lbl_Fmin_min.Name = "lbl_Fmin_min";
            this.lbl_Fmin_min.Size = new System.Drawing.Size(23, 13);
            this.lbl_Fmin_min.TabIndex = 634;
            this.lbl_Fmin_min.Text = "min";
            // 
            // lbl_Fmin_F
            // 
            this.lbl_Fmin_F.AutoSize = true;
            this.lbl_Fmin_F.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Fmin_F.Location = new System.Drawing.Point(2, 428);
            this.lbl_Fmin_F.Name = "lbl_Fmin_F";
            this.lbl_Fmin_F.Size = new System.Drawing.Size(16, 17);
            this.lbl_Fmin_F.TabIndex = 635;
            this.lbl_Fmin_F.Text = "F";
            // 
            // lbl_HCW_CW
            // 
            this.lbl_HCW_CW.AutoSize = true;
            this.lbl_HCW_CW.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_HCW_CW.Location = new System.Drawing.Point(15, 499);
            this.lbl_HCW_CW.Name = "lbl_HCW_CW";
            this.lbl_HCW_CW.Size = new System.Drawing.Size(25, 13);
            this.lbl_HCW_CW.TabIndex = 632;
            this.lbl_HCW_CW.Text = "CW";
            // 
            // lbl_HCA_CA
            // 
            this.lbl_HCA_CA.AutoSize = true;
            this.lbl_HCA_CA.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_HCA_CA.Location = new System.Drawing.Point(15, 472);
            this.lbl_HCA_CA.Name = "lbl_HCA_CA";
            this.lbl_HCA_CA.Size = new System.Drawing.Size(21, 13);
            this.lbl_HCA_CA.TabIndex = 630;
            this.lbl_HCA_CA.Text = "CA";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(14, 264);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(13, 13);
            this.label18.TabIndex = 627;
            this.label18.Text = "o";
            // 
            // lbl_HCW_H
            // 
            this.lbl_HCW_H.AutoSize = true;
            this.lbl_HCW_H.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_HCW_H.Location = new System.Drawing.Point(2, 492);
            this.lbl_HCW_H.Name = "lbl_HCW_H";
            this.lbl_HCW_H.Size = new System.Drawing.Size(18, 17);
            this.lbl_HCW_H.TabIndex = 631;
            this.lbl_HCW_H.Text = "H";
            // 
            // lbl_HCA_H
            // 
            this.lbl_HCA_H.AutoSize = true;
            this.lbl_HCA_H.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_HCA_H.Location = new System.Drawing.Point(2, 464);
            this.lbl_HCA_H.Name = "lbl_HCA_H";
            this.lbl_HCA_H.Size = new System.Drawing.Size(18, 17);
            this.lbl_HCA_H.TabIndex = 628;
            this.lbl_HCA_H.Text = "H";
            // 
            // lbl_Lo_o
            // 
            this.lbl_Lo_o.AutoSize = true;
            this.lbl_Lo_o.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Lo_o.Location = new System.Drawing.Point(3, 256);
            this.lbl_Lo_o.Name = "lbl_Lo_o";
            this.lbl_Lo_o.Size = new System.Drawing.Size(16, 17);
            this.lbl_Lo_o.TabIndex = 625;
            this.lbl_Lo_o.Text = "L";
            // 
            // cmbSystemType
            // 
            this.cmbSystemType.AllowDrop = true;
            this.cmbSystemType.DisplayMember = "1";
            this.cmbSystemType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSystemType.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSystemType.FormattingEnabled = true;
            this.cmbSystemType.Items.AddRange(new object[] {
            "S25",
            "S20",
            "S35"});
            this.cmbSystemType.Location = new System.Drawing.Point(62, 225);
            this.cmbSystemType.Name = "cmbSystemType";
            this.cmbSystemType.Size = new System.Drawing.Size(51, 21);
            this.cmbSystemType.TabIndex = 620;
            this.cmbSystemType.ValueMember = "1";
            this.cmbSystemType.TextChanged += new System.EventHandler(this.cmbSystemType_TextChanged);
            // 
            // lblSystemType
            // 
            this.lblSystemType.AutoSize = true;
            this.lblSystemType.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSystemType.Location = new System.Drawing.Point(3, 215);
            this.lblSystemType.Name = "lblSystemType";
            this.lblSystemType.Size = new System.Drawing.Size(54, 34);
            this.lblSystemType.TabIndex = 619;
            this.lblSystemType.Text = "System\r\n Type";
            // 
            // btnBeregn
            // 
            this.btnBeregn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBeregn.Location = new System.Drawing.Point(514, 539);
            this.btnBeregn.Name = "btnBeregn";
            this.btnBeregn.Size = new System.Drawing.Size(110, 35);
            this.btnBeregn.TabIndex = 618;
            this.btnBeregn.Text = "Beregn ledpart";
            this.btnBeregn.UseVisualStyleBackColor = true;
            this.btnBeregn.Click += new System.EventHandler(this.Beregn);
            // 
            // pnlLeddParams
            // 
            this.pnlLeddParams.AutoScroll = true;
            this.pnlLeddParams.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlLeddParams.Controls.Add(this.LeddRetn10);
            this.pnlLeddParams.Controls.Add(this.LeddRetn9);
            this.pnlLeddParams.Controls.Add(this.LeddRetn8);
            this.pnlLeddParams.Controls.Add(this.LeddRetn7);
            this.pnlLeddParams.Controls.Add(this.LeddRetn6);
            this.pnlLeddParams.Controls.Add(this.LeddRetn5);
            this.pnlLeddParams.Controls.Add(this.LeddRetn4);
            this.pnlLeddParams.Controls.Add(this.LeddRetn3);
            this.pnlLeddParams.Controls.Add(this.LeddRetn2);
            this.pnlLeddParams.Controls.Add(this.comboBox9);
            this.pnlLeddParams.Controls.Add(this.LeddRetn1);
            this.pnlLeddParams.Controls.Add(this.TypeKurve10);
            this.pnlLeddParams.Controls.Add(this.LeddRad10);
            this.pnlLeddParams.Controls.Add(this.TypeKurve9);
            this.pnlLeddParams.Controls.Add(this.LeddRad9);
            this.pnlLeddParams.Controls.Add(this.TypeKurve8);
            this.pnlLeddParams.Controls.Add(this.LeddRad8);
            this.pnlLeddParams.Controls.Add(this.TypeKurve7);
            this.pnlLeddParams.Controls.Add(this.LeddRad7);
            this.pnlLeddParams.Controls.Add(this.TypeKurve6);
            this.pnlLeddParams.Controls.Add(this.LeddRad6);
            this.pnlLeddParams.Controls.Add(this.TypeKurve5);
            this.pnlLeddParams.Controls.Add(this.LeddRad5);
            this.pnlLeddParams.Controls.Add(this.TypeKurve4);
            this.pnlLeddParams.Controls.Add(this.LeddRad4);
            this.pnlLeddParams.Controls.Add(this.TypeKurve3);
            this.pnlLeddParams.Controls.Add(this.LeddRad3);
            this.pnlLeddParams.Controls.Add(this.TypeKurve2);
            this.pnlLeddParams.Controls.Add(this.LeddRad2);
            this.pnlLeddParams.Controls.Add(this.LeddLeng10);
            this.pnlLeddParams.Controls.Add(this.LeddLeng9);
            this.pnlLeddParams.Controls.Add(this.LeddLeng8);
            this.pnlLeddParams.Controls.Add(this.LeddLeng7);
            this.pnlLeddParams.Controls.Add(this.LeddLeng6);
            this.pnlLeddParams.Controls.Add(this.LeddLeng5);
            this.pnlLeddParams.Controls.Add(this.LeddLeng4);
            this.pnlLeddParams.Controls.Add(this.LeddLeng3);
            this.pnlLeddParams.Controls.Add(this.LeddLeng2);
            this.pnlLeddParams.Controls.Add(this.numericUpDown2);
            this.pnlLeddParams.Controls.Add(this.LeddLeng1);
            this.pnlLeddParams.Controls.Add(this.LeddEnd10);
            this.pnlLeddParams.Controls.Add(this.LeddStart10);
            this.pnlLeddParams.Controls.Add(this.lblLedd10);
            this.pnlLeddParams.Controls.Add(this.LeddEnd9);
            this.pnlLeddParams.Controls.Add(this.LeddStart9);
            this.pnlLeddParams.Controls.Add(this.lblLedd9);
            this.pnlLeddParams.Controls.Add(this.LeddEnd8);
            this.pnlLeddParams.Controls.Add(this.LeddStart8);
            this.pnlLeddParams.Controls.Add(this.lblLedd8);
            this.pnlLeddParams.Controls.Add(this.LeddEnd7);
            this.pnlLeddParams.Controls.Add(this.LeddStart7);
            this.pnlLeddParams.Controls.Add(this.lblLedd7);
            this.pnlLeddParams.Controls.Add(this.LeddEnd6);
            this.pnlLeddParams.Controls.Add(this.LeddStart6);
            this.pnlLeddParams.Controls.Add(this.lblLedd6);
            this.pnlLeddParams.Controls.Add(this.LeddEnd5);
            this.pnlLeddParams.Controls.Add(this.LeddStart5);
            this.pnlLeddParams.Controls.Add(this.lblLedd5);
            this.pnlLeddParams.Controls.Add(this.LeddEnd4);
            this.pnlLeddParams.Controls.Add(this.LeddStart4);
            this.pnlLeddParams.Controls.Add(this.lblLedd4);
            this.pnlLeddParams.Controls.Add(this.LeddEnd3);
            this.pnlLeddParams.Controls.Add(this.LeddStart3);
            this.pnlLeddParams.Controls.Add(this.lblLedd3);
            this.pnlLeddParams.Controls.Add(this.LeddEnd2);
            this.pnlLeddParams.Controls.Add(this.LeddStart2);
            this.pnlLeddParams.Controls.Add(this.comboBox1);
            this.pnlLeddParams.Controls.Add(this.lblLedd2);
            this.pnlLeddParams.Controls.Add(this.textBox2);
            this.pnlLeddParams.Controls.Add(this.TypeKurve1);
            this.pnlLeddParams.Controls.Add(this.textBox1);
            this.pnlLeddParams.Controls.Add(this.LeddEnd1);
            this.pnlLeddParams.Controls.Add(this.LeddStart1);
            this.pnlLeddParams.Controls.Add(this.numericUpDown1);
            this.pnlLeddParams.Controls.Add(this.lblLedd1);
            this.pnlLeddParams.Controls.Add(this.LeddRad1);
            this.pnlLeddParams.Location = new System.Drawing.Point(146, 266);
            this.pnlLeddParams.Name = "pnlLeddParams";
            this.pnlLeddParams.Size = new System.Drawing.Size(477, 268);
            this.pnlLeddParams.TabIndex = 194;
            // 
            // LeddRetn10
            // 
            this.LeddRetn10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeddRetn10.FormattingEnabled = true;
            this.LeddRetn10.Items.AddRange(new object[] {
            "+",
            "-"});
            this.LeddRetn10.Location = new System.Drawing.Point(411, 241);
            this.LeddRetn10.Name = "LeddRetn10";
            this.LeddRetn10.Size = new System.Drawing.Size(37, 23);
            this.LeddRetn10.TabIndex = 627;
            this.LeddRetn10.Text = "+";
            this.LeddRetn10.Visible = false;
            // 
            // LeddRetn9
            // 
            this.LeddRetn9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeddRetn9.FormattingEnabled = true;
            this.LeddRetn9.Items.AddRange(new object[] {
            "+",
            "-"});
            this.LeddRetn9.Location = new System.Drawing.Point(411, 214);
            this.LeddRetn9.Name = "LeddRetn9";
            this.LeddRetn9.Size = new System.Drawing.Size(37, 23);
            this.LeddRetn9.TabIndex = 626;
            this.LeddRetn9.Text = "+";
            this.LeddRetn9.Visible = false;
            // 
            // LeddRetn8
            // 
            this.LeddRetn8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeddRetn8.FormattingEnabled = true;
            this.LeddRetn8.Items.AddRange(new object[] {
            "+",
            "-"});
            this.LeddRetn8.Location = new System.Drawing.Point(411, 185);
            this.LeddRetn8.Name = "LeddRetn8";
            this.LeddRetn8.Size = new System.Drawing.Size(37, 23);
            this.LeddRetn8.TabIndex = 625;
            this.LeddRetn8.Text = "+";
            this.LeddRetn8.Visible = false;
            // 
            // LeddRetn7
            // 
            this.LeddRetn7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeddRetn7.FormattingEnabled = true;
            this.LeddRetn7.Items.AddRange(new object[] {
            "+",
            "-"});
            this.LeddRetn7.Location = new System.Drawing.Point(411, 157);
            this.LeddRetn7.Name = "LeddRetn7";
            this.LeddRetn7.Size = new System.Drawing.Size(37, 23);
            this.LeddRetn7.TabIndex = 624;
            this.LeddRetn7.Text = "+";
            this.LeddRetn7.Visible = false;
            // 
            // LeddRetn6
            // 
            this.LeddRetn6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeddRetn6.FormattingEnabled = true;
            this.LeddRetn6.Items.AddRange(new object[] {
            "+",
            "-"});
            this.LeddRetn6.Location = new System.Drawing.Point(411, 131);
            this.LeddRetn6.Name = "LeddRetn6";
            this.LeddRetn6.Size = new System.Drawing.Size(37, 23);
            this.LeddRetn6.TabIndex = 623;
            this.LeddRetn6.Text = "+";
            this.LeddRetn6.Visible = false;
            // 
            // LeddRetn5
            // 
            this.LeddRetn5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeddRetn5.FormattingEnabled = true;
            this.LeddRetn5.Items.AddRange(new object[] {
            "+",
            "-"});
            this.LeddRetn5.Location = new System.Drawing.Point(411, 105);
            this.LeddRetn5.Name = "LeddRetn5";
            this.LeddRetn5.Size = new System.Drawing.Size(37, 23);
            this.LeddRetn5.TabIndex = 622;
            this.LeddRetn5.Text = "+";
            this.LeddRetn5.Visible = false;
            // 
            // LeddRetn4
            // 
            this.LeddRetn4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeddRetn4.FormattingEnabled = true;
            this.LeddRetn4.Items.AddRange(new object[] {
            "+",
            "-"});
            this.LeddRetn4.Location = new System.Drawing.Point(411, 80);
            this.LeddRetn4.Name = "LeddRetn4";
            this.LeddRetn4.Size = new System.Drawing.Size(37, 23);
            this.LeddRetn4.TabIndex = 621;
            this.LeddRetn4.Text = "+";
            this.LeddRetn4.Visible = false;
            // 
            // LeddRetn3
            // 
            this.LeddRetn3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeddRetn3.FormattingEnabled = true;
            this.LeddRetn3.Items.AddRange(new object[] {
            "+",
            "-"});
            this.LeddRetn3.Location = new System.Drawing.Point(411, 55);
            this.LeddRetn3.Name = "LeddRetn3";
            this.LeddRetn3.Size = new System.Drawing.Size(37, 23);
            this.LeddRetn3.TabIndex = 620;
            this.LeddRetn3.Text = "+";
            this.LeddRetn3.Visible = false;
            // 
            // LeddRetn2
            // 
            this.LeddRetn2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeddRetn2.FormattingEnabled = true;
            this.LeddRetn2.Items.AddRange(new object[] {
            "+",
            "-"});
            this.LeddRetn2.Location = new System.Drawing.Point(411, 29);
            this.LeddRetn2.Name = "LeddRetn2";
            this.LeddRetn2.Size = new System.Drawing.Size(37, 23);
            this.LeddRetn2.TabIndex = 619;
            this.LeddRetn2.Text = "+";
            this.LeddRetn2.Visible = false;
            // 
            // comboBox9
            // 
            this.comboBox9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox9.FormattingEnabled = true;
            this.comboBox9.Items.AddRange(new object[] {
            "+",
            "-"});
            this.comboBox9.Location = new System.Drawing.Point(495, -26);
            this.comboBox9.Name = "comboBox9";
            this.comboBox9.Size = new System.Drawing.Size(37, 23);
            this.comboBox9.TabIndex = 617;
            this.comboBox9.Text = "+";
            this.comboBox9.Visible = false;
            // 
            // LeddRetn1
            // 
            this.LeddRetn1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeddRetn1.FormattingEnabled = true;
            this.LeddRetn1.Items.AddRange(new object[] {
            "+",
            "-"});
            this.LeddRetn1.Location = new System.Drawing.Point(411, 3);
            this.LeddRetn1.Name = "LeddRetn1";
            this.LeddRetn1.Size = new System.Drawing.Size(37, 23);
            this.LeddRetn1.TabIndex = 617;
            this.LeddRetn1.Text = "+";
            this.LeddRetn1.Visible = false;
            // 
            // TypeKurve10
            // 
            this.TypeKurve10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TypeKurve10.FormattingEnabled = true;
            this.TypeKurve10.Items.AddRange(new object[] {
            "Rett linje",
            "Kurve"});
            this.TypeKurve10.Location = new System.Drawing.Point(255, 241);
            this.TypeKurve10.Name = "TypeKurve10";
            this.TypeKurve10.Size = new System.Drawing.Size(73, 23);
            this.TypeKurve10.TabIndex = 616;
            this.TypeKurve10.Text = "Rett linje";
            this.TypeKurve10.Visible = false;
            // 
            // LeddRad10
            // 
            this.LeddRad10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeddRad10.Location = new System.Drawing.Point(337, 243);
            this.LeddRad10.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.LeddRad10.Minimum = new decimal(new int[] {
            180,
            0,
            0,
            0});
            this.LeddRad10.Name = "LeddRad10";
            this.LeddRad10.Size = new System.Drawing.Size(65, 21);
            this.LeddRad10.TabIndex = 614;
            this.LeddRad10.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.LeddRad10.Visible = false;
            // 
            // TypeKurve9
            // 
            this.TypeKurve9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TypeKurve9.FormattingEnabled = true;
            this.TypeKurve9.Items.AddRange(new object[] {
            "Rett linje",
            "Kurve",
            "Overgang"});
            this.TypeKurve9.Location = new System.Drawing.Point(255, 214);
            this.TypeKurve9.Name = "TypeKurve9";
            this.TypeKurve9.Size = new System.Drawing.Size(73, 23);
            this.TypeKurve9.TabIndex = 613;
            this.TypeKurve9.Text = "Rett linje";
            this.TypeKurve9.Visible = false;
            this.TypeKurve9.SelectedValueChanged += new System.EventHandler(this.TypeKurve9_Change);
            this.TypeKurve9.MouseEnter += new System.EventHandler(this.TypeKurve9_Enter);
            // 
            // LeddRad9
            // 
            this.LeddRad9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeddRad9.Location = new System.Drawing.Point(337, 216);
            this.LeddRad9.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.LeddRad9.Minimum = new decimal(new int[] {
            180,
            0,
            0,
            0});
            this.LeddRad9.Name = "LeddRad9";
            this.LeddRad9.Size = new System.Drawing.Size(65, 21);
            this.LeddRad9.TabIndex = 611;
            this.LeddRad9.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.LeddRad9.Visible = false;
            // 
            // TypeKurve8
            // 
            this.TypeKurve8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TypeKurve8.FormattingEnabled = true;
            this.TypeKurve8.Items.AddRange(new object[] {
            "Rett linje",
            "Kurve",
            "Overgang"});
            this.TypeKurve8.Location = new System.Drawing.Point(255, 185);
            this.TypeKurve8.Name = "TypeKurve8";
            this.TypeKurve8.Size = new System.Drawing.Size(73, 23);
            this.TypeKurve8.TabIndex = 610;
            this.TypeKurve8.Text = "Rett linje";
            this.TypeKurve8.Visible = false;
            this.TypeKurve8.SelectedValueChanged += new System.EventHandler(this.TypeKurve8_Change);
            this.TypeKurve8.MouseEnter += new System.EventHandler(this.TypeKurve8_Enter);
            // 
            // LeddRad8
            // 
            this.LeddRad8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeddRad8.Location = new System.Drawing.Point(337, 187);
            this.LeddRad8.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.LeddRad8.Minimum = new decimal(new int[] {
            180,
            0,
            0,
            0});
            this.LeddRad8.Name = "LeddRad8";
            this.LeddRad8.Size = new System.Drawing.Size(65, 21);
            this.LeddRad8.TabIndex = 608;
            this.LeddRad8.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.LeddRad8.Visible = false;
            // 
            // TypeKurve7
            // 
            this.TypeKurve7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TypeKurve7.FormattingEnabled = true;
            this.TypeKurve7.Items.AddRange(new object[] {
            "Rett linje",
            "Kurve",
            "Overgang"});
            this.TypeKurve7.Location = new System.Drawing.Point(255, 157);
            this.TypeKurve7.Name = "TypeKurve7";
            this.TypeKurve7.Size = new System.Drawing.Size(73, 23);
            this.TypeKurve7.TabIndex = 607;
            this.TypeKurve7.Text = "Rett linje";
            this.TypeKurve7.Visible = false;
            this.TypeKurve7.SelectedValueChanged += new System.EventHandler(this.TypeKurve7_Change);
            this.TypeKurve7.MouseEnter += new System.EventHandler(this.TypeKurve7_Enter);
            // 
            // LeddRad7
            // 
            this.LeddRad7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeddRad7.Location = new System.Drawing.Point(337, 158);
            this.LeddRad7.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.LeddRad7.Minimum = new decimal(new int[] {
            180,
            0,
            0,
            0});
            this.LeddRad7.Name = "LeddRad7";
            this.LeddRad7.Size = new System.Drawing.Size(65, 21);
            this.LeddRad7.TabIndex = 605;
            this.LeddRad7.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.LeddRad7.Visible = false;
            // 
            // TypeKurve6
            // 
            this.TypeKurve6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TypeKurve6.FormattingEnabled = true;
            this.TypeKurve6.Items.AddRange(new object[] {
            "Rett linje",
            "Kurve",
            "Overgang"});
            this.TypeKurve6.Location = new System.Drawing.Point(255, 131);
            this.TypeKurve6.Name = "TypeKurve6";
            this.TypeKurve6.Size = new System.Drawing.Size(73, 23);
            this.TypeKurve6.TabIndex = 604;
            this.TypeKurve6.Text = "Rett linje";
            this.TypeKurve6.Visible = false;
            this.TypeKurve6.SelectedValueChanged += new System.EventHandler(this.TypeKurve6_Change);
            this.TypeKurve6.MouseEnter += new System.EventHandler(this.TypeKurve6_Enter);
            // 
            // LeddRad6
            // 
            this.LeddRad6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeddRad6.Location = new System.Drawing.Point(337, 132);
            this.LeddRad6.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.LeddRad6.Minimum = new decimal(new int[] {
            180,
            0,
            0,
            0});
            this.LeddRad6.Name = "LeddRad6";
            this.LeddRad6.Size = new System.Drawing.Size(65, 21);
            this.LeddRad6.TabIndex = 602;
            this.LeddRad6.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.LeddRad6.Visible = false;
            // 
            // TypeKurve5
            // 
            this.TypeKurve5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TypeKurve5.FormattingEnabled = true;
            this.TypeKurve5.Items.AddRange(new object[] {
            "Rett linje",
            "Kurve",
            "Overgang"});
            this.TypeKurve5.Location = new System.Drawing.Point(255, 105);
            this.TypeKurve5.Name = "TypeKurve5";
            this.TypeKurve5.Size = new System.Drawing.Size(73, 23);
            this.TypeKurve5.TabIndex = 601;
            this.TypeKurve5.Text = "Rett linje";
            this.TypeKurve5.Visible = false;
            this.TypeKurve5.SelectedValueChanged += new System.EventHandler(this.TypeKurve5_Change);
            this.TypeKurve5.MouseEnter += new System.EventHandler(this.TypeKurve5_Enter);
            // 
            // LeddRad5
            // 
            this.LeddRad5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeddRad5.Location = new System.Drawing.Point(337, 106);
            this.LeddRad5.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.LeddRad5.Minimum = new decimal(new int[] {
            180,
            0,
            0,
            0});
            this.LeddRad5.Name = "LeddRad5";
            this.LeddRad5.Size = new System.Drawing.Size(65, 21);
            this.LeddRad5.TabIndex = 599;
            this.LeddRad5.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.LeddRad5.Visible = false;
            // 
            // TypeKurve4
            // 
            this.TypeKurve4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TypeKurve4.FormattingEnabled = true;
            this.TypeKurve4.Items.AddRange(new object[] {
            "Rett linje",
            "Kurve",
            "Overgang"});
            this.TypeKurve4.Location = new System.Drawing.Point(255, 80);
            this.TypeKurve4.Name = "TypeKurve4";
            this.TypeKurve4.Size = new System.Drawing.Size(73, 23);
            this.TypeKurve4.TabIndex = 598;
            this.TypeKurve4.Text = "Rett linje";
            this.TypeKurve4.Visible = false;
            this.TypeKurve4.SelectedValueChanged += new System.EventHandler(this.TypeKurve4_Change);
            this.TypeKurve4.MouseEnter += new System.EventHandler(this.TypeKurve4_Enter);
            // 
            // LeddRad4
            // 
            this.LeddRad4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeddRad4.Location = new System.Drawing.Point(337, 81);
            this.LeddRad4.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.LeddRad4.Minimum = new decimal(new int[] {
            180,
            0,
            0,
            0});
            this.LeddRad4.Name = "LeddRad4";
            this.LeddRad4.Size = new System.Drawing.Size(65, 21);
            this.LeddRad4.TabIndex = 596;
            this.LeddRad4.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.LeddRad4.Visible = false;
            // 
            // TypeKurve3
            // 
            this.TypeKurve3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TypeKurve3.FormattingEnabled = true;
            this.TypeKurve3.Items.AddRange(new object[] {
            "Rett linje",
            "Kurve",
            "Overgang"});
            this.TypeKurve3.Location = new System.Drawing.Point(255, 55);
            this.TypeKurve3.Name = "TypeKurve3";
            this.TypeKurve3.Size = new System.Drawing.Size(73, 23);
            this.TypeKurve3.TabIndex = 595;
            this.TypeKurve3.Text = "Rett linje";
            this.TypeKurve3.Visible = false;
            this.TypeKurve3.SelectedValueChanged += new System.EventHandler(this.TypeKurve3_Change);
            this.TypeKurve3.MouseEnter += new System.EventHandler(this.TypeKurve3_Enter);
            // 
            // LeddRad3
            // 
            this.LeddRad3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeddRad3.Location = new System.Drawing.Point(337, 57);
            this.LeddRad3.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.LeddRad3.Minimum = new decimal(new int[] {
            180,
            0,
            0,
            0});
            this.LeddRad3.Name = "LeddRad3";
            this.LeddRad3.Size = new System.Drawing.Size(65, 21);
            this.LeddRad3.TabIndex = 593;
            this.LeddRad3.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.LeddRad3.Visible = false;
            // 
            // TypeKurve2
            // 
            this.TypeKurve2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TypeKurve2.FormattingEnabled = true;
            this.TypeKurve2.Items.AddRange(new object[] {
            "Rett linje",
            "Kurve",
            "Overgang"});
            this.TypeKurve2.Location = new System.Drawing.Point(255, 29);
            this.TypeKurve2.Name = "TypeKurve2";
            this.TypeKurve2.Size = new System.Drawing.Size(73, 23);
            this.TypeKurve2.TabIndex = 592;
            this.TypeKurve2.Text = "Rett linje";
            this.TypeKurve2.Visible = false;
            this.TypeKurve2.SelectedValueChanged += new System.EventHandler(this.TypeKurve2_Change);
            this.TypeKurve2.MouseEnter += new System.EventHandler(this.TypeKurve2_Enter);
            // 
            // LeddRad2
            // 
            this.LeddRad2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeddRad2.Location = new System.Drawing.Point(337, 31);
            this.LeddRad2.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.LeddRad2.Minimum = new decimal(new int[] {
            180,
            0,
            0,
            0});
            this.LeddRad2.Name = "LeddRad2";
            this.LeddRad2.Size = new System.Drawing.Size(65, 21);
            this.LeddRad2.TabIndex = 590;
            this.LeddRad2.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.LeddRad2.Visible = false;
            // 
            // LeddLeng10
            // 
            this.LeddLeng10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeddLeng10.Location = new System.Drawing.Point(195, 243);
            this.LeddLeng10.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.LeddLeng10.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.LeddLeng10.Name = "LeddLeng10";
            this.LeddLeng10.Size = new System.Drawing.Size(50, 21);
            this.LeddLeng10.TabIndex = 578;
            this.LeddLeng10.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.LeddLeng10.Visible = false;
            this.LeddLeng10.ValueChanged += new System.EventHandler(this.LeddLeng_ValueChanged);
            // 
            // LeddLeng9
            // 
            this.LeddLeng9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeddLeng9.Location = new System.Drawing.Point(195, 216);
            this.LeddLeng9.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.LeddLeng9.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.LeddLeng9.Name = "LeddLeng9";
            this.LeddLeng9.Size = new System.Drawing.Size(50, 21);
            this.LeddLeng9.TabIndex = 577;
            this.LeddLeng9.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.LeddLeng9.Visible = false;
            this.LeddLeng9.ValueChanged += new System.EventHandler(this.LeddLeng_ValueChanged);
            // 
            // LeddLeng8
            // 
            this.LeddLeng8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeddLeng8.Location = new System.Drawing.Point(195, 187);
            this.LeddLeng8.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.LeddLeng8.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.LeddLeng8.Name = "LeddLeng8";
            this.LeddLeng8.Size = new System.Drawing.Size(50, 21);
            this.LeddLeng8.TabIndex = 576;
            this.LeddLeng8.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.LeddLeng8.Visible = false;
            this.LeddLeng8.ValueChanged += new System.EventHandler(this.LeddLeng_ValueChanged);
            // 
            // LeddLeng7
            // 
            this.LeddLeng7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeddLeng7.Location = new System.Drawing.Point(195, 158);
            this.LeddLeng7.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.LeddLeng7.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.LeddLeng7.Name = "LeddLeng7";
            this.LeddLeng7.Size = new System.Drawing.Size(50, 21);
            this.LeddLeng7.TabIndex = 575;
            this.LeddLeng7.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.LeddLeng7.Visible = false;
            this.LeddLeng7.ValueChanged += new System.EventHandler(this.LeddLeng_ValueChanged);
            // 
            // LeddLeng6
            // 
            this.LeddLeng6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeddLeng6.Location = new System.Drawing.Point(195, 132);
            this.LeddLeng6.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.LeddLeng6.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.LeddLeng6.Name = "LeddLeng6";
            this.LeddLeng6.Size = new System.Drawing.Size(50, 21);
            this.LeddLeng6.TabIndex = 574;
            this.LeddLeng6.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.LeddLeng6.Visible = false;
            this.LeddLeng6.ValueChanged += new System.EventHandler(this.LeddLeng_ValueChanged);
            // 
            // LeddLeng5
            // 
            this.LeddLeng5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeddLeng5.Location = new System.Drawing.Point(195, 106);
            this.LeddLeng5.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.LeddLeng5.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.LeddLeng5.Name = "LeddLeng5";
            this.LeddLeng5.Size = new System.Drawing.Size(50, 21);
            this.LeddLeng5.TabIndex = 573;
            this.LeddLeng5.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.LeddLeng5.Visible = false;
            this.LeddLeng5.ValueChanged += new System.EventHandler(this.LeddLeng_ValueChanged);
            // 
            // LeddLeng4
            // 
            this.LeddLeng4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeddLeng4.Location = new System.Drawing.Point(195, 81);
            this.LeddLeng4.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.LeddLeng4.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.LeddLeng4.Name = "LeddLeng4";
            this.LeddLeng4.Size = new System.Drawing.Size(50, 21);
            this.LeddLeng4.TabIndex = 572;
            this.LeddLeng4.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.LeddLeng4.Visible = false;
            this.LeddLeng4.ValueChanged += new System.EventHandler(this.LeddLeng_ValueChanged);
            // 
            // LeddLeng3
            // 
            this.LeddLeng3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeddLeng3.Location = new System.Drawing.Point(195, 57);
            this.LeddLeng3.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.LeddLeng3.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.LeddLeng3.Name = "LeddLeng3";
            this.LeddLeng3.Size = new System.Drawing.Size(50, 21);
            this.LeddLeng3.TabIndex = 571;
            this.LeddLeng3.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.LeddLeng3.Visible = false;
            this.LeddLeng3.ValueChanged += new System.EventHandler(this.LeddLeng_ValueChanged);
            // 
            // LeddLeng2
            // 
            this.LeddLeng2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeddLeng2.Location = new System.Drawing.Point(195, 31);
            this.LeddLeng2.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.LeddLeng2.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.LeddLeng2.Name = "LeddLeng2";
            this.LeddLeng2.Size = new System.Drawing.Size(50, 21);
            this.LeddLeng2.TabIndex = 570;
            this.LeddLeng2.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.LeddLeng2.Visible = false;
            this.LeddLeng2.ValueChanged += new System.EventHandler(this.LeddLeng_ValueChanged);
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericUpDown2.Location = new System.Drawing.Point(227, -26);
            this.numericUpDown2.Maximum = new decimal(new int[] {
            1500,
            0,
            0,
            0});
            this.numericUpDown2.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(62, 21);
            this.numericUpDown2.TabIndex = 569;
            this.numericUpDown2.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // LeddLeng1
            // 
            this.LeddLeng1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeddLeng1.Location = new System.Drawing.Point(195, 5);
            this.LeddLeng1.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.LeddLeng1.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.LeddLeng1.Name = "LeddLeng1";
            this.LeddLeng1.Size = new System.Drawing.Size(50, 21);
            this.LeddLeng1.TabIndex = 569;
            this.LeddLeng1.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.LeddLeng1.ValueChanged += new System.EventHandler(this.LeddLeng_ValueChanged);
            // 
            // LeddEnd10
            // 
            this.LeddEnd10.Enabled = false;
            this.LeddEnd10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeddEnd10.Location = new System.Drawing.Point(132, 243);
            this.LeddEnd10.Name = "LeddEnd10";
            this.LeddEnd10.Size = new System.Drawing.Size(53, 21);
            this.LeddEnd10.TabIndex = 285;
            this.LeddEnd10.Text = "100";
            this.LeddEnd10.Visible = false;
            // 
            // LeddStart10
            // 
            this.LeddStart10.Enabled = false;
            this.LeddStart10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeddStart10.Location = new System.Drawing.Point(66, 243);
            this.LeddStart10.Name = "LeddStart10";
            this.LeddStart10.Size = new System.Drawing.Size(56, 21);
            this.LeddStart10.TabIndex = 284;
            this.LeddStart10.Text = "90";
            this.LeddStart10.Visible = false;
            // 
            // lblLedd10
            // 
            this.lblLedd10.AutoSize = true;
            this.lblLedd10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLedd10.Location = new System.Drawing.Point(7, 248);
            this.lblLedd10.Name = "lblLedd10";
            this.lblLedd10.Size = new System.Drawing.Size(52, 15);
            this.lblLedd10.TabIndex = 283;
            this.lblLedd10.Text = "Ledd 10";
            this.lblLedd10.Visible = false;
            // 
            // LeddEnd9
            // 
            this.LeddEnd9.Enabled = false;
            this.LeddEnd9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeddEnd9.Location = new System.Drawing.Point(132, 216);
            this.LeddEnd9.Name = "LeddEnd9";
            this.LeddEnd9.Size = new System.Drawing.Size(53, 21);
            this.LeddEnd9.TabIndex = 278;
            this.LeddEnd9.Text = "90";
            this.LeddEnd9.Visible = false;
            this.LeddEnd9.TextChanged += new System.EventHandler(this.LeddEnd9_Change);
            // 
            // LeddStart9
            // 
            this.LeddStart9.Enabled = false;
            this.LeddStart9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeddStart9.Location = new System.Drawing.Point(66, 216);
            this.LeddStart9.Name = "LeddStart9";
            this.LeddStart9.Size = new System.Drawing.Size(56, 21);
            this.LeddStart9.TabIndex = 277;
            this.LeddStart9.Text = "80";
            this.LeddStart9.Visible = false;
            // 
            // lblLedd9
            // 
            this.lblLedd9.AutoSize = true;
            this.lblLedd9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLedd9.Location = new System.Drawing.Point(7, 221);
            this.lblLedd9.Name = "lblLedd9";
            this.lblLedd9.Size = new System.Drawing.Size(45, 15);
            this.lblLedd9.TabIndex = 276;
            this.lblLedd9.Text = "Ledd 9";
            this.lblLedd9.Visible = false;
            // 
            // LeddEnd8
            // 
            this.LeddEnd8.Enabled = false;
            this.LeddEnd8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeddEnd8.Location = new System.Drawing.Point(132, 187);
            this.LeddEnd8.Name = "LeddEnd8";
            this.LeddEnd8.Size = new System.Drawing.Size(53, 21);
            this.LeddEnd8.TabIndex = 271;
            this.LeddEnd8.Text = "80";
            this.LeddEnd8.Visible = false;
            this.LeddEnd8.TextChanged += new System.EventHandler(this.LeddEnd8_Change);
            // 
            // LeddStart8
            // 
            this.LeddStart8.Enabled = false;
            this.LeddStart8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeddStart8.Location = new System.Drawing.Point(66, 187);
            this.LeddStart8.Name = "LeddStart8";
            this.LeddStart8.Size = new System.Drawing.Size(56, 21);
            this.LeddStart8.TabIndex = 270;
            this.LeddStart8.Text = "70";
            this.LeddStart8.Visible = false;
            // 
            // lblLedd8
            // 
            this.lblLedd8.AutoSize = true;
            this.lblLedd8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLedd8.Location = new System.Drawing.Point(7, 192);
            this.lblLedd8.Name = "lblLedd8";
            this.lblLedd8.Size = new System.Drawing.Size(45, 15);
            this.lblLedd8.TabIndex = 269;
            this.lblLedd8.Text = "Ledd 8";
            this.lblLedd8.Visible = false;
            // 
            // LeddEnd7
            // 
            this.LeddEnd7.Enabled = false;
            this.LeddEnd7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeddEnd7.Location = new System.Drawing.Point(132, 158);
            this.LeddEnd7.Name = "LeddEnd7";
            this.LeddEnd7.Size = new System.Drawing.Size(53, 21);
            this.LeddEnd7.TabIndex = 264;
            this.LeddEnd7.Text = "70";
            this.LeddEnd7.Visible = false;
            this.LeddEnd7.TextChanged += new System.EventHandler(this.LeddEnd7_Change);
            // 
            // LeddStart7
            // 
            this.LeddStart7.Enabled = false;
            this.LeddStart7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeddStart7.Location = new System.Drawing.Point(66, 158);
            this.LeddStart7.Name = "LeddStart7";
            this.LeddStart7.Size = new System.Drawing.Size(56, 21);
            this.LeddStart7.TabIndex = 263;
            this.LeddStart7.Text = "60";
            this.LeddStart7.Visible = false;
            // 
            // lblLedd7
            // 
            this.lblLedd7.AutoSize = true;
            this.lblLedd7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLedd7.Location = new System.Drawing.Point(7, 163);
            this.lblLedd7.Name = "lblLedd7";
            this.lblLedd7.Size = new System.Drawing.Size(45, 15);
            this.lblLedd7.TabIndex = 262;
            this.lblLedd7.Text = "Ledd 7";
            this.lblLedd7.Visible = false;
            // 
            // LeddEnd6
            // 
            this.LeddEnd6.Enabled = false;
            this.LeddEnd6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeddEnd6.Location = new System.Drawing.Point(132, 132);
            this.LeddEnd6.Name = "LeddEnd6";
            this.LeddEnd6.Size = new System.Drawing.Size(53, 21);
            this.LeddEnd6.TabIndex = 257;
            this.LeddEnd6.Text = "60";
            this.LeddEnd6.Visible = false;
            this.LeddEnd6.TextChanged += new System.EventHandler(this.LeddEnd6_Change);
            // 
            // LeddStart6
            // 
            this.LeddStart6.Enabled = false;
            this.LeddStart6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeddStart6.Location = new System.Drawing.Point(66, 132);
            this.LeddStart6.Name = "LeddStart6";
            this.LeddStart6.Size = new System.Drawing.Size(56, 21);
            this.LeddStart6.TabIndex = 256;
            this.LeddStart6.Text = "50";
            this.LeddStart6.Visible = false;
            // 
            // lblLedd6
            // 
            this.lblLedd6.AutoSize = true;
            this.lblLedd6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLedd6.Location = new System.Drawing.Point(7, 137);
            this.lblLedd6.Name = "lblLedd6";
            this.lblLedd6.Size = new System.Drawing.Size(45, 15);
            this.lblLedd6.TabIndex = 255;
            this.lblLedd6.Text = "Ledd 6";
            this.lblLedd6.Visible = false;
            // 
            // LeddEnd5
            // 
            this.LeddEnd5.Enabled = false;
            this.LeddEnd5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeddEnd5.Location = new System.Drawing.Point(132, 106);
            this.LeddEnd5.Name = "LeddEnd5";
            this.LeddEnd5.Size = new System.Drawing.Size(53, 21);
            this.LeddEnd5.TabIndex = 250;
            this.LeddEnd5.Text = "50";
            this.LeddEnd5.Visible = false;
            this.LeddEnd5.TextChanged += new System.EventHandler(this.LeddEnd5_Change);
            // 
            // LeddStart5
            // 
            this.LeddStart5.Enabled = false;
            this.LeddStart5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeddStart5.Location = new System.Drawing.Point(66, 106);
            this.LeddStart5.Name = "LeddStart5";
            this.LeddStart5.Size = new System.Drawing.Size(56, 21);
            this.LeddStart5.TabIndex = 249;
            this.LeddStart5.Text = "40";
            this.LeddStart5.Visible = false;
            // 
            // lblLedd5
            // 
            this.lblLedd5.AutoSize = true;
            this.lblLedd5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLedd5.Location = new System.Drawing.Point(7, 111);
            this.lblLedd5.Name = "lblLedd5";
            this.lblLedd5.Size = new System.Drawing.Size(45, 15);
            this.lblLedd5.TabIndex = 248;
            this.lblLedd5.Text = "Ledd 5";
            this.lblLedd5.Visible = false;
            // 
            // LeddEnd4
            // 
            this.LeddEnd4.Enabled = false;
            this.LeddEnd4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeddEnd4.Location = new System.Drawing.Point(132, 81);
            this.LeddEnd4.Name = "LeddEnd4";
            this.LeddEnd4.Size = new System.Drawing.Size(53, 21);
            this.LeddEnd4.TabIndex = 243;
            this.LeddEnd4.Text = "40";
            this.LeddEnd4.Visible = false;
            this.LeddEnd4.Validated += new System.EventHandler(this.LeddEnd4_Change);
            // 
            // LeddStart4
            // 
            this.LeddStart4.Enabled = false;
            this.LeddStart4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeddStart4.Location = new System.Drawing.Point(66, 81);
            this.LeddStart4.Name = "LeddStart4";
            this.LeddStart4.Size = new System.Drawing.Size(56, 21);
            this.LeddStart4.TabIndex = 242;
            this.LeddStart4.Text = "30";
            this.LeddStart4.Visible = false;
            // 
            // lblLedd4
            // 
            this.lblLedd4.AutoSize = true;
            this.lblLedd4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLedd4.Location = new System.Drawing.Point(7, 86);
            this.lblLedd4.Name = "lblLedd4";
            this.lblLedd4.Size = new System.Drawing.Size(45, 15);
            this.lblLedd4.TabIndex = 241;
            this.lblLedd4.Text = "Ledd 4";
            this.lblLedd4.Visible = false;
            // 
            // LeddEnd3
            // 
            this.LeddEnd3.Enabled = false;
            this.LeddEnd3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeddEnd3.Location = new System.Drawing.Point(132, 57);
            this.LeddEnd3.Name = "LeddEnd3";
            this.LeddEnd3.Size = new System.Drawing.Size(53, 21);
            this.LeddEnd3.TabIndex = 236;
            this.LeddEnd3.Text = "30";
            this.LeddEnd3.Visible = false;
            this.LeddEnd3.Validated += new System.EventHandler(this.LeddEnd3_Change);
            // 
            // LeddStart3
            // 
            this.LeddStart3.Enabled = false;
            this.LeddStart3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeddStart3.Location = new System.Drawing.Point(66, 57);
            this.LeddStart3.Name = "LeddStart3";
            this.LeddStart3.Size = new System.Drawing.Size(56, 21);
            this.LeddStart3.TabIndex = 235;
            this.LeddStart3.Text = "20";
            this.LeddStart3.Visible = false;
            // 
            // lblLedd3
            // 
            this.lblLedd3.AutoSize = true;
            this.lblLedd3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLedd3.Location = new System.Drawing.Point(7, 62);
            this.lblLedd3.Name = "lblLedd3";
            this.lblLedd3.Size = new System.Drawing.Size(45, 15);
            this.lblLedd3.TabIndex = 234;
            this.lblLedd3.Text = "Ledd 3";
            this.lblLedd3.Visible = false;
            // 
            // LeddEnd2
            // 
            this.LeddEnd2.Enabled = false;
            this.LeddEnd2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeddEnd2.Location = new System.Drawing.Point(132, 31);
            this.LeddEnd2.Name = "LeddEnd2";
            this.LeddEnd2.Size = new System.Drawing.Size(53, 21);
            this.LeddEnd2.TabIndex = 229;
            this.LeddEnd2.Text = "20";
            this.LeddEnd2.Visible = false;
            this.LeddEnd2.TextChanged += new System.EventHandler(this.LeddEnd2_Change);
            // 
            // LeddStart2
            // 
            this.LeddStart2.Enabled = false;
            this.LeddStart2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeddStart2.Location = new System.Drawing.Point(66, 31);
            this.LeddStart2.Name = "LeddStart2";
            this.LeddStart2.Size = new System.Drawing.Size(56, 21);
            this.LeddStart2.TabIndex = 228;
            this.LeddStart2.Text = "10";
            this.LeddStart2.Visible = false;
            // 
            // comboBox1
            // 
            this.comboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Rett linje",
            "Kurve"});
            this.comboBox1.Location = new System.Drawing.Point(307, -28);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(92, 23);
            this.comboBox1.TabIndex = 224;
            this.comboBox1.Text = "Rett linje";
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.TypeKurve1_Change);
            // 
            // lblLedd2
            // 
            this.lblLedd2.AutoSize = true;
            this.lblLedd2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLedd2.Location = new System.Drawing.Point(7, 36);
            this.lblLedd2.Name = "lblLedd2";
            this.lblLedd2.Size = new System.Drawing.Size(45, 15);
            this.lblLedd2.TabIndex = 227;
            this.lblLedd2.Text = "Ledd 2";
            this.lblLedd2.Visible = false;
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(148, -26);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(61, 21);
            this.textBox2.TabIndex = 198;
            this.textBox2.Text = "0";
            this.textBox2.TextChanged += new System.EventHandler(this.LeddEnd1_Change);
            // 
            // TypeKurve1
            // 
            this.TypeKurve1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TypeKurve1.FormattingEnabled = true;
            this.TypeKurve1.Items.AddRange(new object[] {
            "Rett linje",
            "Kurve"});
            this.TypeKurve1.Location = new System.Drawing.Point(255, 3);
            this.TypeKurve1.Name = "TypeKurve1";
            this.TypeKurve1.Size = new System.Drawing.Size(73, 23);
            this.TypeKurve1.TabIndex = 224;
            this.TypeKurve1.Text = "Rett linje";
            this.TypeKurve1.SelectedIndexChanged += new System.EventHandler(this.TypeKurve1_Change);
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(70, -26);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(61, 21);
            this.textBox1.TabIndex = 589;
            this.textBox1.Text = "0";
            // 
            // LeddEnd1
            // 
            this.LeddEnd1.Enabled = false;
            this.LeddEnd1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeddEnd1.Location = new System.Drawing.Point(132, 5);
            this.LeddEnd1.Name = "LeddEnd1";
            this.LeddEnd1.Size = new System.Drawing.Size(53, 21);
            this.LeddEnd1.TabIndex = 198;
            this.LeddEnd1.Text = "10";
            this.LeddEnd1.TextChanged += new System.EventHandler(this.LeddEnd1_Change);
            this.LeddEnd1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.LeddEnd1_KeyPress);
            // 
            // LeddStart1
            // 
            this.LeddStart1.Enabled = false;
            this.LeddStart1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeddStart1.Location = new System.Drawing.Point(66, 5);
            this.LeddStart1.Name = "LeddStart1";
            this.LeddStart1.Size = new System.Drawing.Size(56, 21);
            this.LeddStart1.TabIndex = 589;
            this.LeddStart1.Text = "0";
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericUpDown1.Location = new System.Drawing.Point(405, -28);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numericUpDown1.Minimum = new decimal(new int[] {
            180,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(78, 21);
            this.numericUpDown1.TabIndex = 190;
            this.numericUpDown1.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDown1.Visible = false;
            // 
            // lblLedd1
            // 
            this.lblLedd1.AutoSize = true;
            this.lblLedd1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLedd1.Location = new System.Drawing.Point(7, 10);
            this.lblLedd1.Name = "lblLedd1";
            this.lblLedd1.Size = new System.Drawing.Size(45, 15);
            this.lblLedd1.TabIndex = 196;
            this.lblLedd1.Text = "Ledd 1";
            // 
            // LeddRad1
            // 
            this.LeddRad1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeddRad1.Location = new System.Drawing.Point(337, 5);
            this.LeddRad1.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.LeddRad1.Minimum = new decimal(new int[] {
            180,
            0,
            0,
            0});
            this.LeddRad1.Name = "LeddRad1";
            this.LeddRad1.Size = new System.Drawing.Size(65, 21);
            this.LeddRad1.TabIndex = 190;
            this.LeddRad1.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.LeddRad1.Visible = false;
            // 
            // PlotSelector
            // 
            this.PlotSelector.Controls.Add(this.btnLagrePlot);
            this.PlotSelector.Controls.Add(this.nrUpDnSpennNr);
            this.PlotSelector.Controls.Add(this.label9);
            this.PlotSelector.Controls.Add(this.rdBtnVUtbSpan);
            this.PlotSelector.Controls.Add(this.rdBtnVUtbLedPart);
            this.PlotSelector.Controls.Add(this.rdBtnTrase);
            this.PlotSelector.Controls.Add(this.nrUpDnLedpartNr);
            this.PlotSelector.Controls.Add(this.lblLedpartNr);
            this.PlotSelector.Controls.Add(this.btnTrasePlot);
            this.PlotSelector.Location = new System.Drawing.Point(633, 441);
            this.PlotSelector.Name = "PlotSelector";
            this.PlotSelector.Size = new System.Drawing.Size(434, 131);
            this.PlotSelector.TabIndex = 192;
            // 
            // btnLagrePlot
            // 
            this.btnLagrePlot.Enabled = false;
            this.btnLagrePlot.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLagrePlot.Location = new System.Drawing.Point(312, 75);
            this.btnLagrePlot.Margin = new System.Windows.Forms.Padding(2);
            this.btnLagrePlot.Name = "btnLagrePlot";
            this.btnLagrePlot.Size = new System.Drawing.Size(82, 25);
            this.btnLagrePlot.TabIndex = 680;
            this.btnLagrePlot.Text = "Lagre plot";
            this.btnLagrePlot.UseVisualStyleBackColor = true;
            this.btnLagrePlot.Click += new System.EventHandler(this.btnLagrePlot_Click);
            // 
            // nrUpDnSpennNr
            // 
            this.nrUpDnSpennNr.Enabled = false;
            this.nrUpDnSpennNr.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.nrUpDnSpennNr.Location = new System.Drawing.Point(203, 75);
            this.nrUpDnSpennNr.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nrUpDnSpennNr.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nrUpDnSpennNr.Name = "nrUpDnSpennNr";
            this.nrUpDnSpennNr.Size = new System.Drawing.Size(44, 21);
            this.nrUpDnSpennNr.TabIndex = 671;
            this.nrUpDnSpennNr.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(139, 76);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(60, 15);
            this.label9.TabIndex = 670;
            this.label9.Text = "Spenn nr.";
            // 
            // rdBtnVUtbSpan
            // 
            this.rdBtnVUtbSpan.AutoSize = true;
            this.rdBtnVUtbSpan.Enabled = false;
            this.rdBtnVUtbSpan.Location = new System.Drawing.Point(10, 74);
            this.rdBtnVUtbSpan.Name = "rdBtnVUtbSpan";
            this.rdBtnVUtbSpan.Size = new System.Drawing.Size(76, 19);
            this.rdBtnVUtbSpan.TabIndex = 669;
            this.rdBtnVUtbSpan.TabStop = true;
            this.rdBtnVUtbSpan.Text = "To spenn";
            this.rdBtnVUtbSpan.UseVisualStyleBackColor = true;
            this.rdBtnVUtbSpan.CheckedChanged += new System.EventHandler(this.rdBtnVUtbSpan_CheckedChanged);
            // 
            // rdBtnVUtbLedPart
            // 
            this.rdBtnVUtbLedPart.AutoSize = true;
            this.rdBtnVUtbLedPart.Enabled = false;
            this.rdBtnVUtbLedPart.Location = new System.Drawing.Point(10, 47);
            this.rdBtnVUtbLedPart.Name = "rdBtnVUtbLedPart";
            this.rdBtnVUtbLedPart.Size = new System.Drawing.Size(121, 19);
            this.rdBtnVUtbLedPart.TabIndex = 668;
            this.rdBtnVUtbLedPart.Text = "En ½ledningspart";
            this.rdBtnVUtbLedPart.UseVisualStyleBackColor = true;
            this.rdBtnVUtbLedPart.CheckedChanged += new System.EventHandler(this.rdBtnVUtbLedPart_CheckedChanged);
            // 
            // rdBtnTrase
            // 
            this.rdBtnTrase.AutoSize = true;
            this.rdBtnTrase.Checked = true;
            this.rdBtnTrase.Enabled = false;
            this.rdBtnTrase.Location = new System.Drawing.Point(10, 17);
            this.rdBtnTrase.Name = "rdBtnTrase";
            this.rdBtnTrase.Size = new System.Drawing.Size(88, 19);
            this.rdBtnTrase.TabIndex = 667;
            this.rdBtnTrase.TabStop = true;
            this.rdBtnTrase.Text = "Hele trasen";
            this.rdBtnTrase.UseVisualStyleBackColor = true;
            this.rdBtnTrase.CheckedChanged += new System.EventHandler(this.rdBtnTrase_CheckedChanged);
            // 
            // nrUpDnLedpartNr
            // 
            this.nrUpDnLedpartNr.Enabled = false;
            this.nrUpDnLedpartNr.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.nrUpDnLedpartNr.Location = new System.Drawing.Point(203, 47);
            this.nrUpDnLedpartNr.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nrUpDnLedpartNr.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nrUpDnLedpartNr.Name = "nrUpDnLedpartNr";
            this.nrUpDnLedpartNr.Size = new System.Drawing.Size(44, 21);
            this.nrUpDnLedpartNr.TabIndex = 662;
            this.nrUpDnLedpartNr.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nrUpDnLedpartNr.ValueChanged += new System.EventHandler(this.nrUpDnLedpartNr_ValueChanged);
            // 
            // lblLedpartNr
            // 
            this.lblLedpartNr.AutoSize = true;
            this.lblLedpartNr.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLedpartNr.Location = new System.Drawing.Point(139, 48);
            this.lblLedpartNr.Name = "lblLedpartNr";
            this.lblLedpartNr.Size = new System.Drawing.Size(79, 15);
            this.lblLedpartNr.TabIndex = 661;
            this.lblLedpartNr.Text = "½Led.part nr.";
            // 
            // btnTrasePlot
            // 
            this.btnTrasePlot.Enabled = false;
            this.btnTrasePlot.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTrasePlot.Location = new System.Drawing.Point(312, 24);
            this.btnTrasePlot.Name = "btnTrasePlot";
            this.btnTrasePlot.Size = new System.Drawing.Size(82, 27);
            this.btnTrasePlot.TabIndex = 659;
            this.btnTrasePlot.Text = "Vis plot";
            this.btnTrasePlot.UseVisualStyleBackColor = true;
            this.btnTrasePlot.Click += new System.EventHandler(this.btnTrasePlot_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(659, 146);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(119, 24);
            this.label12.TabIndex = 191;
            this.label12.Text = "Ledningspart";
            // 
            // panel4
            // 
            this.panel4.AutoScroll = true;
            this.panel4.Controls.Add(this.btnLeddPart5);
            this.panel4.Controls.Add(this.btnLeddPart4);
            this.panel4.Controls.Add(this.btnLeddPart3);
            this.panel4.Controls.Add(this.btnLeddPart2);
            this.panel4.Controls.Add(this.btnLeddPart1);
            this.panel4.Controls.Add(this.LedPart5LøpRet);
            this.panel4.Controls.Add(this.LedPart4LøpRet);
            this.panel4.Controls.Add(this.LedPart3LøpRet);
            this.panel4.Controls.Add(this.LedPart2LøpRet);
            this.panel4.Controls.Add(this.LedPart1LøpRet);
            this.panel4.Controls.Add(this.LedPart5MaksLeng);
            this.panel4.Controls.Add(this.LedPart4MaksLeng);
            this.panel4.Controls.Add(this.LedPart3MaksLeng);
            this.panel4.Controls.Add(this.LedPart2MaksLeng);
            this.panel4.Controls.Add(this.LedPart1MaksLeng);
            this.panel4.Controls.Add(this.label3);
            this.panel4.Controls.Add(this.LedPart5MaksTall);
            this.panel4.Controls.Add(this.LedPart4MaksTall);
            this.panel4.Controls.Add(this.LedPart3MaksTall);
            this.panel4.Controls.Add(this.LedPart2MaksTall);
            this.panel4.Controls.Add(this.LedPart1MaksTall);
            this.panel4.Controls.Add(this.label2);
            this.panel4.Controls.Add(this.label1);
            this.panel4.Controls.Add(this.LedPart5TallSpn);
            this.panel4.Controls.Add(this.LedPart4TallSpn);
            this.panel4.Controls.Add(this.LedPart3TallSpn);
            this.panel4.Controls.Add(this.LedPart2TallSpn);
            this.panel4.Controls.Add(this.LedPart1TallSpn);
            this.panel4.Controls.Add(this.label5);
            this.panel4.Controls.Add(this.LedPart5_leng);
            this.panel4.Controls.Add(this.LedPart4_leng);
            this.panel4.Controls.Add(this.LedPart3_leng);
            this.panel4.Controls.Add(this.LedPart2_leng);
            this.panel4.Controls.Add(this.LedPart1_leng);
            this.panel4.Controls.Add(this.LedPart5_end);
            this.panel4.Controls.Add(this.LedPart5_start);
            this.panel4.Controls.Add(this.LedPart4_end);
            this.panel4.Controls.Add(this.LedPart4_start);
            this.panel4.Controls.Add(this.LedPart3_end);
            this.panel4.Controls.Add(this.LedPart3_start);
            this.panel4.Controls.Add(this.LedPart2_end);
            this.panel4.Controls.Add(this.LedPart2_start);
            this.panel4.Controls.Add(this.LedPart1_end);
            this.panel4.Controls.Add(this.label40);
            this.panel4.Controls.Add(this.label41);
            this.panel4.Controls.Add(this.LedPart1_start);
            this.panel4.Controls.Add(this.label43);
            this.panel4.Location = new System.Drawing.Point(629, 173);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(447, 208);
            this.panel4.TabIndex = 190;
            // 
            // btnLeddPart5
            // 
            this.btnLeddPart5.Enabled = false;
            this.btnLeddPart5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLeddPart5.Location = new System.Drawing.Point(7, 171);
            this.btnLeddPart5.Margin = new System.Windows.Forms.Padding(0);
            this.btnLeddPart5.Name = "btnLeddPart5";
            this.btnLeddPart5.Size = new System.Drawing.Size(71, 29);
            this.btnLeddPart5.TabIndex = 678;
            this.btnLeddPart5.Text = "½Led.part 5";
            this.btnLeddPart5.UseVisualStyleBackColor = true;
            this.btnLeddPart5.Click += new System.EventHandler(this.btnLeddPart5_Click);
            // 
            // btnLeddPart4
            // 
            this.btnLeddPart4.Enabled = false;
            this.btnLeddPart4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLeddPart4.Location = new System.Drawing.Point(7, 136);
            this.btnLeddPart4.Margin = new System.Windows.Forms.Padding(0);
            this.btnLeddPart4.Name = "btnLeddPart4";
            this.btnLeddPart4.Size = new System.Drawing.Size(71, 29);
            this.btnLeddPart4.TabIndex = 677;
            this.btnLeddPart4.Text = "½Led.part 4";
            this.btnLeddPart4.UseVisualStyleBackColor = true;
            this.btnLeddPart4.Click += new System.EventHandler(this.btnLeddPart4_Click);
            // 
            // btnLeddPart3
            // 
            this.btnLeddPart3.Enabled = false;
            this.btnLeddPart3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLeddPart3.Location = new System.Drawing.Point(7, 101);
            this.btnLeddPart3.Margin = new System.Windows.Forms.Padding(0);
            this.btnLeddPart3.Name = "btnLeddPart3";
            this.btnLeddPart3.Size = new System.Drawing.Size(71, 29);
            this.btnLeddPart3.TabIndex = 676;
            this.btnLeddPart3.Text = "½Led.part 3";
            this.btnLeddPart3.UseVisualStyleBackColor = true;
            this.btnLeddPart3.Click += new System.EventHandler(this.btnLeddPart3_Click);
            // 
            // btnLeddPart2
            // 
            this.btnLeddPart2.Enabled = false;
            this.btnLeddPart2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLeddPart2.Location = new System.Drawing.Point(7, 67);
            this.btnLeddPart2.Margin = new System.Windows.Forms.Padding(0);
            this.btnLeddPart2.Name = "btnLeddPart2";
            this.btnLeddPart2.Size = new System.Drawing.Size(71, 29);
            this.btnLeddPart2.TabIndex = 675;
            this.btnLeddPart2.Text = "½Led.part 2";
            this.btnLeddPart2.UseVisualStyleBackColor = true;
            this.btnLeddPart2.Click += new System.EventHandler(this.btnLeddPart2_Click);
            // 
            // btnLeddPart1
            // 
            this.btnLeddPart1.Enabled = false;
            this.btnLeddPart1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLeddPart1.Location = new System.Drawing.Point(7, 31);
            this.btnLeddPart1.Margin = new System.Windows.Forms.Padding(0);
            this.btnLeddPart1.Name = "btnLeddPart1";
            this.btnLeddPart1.Size = new System.Drawing.Size(71, 29);
            this.btnLeddPart1.TabIndex = 666;
            this.btnLeddPart1.Text = "½Led.part 1";
            this.btnLeddPart1.UseVisualStyleBackColor = true;
            this.btnLeddPart1.Click += new System.EventHandler(this.btnLeddPart1_Click);
            // 
            // LedPart5LøpRet
            // 
            this.LedPart5LøpRet.Enabled = false;
            this.LedPart5LøpRet.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LedPart5LøpRet.FormattingEnabled = true;
            this.LedPart5LøpRet.Items.AddRange(new object[] {
            "|→Ͽ",
            "Ͼ←|"});
            this.LedPart5LøpRet.Location = new System.Drawing.Point(84, 175);
            this.LedPart5LøpRet.Name = "LedPart5LøpRet";
            this.LedPart5LøpRet.Size = new System.Drawing.Size(49, 23);
            this.LedPart5LøpRet.TabIndex = 674;
            this.LedPart5LøpRet.Text = "|→Ͽ";
            // 
            // LedPart4LøpRet
            // 
            this.LedPart4LøpRet.Enabled = false;
            this.LedPart4LøpRet.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LedPart4LøpRet.FormattingEnabled = true;
            this.LedPart4LøpRet.Items.AddRange(new object[] {
            "|→Ͽ",
            "Ͼ←|"});
            this.LedPart4LøpRet.Location = new System.Drawing.Point(84, 140);
            this.LedPart4LøpRet.Name = "LedPart4LøpRet";
            this.LedPart4LøpRet.Size = new System.Drawing.Size(49, 23);
            this.LedPart4LøpRet.TabIndex = 673;
            this.LedPart4LøpRet.Text = "Ͼ←|";
            // 
            // LedPart3LøpRet
            // 
            this.LedPart3LøpRet.Enabled = false;
            this.LedPart3LøpRet.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LedPart3LøpRet.FormattingEnabled = true;
            this.LedPart3LøpRet.Items.AddRange(new object[] {
            "|→Ͽ",
            "Ͼ←|"});
            this.LedPart3LøpRet.Location = new System.Drawing.Point(84, 105);
            this.LedPart3LøpRet.Name = "LedPart3LøpRet";
            this.LedPart3LøpRet.Size = new System.Drawing.Size(49, 23);
            this.LedPart3LøpRet.TabIndex = 672;
            this.LedPart3LøpRet.Text = "|→Ͽ";
            // 
            // LedPart2LøpRet
            // 
            this.LedPart2LøpRet.Enabled = false;
            this.LedPart2LøpRet.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LedPart2LøpRet.FormattingEnabled = true;
            this.LedPart2LøpRet.Items.AddRange(new object[] {
            "|→Ͽ",
            "Ͼ←|"});
            this.LedPart2LøpRet.Location = new System.Drawing.Point(84, 68);
            this.LedPart2LøpRet.Name = "LedPart2LøpRet";
            this.LedPart2LøpRet.Size = new System.Drawing.Size(49, 23);
            this.LedPart2LøpRet.TabIndex = 671;
            this.LedPart2LøpRet.Text = "Ͼ←|";
            // 
            // LedPart1LøpRet
            // 
            this.LedPart1LøpRet.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LedPart1LøpRet.FormattingEnabled = true;
            this.LedPart1LøpRet.Items.AddRange(new object[] {
            "|→Ͽ",
            "Ͼ←|"});
            this.LedPart1LøpRet.Location = new System.Drawing.Point(84, 34);
            this.LedPart1LøpRet.Name = "LedPart1LøpRet";
            this.LedPart1LøpRet.Size = new System.Drawing.Size(49, 23);
            this.LedPart1LøpRet.TabIndex = 225;
            this.LedPart1LøpRet.Text = "|→Ͽ";
            this.LedPart1LøpRet.TextChanged += new System.EventHandler(this.LedPart1LøpRet_TextChanged);
            // 
            // LedPart5MaksLeng
            // 
            this.LedPart5MaksLeng.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LedPart5MaksLeng.Location = new System.Drawing.Point(380, 173);
            this.LedPart5MaksLeng.Maximum = new decimal(new int[] {
            1500,
            0,
            0,
            0});
            this.LedPart5MaksLeng.Minimum = new decimal(new int[] {
            300,
            0,
            0,
            0});
            this.LedPart5MaksLeng.Name = "LedPart5MaksLeng";
            this.LedPart5MaksLeng.Size = new System.Drawing.Size(50, 22);
            this.LedPart5MaksLeng.TabIndex = 670;
            this.LedPart5MaksLeng.Value = new decimal(new int[] {
            750,
            0,
            0,
            0});
            // 
            // LedPart4MaksLeng
            // 
            this.LedPart4MaksLeng.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LedPart4MaksLeng.Location = new System.Drawing.Point(380, 139);
            this.LedPart4MaksLeng.Maximum = new decimal(new int[] {
            1500,
            0,
            0,
            0});
            this.LedPart4MaksLeng.Minimum = new decimal(new int[] {
            300,
            0,
            0,
            0});
            this.LedPart4MaksLeng.Name = "LedPart4MaksLeng";
            this.LedPart4MaksLeng.Size = new System.Drawing.Size(50, 22);
            this.LedPart4MaksLeng.TabIndex = 669;
            this.LedPart4MaksLeng.Value = new decimal(new int[] {
            750,
            0,
            0,
            0});
            // 
            // LedPart3MaksLeng
            // 
            this.LedPart3MaksLeng.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LedPart3MaksLeng.Location = new System.Drawing.Point(380, 104);
            this.LedPart3MaksLeng.Maximum = new decimal(new int[] {
            1500,
            0,
            0,
            0});
            this.LedPart3MaksLeng.Minimum = new decimal(new int[] {
            300,
            0,
            0,
            0});
            this.LedPart3MaksLeng.Name = "LedPart3MaksLeng";
            this.LedPart3MaksLeng.Size = new System.Drawing.Size(50, 22);
            this.LedPart3MaksLeng.TabIndex = 668;
            this.LedPart3MaksLeng.Value = new decimal(new int[] {
            750,
            0,
            0,
            0});
            // 
            // LedPart2MaksLeng
            // 
            this.LedPart2MaksLeng.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LedPart2MaksLeng.Location = new System.Drawing.Point(380, 69);
            this.LedPart2MaksLeng.Maximum = new decimal(new int[] {
            1500,
            0,
            0,
            0});
            this.LedPart2MaksLeng.Minimum = new decimal(new int[] {
            300,
            0,
            0,
            0});
            this.LedPart2MaksLeng.Name = "LedPart2MaksLeng";
            this.LedPart2MaksLeng.Size = new System.Drawing.Size(50, 22);
            this.LedPart2MaksLeng.TabIndex = 667;
            this.LedPart2MaksLeng.Value = new decimal(new int[] {
            750,
            0,
            0,
            0});
            // 
            // LedPart1MaksLeng
            // 
            this.LedPart1MaksLeng.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LedPart1MaksLeng.Location = new System.Drawing.Point(380, 34);
            this.LedPart1MaksLeng.Maximum = new decimal(new int[] {
            1500,
            0,
            0,
            0});
            this.LedPart1MaksLeng.Minimum = new decimal(new int[] {
            300,
            0,
            0,
            0});
            this.LedPart1MaksLeng.Name = "LedPart1MaksLeng";
            this.LedPart1MaksLeng.Size = new System.Drawing.Size(50, 22);
            this.LedPart1MaksLeng.TabIndex = 666;
            this.LedPart1MaksLeng.Value = new decimal(new int[] {
            750,
            0,
            0,
            0});
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(383, 1);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 30);
            this.label3.TabIndex = 665;
            this.label3.Text = "Maks\r\nlengde";
            // 
            // LedPart5MaksTall
            // 
            this.LedPart5MaksTall.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LedPart5MaksTall.Location = new System.Drawing.Point(330, 173);
            this.LedPart5MaksTall.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.LedPart5MaksTall.Minimum = new decimal(new int[] {
            6,
            0,
            0,
            0});
            this.LedPart5MaksTall.Name = "LedPart5MaksTall";
            this.LedPart5MaksTall.Size = new System.Drawing.Size(41, 22);
            this.LedPart5MaksTall.TabIndex = 664;
            this.LedPart5MaksTall.Value = new decimal(new int[] {
            12,
            0,
            0,
            0});
            // 
            // LedPart4MaksTall
            // 
            this.LedPart4MaksTall.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LedPart4MaksTall.Location = new System.Drawing.Point(330, 139);
            this.LedPart4MaksTall.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.LedPart4MaksTall.Minimum = new decimal(new int[] {
            6,
            0,
            0,
            0});
            this.LedPart4MaksTall.Name = "LedPart4MaksTall";
            this.LedPart4MaksTall.Size = new System.Drawing.Size(41, 22);
            this.LedPart4MaksTall.TabIndex = 663;
            this.LedPart4MaksTall.Value = new decimal(new int[] {
            12,
            0,
            0,
            0});
            // 
            // LedPart3MaksTall
            // 
            this.LedPart3MaksTall.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LedPart3MaksTall.Location = new System.Drawing.Point(330, 104);
            this.LedPart3MaksTall.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.LedPart3MaksTall.Minimum = new decimal(new int[] {
            6,
            0,
            0,
            0});
            this.LedPart3MaksTall.Name = "LedPart3MaksTall";
            this.LedPart3MaksTall.Size = new System.Drawing.Size(41, 22);
            this.LedPart3MaksTall.TabIndex = 662;
            this.LedPart3MaksTall.Value = new decimal(new int[] {
            12,
            0,
            0,
            0});
            // 
            // LedPart2MaksTall
            // 
            this.LedPart2MaksTall.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LedPart2MaksTall.Location = new System.Drawing.Point(330, 69);
            this.LedPart2MaksTall.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.LedPart2MaksTall.Minimum = new decimal(new int[] {
            6,
            0,
            0,
            0});
            this.LedPart2MaksTall.Name = "LedPart2MaksTall";
            this.LedPart2MaksTall.Size = new System.Drawing.Size(41, 22);
            this.LedPart2MaksTall.TabIndex = 661;
            this.LedPart2MaksTall.Value = new decimal(new int[] {
            12,
            0,
            0,
            0});
            // 
            // LedPart1MaksTall
            // 
            this.LedPart1MaksTall.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LedPart1MaksTall.Location = new System.Drawing.Point(330, 34);
            this.LedPart1MaksTall.Maximum = new decimal(new int[] {
            24,
            0,
            0,
            0});
            this.LedPart1MaksTall.Minimum = new decimal(new int[] {
            6,
            0,
            0,
            0});
            this.LedPart1MaksTall.Name = "LedPart1MaksTall";
            this.LedPart1MaksTall.Size = new System.Drawing.Size(41, 22);
            this.LedPart1MaksTall.TabIndex = 660;
            this.LedPart1MaksTall.Value = new decimal(new int[] {
            12,
            0,
            0,
            0});
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(338, 1);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 30);
            this.label2.TabIndex = 659;
            this.label2.Text = "Maks\r\nAntall";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(79, 2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 30);
            this.label1.TabIndex = 658;
            this.label1.Text = "Løp\r\nretning";
            // 
            // LedPart5TallSpn
            // 
            this.LedPart5TallSpn.Enabled = false;
            this.LedPart5TallSpn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LedPart5TallSpn.Location = new System.Drawing.Point(295, 174);
            this.LedPart5TallSpn.Name = "LedPart5TallSpn";
            this.LedPart5TallSpn.ReadOnly = true;
            this.LedPart5TallSpn.Size = new System.Drawing.Size(26, 22);
            this.LedPart5TallSpn.TabIndex = 162;
            // 
            // LedPart4TallSpn
            // 
            this.LedPart4TallSpn.Enabled = false;
            this.LedPart4TallSpn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LedPart4TallSpn.Location = new System.Drawing.Point(295, 139);
            this.LedPart4TallSpn.Name = "LedPart4TallSpn";
            this.LedPart4TallSpn.ReadOnly = true;
            this.LedPart4TallSpn.Size = new System.Drawing.Size(26, 22);
            this.LedPart4TallSpn.TabIndex = 161;
            // 
            // LedPart3TallSpn
            // 
            this.LedPart3TallSpn.Enabled = false;
            this.LedPart3TallSpn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LedPart3TallSpn.Location = new System.Drawing.Point(295, 104);
            this.LedPart3TallSpn.Name = "LedPart3TallSpn";
            this.LedPart3TallSpn.ReadOnly = true;
            this.LedPart3TallSpn.Size = new System.Drawing.Size(26, 22);
            this.LedPart3TallSpn.TabIndex = 160;
            // 
            // LedPart2TallSpn
            // 
            this.LedPart2TallSpn.Enabled = false;
            this.LedPart2TallSpn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LedPart2TallSpn.Location = new System.Drawing.Point(295, 69);
            this.LedPart2TallSpn.Name = "LedPart2TallSpn";
            this.LedPart2TallSpn.ReadOnly = true;
            this.LedPart2TallSpn.Size = new System.Drawing.Size(26, 22);
            this.LedPart2TallSpn.TabIndex = 159;
            // 
            // LedPart1TallSpn
            // 
            this.LedPart1TallSpn.Enabled = false;
            this.LedPart1TallSpn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LedPart1TallSpn.Location = new System.Drawing.Point(295, 34);
            this.LedPart1TallSpn.Name = "LedPart1TallSpn";
            this.LedPart1TallSpn.ReadOnly = true;
            this.LedPart1TallSpn.Size = new System.Drawing.Size(26, 22);
            this.LedPart1TallSpn.TabIndex = 158;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(291, 1);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 30);
            this.label5.TabIndex = 157;
            this.label5.Text = "Antall\r\nSpenn";
            // 
            // LedPart5_leng
            // 
            this.LedPart5_leng.Enabled = false;
            this.LedPart5_leng.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LedPart5_leng.Location = new System.Drawing.Point(249, 174);
            this.LedPart5_leng.Name = "LedPart5_leng";
            this.LedPart5_leng.Size = new System.Drawing.Size(37, 22);
            this.LedPart5_leng.TabIndex = 156;
            // 
            // LedPart4_leng
            // 
            this.LedPart4_leng.Enabled = false;
            this.LedPart4_leng.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LedPart4_leng.Location = new System.Drawing.Point(249, 139);
            this.LedPart4_leng.Name = "LedPart4_leng";
            this.LedPart4_leng.Size = new System.Drawing.Size(37, 22);
            this.LedPart4_leng.TabIndex = 155;
            // 
            // LedPart3_leng
            // 
            this.LedPart3_leng.Enabled = false;
            this.LedPart3_leng.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LedPart3_leng.Location = new System.Drawing.Point(249, 104);
            this.LedPart3_leng.Name = "LedPart3_leng";
            this.LedPart3_leng.Size = new System.Drawing.Size(37, 22);
            this.LedPart3_leng.TabIndex = 154;
            // 
            // LedPart2_leng
            // 
            this.LedPart2_leng.Enabled = false;
            this.LedPart2_leng.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LedPart2_leng.Location = new System.Drawing.Point(249, 69);
            this.LedPart2_leng.Name = "LedPart2_leng";
            this.LedPart2_leng.Size = new System.Drawing.Size(37, 22);
            this.LedPart2_leng.TabIndex = 153;
            // 
            // LedPart1_leng
            // 
            this.LedPart1_leng.Enabled = false;
            this.LedPart1_leng.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LedPart1_leng.Location = new System.Drawing.Point(249, 34);
            this.LedPart1_leng.Name = "LedPart1_leng";
            this.LedPart1_leng.Size = new System.Drawing.Size(37, 22);
            this.LedPart1_leng.TabIndex = 152;
            // 
            // LedPart5_end
            // 
            this.LedPart5_end.Enabled = false;
            this.LedPart5_end.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LedPart5_end.Location = new System.Drawing.Point(193, 174);
            this.LedPart5_end.Name = "LedPart5_end";
            this.LedPart5_end.Size = new System.Drawing.Size(47, 22);
            this.LedPart5_end.TabIndex = 148;
            // 
            // LedPart5_start
            // 
            this.LedPart5_start.Enabled = false;
            this.LedPart5_start.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LedPart5_start.Location = new System.Drawing.Point(139, 175);
            this.LedPart5_start.Name = "LedPart5_start";
            this.LedPart5_start.Size = new System.Drawing.Size(47, 22);
            this.LedPart5_start.TabIndex = 147;
            // 
            // LedPart4_end
            // 
            this.LedPart4_end.Enabled = false;
            this.LedPart4_end.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LedPart4_end.Location = new System.Drawing.Point(193, 139);
            this.LedPart4_end.Name = "LedPart4_end";
            this.LedPart4_end.Size = new System.Drawing.Size(47, 22);
            this.LedPart4_end.TabIndex = 145;
            // 
            // LedPart4_start
            // 
            this.LedPart4_start.Enabled = false;
            this.LedPart4_start.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LedPart4_start.Location = new System.Drawing.Point(139, 140);
            this.LedPart4_start.Name = "LedPart4_start";
            this.LedPart4_start.Size = new System.Drawing.Size(47, 22);
            this.LedPart4_start.TabIndex = 144;
            // 
            // LedPart3_end
            // 
            this.LedPart3_end.Enabled = false;
            this.LedPart3_end.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LedPart3_end.Location = new System.Drawing.Point(193, 104);
            this.LedPart3_end.Name = "LedPart3_end";
            this.LedPart3_end.Size = new System.Drawing.Size(47, 22);
            this.LedPart3_end.TabIndex = 142;
            // 
            // LedPart3_start
            // 
            this.LedPart3_start.Enabled = false;
            this.LedPart3_start.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LedPart3_start.Location = new System.Drawing.Point(139, 105);
            this.LedPart3_start.Name = "LedPart3_start";
            this.LedPart3_start.Size = new System.Drawing.Size(47, 22);
            this.LedPart3_start.TabIndex = 141;
            // 
            // LedPart2_end
            // 
            this.LedPart2_end.Enabled = false;
            this.LedPart2_end.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LedPart2_end.Location = new System.Drawing.Point(193, 69);
            this.LedPart2_end.Name = "LedPart2_end";
            this.LedPart2_end.Size = new System.Drawing.Size(47, 22);
            this.LedPart2_end.TabIndex = 139;
            // 
            // LedPart2_start
            // 
            this.LedPart2_start.Enabled = false;
            this.LedPart2_start.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LedPart2_start.Location = new System.Drawing.Point(139, 70);
            this.LedPart2_start.Name = "LedPart2_start";
            this.LedPart2_start.Size = new System.Drawing.Size(47, 22);
            this.LedPart2_start.TabIndex = 138;
            // 
            // LedPart1_end
            // 
            this.LedPart1_end.Enabled = false;
            this.LedPart1_end.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LedPart1_end.Location = new System.Drawing.Point(193, 34);
            this.LedPart1_end.Name = "LedPart1_end";
            this.LedPart1_end.Size = new System.Drawing.Size(47, 22);
            this.LedPart1_end.TabIndex = 136;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(203, 12);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(32, 16);
            this.label40.TabIndex = 135;
            this.label40.Text = "End";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(148, 12);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(35, 16);
            this.label41.TabIndex = 134;
            this.label41.Text = "Start";
            // 
            // LedPart1_start
            // 
            this.LedPart1_start.Enabled = false;
            this.LedPart1_start.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LedPart1_start.Location = new System.Drawing.Point(139, 35);
            this.LedPart1_start.Name = "LedPart1_start";
            this.LedPart1_start.Size = new System.Drawing.Size(47, 22);
            this.LedPart1_start.TabIndex = 133;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(264, 12);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(15, 16);
            this.label43.TabIndex = 131;
            this.label43.Text = "L";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(479, 244);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(66, 15);
            this.label31.TabIndex = 139;
            this.label31.Text = "Radius [m]";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(286, 245);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(49, 15);
            this.label21.TabIndex = 102;
            this.label21.Text = "End [m]";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(400, 244);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(65, 15);
            this.label30.TabIndex = 102;
            this.label30.Text = "Type kurve";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(218, 245);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(52, 15);
            this.label20.TabIndex = 102;
            this.label20.Text = "Start [m]";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(551, 245);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(65, 15);
            this.label13.TabIndex = 90;
            this.label13.Text = "Kurve retn.";
            // 
            // lblKurveLengde
            // 
            this.lblKurveLengde.AutoSize = true;
            this.lblKurveLengde.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKurveLengde.Location = new System.Drawing.Point(347, 244);
            this.lblKurveLengde.Name = "lblKurveLengde";
            this.lblKurveLengde.Size = new System.Drawing.Size(34, 15);
            this.lblKurveLengde.TabIndex = 87;
            this.lblKurveLengde.Text = "L [m]";
            // 
            // lblTraseSammenstilling
            // 
            this.lblTraseSammenstilling.AutoSize = true;
            this.lblTraseSammenstilling.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTraseSammenstilling.Location = new System.Drawing.Point(147, 179);
            this.lblTraseSammenstilling.Name = "lblTraseSammenstilling";
            this.lblTraseSammenstilling.Size = new System.Drawing.Size(58, 24);
            this.lblTraseSammenstilling.TabIndex = 84;
            this.lblTraseSammenstilling.Text = "Trase";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.LightSteelBlue;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.numUpDnStrekHast);
            this.panel2.Controls.Add(this.btnLagreProsjektInfo);
            this.panel2.Controls.Add(this.btnHentProsjektInfo);
            this.panel2.Controls.Add(this.lblEksportmappe);
            this.panel2.Controls.Add(this.btnExportmappe);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.txtSluttpkt);
            this.panel2.Controls.Add(this.lblToMast);
            this.panel2.Controls.Add(this.lblFromMast);
            this.panel2.Controls.Add(this.txtUtfortdato);
            this.panel2.Controls.Add(this.txtUtfortav);
            this.panel2.Controls.Add(this.txtStartpkt);
            this.panel2.Controls.Add(this.txtProjectNumber);
            this.panel2.Controls.Add(this.txtProjectName);
            this.panel2.Controls.Add(this.lblDateOfDesign);
            this.panel2.Controls.Add(this.lblNameOfDesigner);
            this.panel2.Controls.Add(this.lblSpanLocation);
            this.panel2.Controls.Add(this.lblProjectNo);
            this.panel2.Controls.Add(this.lblProjectName);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Location = new System.Drawing.Point(6, 6);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(958, 132);
            this.panel2.TabIndex = 11;
            // 
            // numUpDnStrekHast
            // 
            this.numUpDnStrekHast.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.numUpDnStrekHast.Location = new System.Drawing.Point(565, 100);
            this.numUpDnStrekHast.Maximum = new decimal(new int[] {
            250,
            0,
            0,
            0});
            this.numUpDnStrekHast.Minimum = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.numUpDnStrekHast.Name = "numUpDnStrekHast";
            this.numUpDnStrekHast.Size = new System.Drawing.Size(44, 21);
            this.numUpDnStrekHast.TabIndex = 664;
            this.numUpDnStrekHast.Value = new decimal(new int[] {
            250,
            0,
            0,
            0});
            // 
            // btnLagreProsjektInfo
            // 
            this.btnLagreProsjektInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLagreProsjektInfo.Location = new System.Drawing.Point(756, 1);
            this.btnLagreProsjektInfo.Margin = new System.Windows.Forms.Padding(0);
            this.btnLagreProsjektInfo.Name = "btnLagreProsjektInfo";
            this.btnLagreProsjektInfo.Size = new System.Drawing.Size(92, 34);
            this.btnLagreProsjektInfo.TabIndex = 663;
            this.btnLagreProsjektInfo.Text = "Lagre prosjekt info.";
            this.btnLagreProsjektInfo.UseVisualStyleBackColor = true;
            this.btnLagreProsjektInfo.Click += new System.EventHandler(this.btnLagreProsjektInfo_Click);
            // 
            // btnHentProsjektInfo
            // 
            this.btnHentProsjektInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHentProsjektInfo.Location = new System.Drawing.Point(216, 1);
            this.btnHentProsjektInfo.Margin = new System.Windows.Forms.Padding(0);
            this.btnHentProsjektInfo.Name = "btnHentProsjektInfo";
            this.btnHentProsjektInfo.Size = new System.Drawing.Size(92, 34);
            this.btnHentProsjektInfo.TabIndex = 662;
            this.btnHentProsjektInfo.Text = "Hent prosjekt info.";
            this.btnHentProsjektInfo.UseVisualStyleBackColor = true;
            this.btnHentProsjektInfo.Click += new System.EventHandler(this.btnHentProsjektInfo_Click);
            // 
            // lblEksportmappe
            // 
            this.lblEksportmappe.AutoSize = true;
            this.lblEksportmappe.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEksportmappe.Location = new System.Drawing.Point(549, 13);
            this.lblEksportmappe.Name = "lblEksportmappe";
            this.lblEksportmappe.Size = new System.Drawing.Size(154, 15);
            this.lblEksportmappe.TabIndex = 661;
            this.lblEksportmappe.Text = "Mappe er ikke velget enda!";
            // 
            // btnExportmappe
            // 
            this.btnExportmappe.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExportmappe.Location = new System.Drawing.Point(444, 1);
            this.btnExportmappe.Margin = new System.Windows.Forms.Padding(0);
            this.btnExportmappe.Name = "btnExportmappe";
            this.btnExportmappe.Size = new System.Drawing.Size(97, 34);
            this.btnExportmappe.TabIndex = 660;
            this.btnExportmappe.Text = "Velg mappe for data lagring.";
            this.btnExportmappe.UseVisualStyleBackColor = true;
            this.btnExportmappe.Click += new System.EventHandler(this.btnExportmappe_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(484, 92);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(66, 34);
            this.label10.TabIndex = 191;
            this.label10.Text = "   Strek. \r\nhastighet";
            // 
            // txtSluttpkt
            // 
            this.txtSluttpkt.Location = new System.Drawing.Point(336, 97);
            this.txtSluttpkt.Name = "txtSluttpkt";
            this.txtSluttpkt.Size = new System.Drawing.Size(110, 21);
            this.txtSluttpkt.TabIndex = 36;
            // 
            // lblToMast
            // 
            this.lblToMast.AutoSize = true;
            this.lblToMast.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblToMast.Location = new System.Drawing.Point(276, 103);
            this.lblToMast.Name = "lblToMast";
            this.lblToMast.Size = new System.Drawing.Size(63, 17);
            this.lblToMast.TabIndex = 35;
            this.lblToMast.Text = "Slutt pkt:";
            // 
            // lblFromMast
            // 
            this.lblFromMast.AutoSize = true;
            this.lblFromMast.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFromMast.Location = new System.Drawing.Point(97, 102);
            this.lblFromMast.Name = "lblFromMast";
            this.lblFromMast.Size = new System.Drawing.Size(65, 17);
            this.lblFromMast.TabIndex = 35;
            this.lblFromMast.Text = "Start pkt:";
            // 
            // txtUtfortdato
            // 
            this.txtUtfortdato.Location = new System.Drawing.Point(565, 68);
            this.txtUtfortdato.Name = "txtUtfortdato";
            this.txtUtfortdato.Size = new System.Drawing.Size(283, 21);
            this.txtUtfortdato.TabIndex = 34;
            // 
            // txtUtfortav
            // 
            this.txtUtfortav.Location = new System.Drawing.Point(565, 38);
            this.txtUtfortav.Name = "txtUtfortav";
            this.txtUtfortav.Size = new System.Drawing.Size(283, 21);
            this.txtUtfortav.TabIndex = 34;
            // 
            // txtStartpkt
            // 
            this.txtStartpkt.Location = new System.Drawing.Point(164, 97);
            this.txtStartpkt.Name = "txtStartpkt";
            this.txtStartpkt.Size = new System.Drawing.Size(113, 21);
            this.txtStartpkt.TabIndex = 34;
            // 
            // txtProjectNumber
            // 
            this.txtProjectNumber.Location = new System.Drawing.Point(163, 65);
            this.txtProjectNumber.Name = "txtProjectNumber";
            this.txtProjectNumber.Size = new System.Drawing.Size(283, 21);
            this.txtProjectNumber.TabIndex = 34;
            // 
            // txtProjectName
            // 
            this.txtProjectName.Location = new System.Drawing.Point(163, 36);
            this.txtProjectName.Name = "txtProjectName";
            this.txtProjectName.Size = new System.Drawing.Size(283, 21);
            this.txtProjectName.TabIndex = 33;
            // 
            // lblDateOfDesign
            // 
            this.lblDateOfDesign.AutoSize = true;
            this.lblDateOfDesign.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDateOfDesign.Location = new System.Drawing.Point(485, 69);
            this.lblDateOfDesign.Name = "lblDateOfDesign";
            this.lblDateOfDesign.Size = new System.Drawing.Size(79, 17);
            this.lblDateOfDesign.TabIndex = 14;
            this.lblDateOfDesign.Text = "Utført dato:";
            // 
            // lblNameOfDesigner
            // 
            this.lblNameOfDesigner.AutoSize = true;
            this.lblNameOfDesigner.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNameOfDesigner.Location = new System.Drawing.Point(485, 38);
            this.lblNameOfDesigner.Name = "lblNameOfDesigner";
            this.lblNameOfDesigner.Size = new System.Drawing.Size(66, 17);
            this.lblNameOfDesigner.TabIndex = 14;
            this.lblNameOfDesigner.Text = "Utført av:";
            // 
            // lblSpanLocation
            // 
            this.lblSpanLocation.AutoSize = true;
            this.lblSpanLocation.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSpanLocation.Location = new System.Drawing.Point(3, 92);
            this.lblSpanLocation.Name = "lblSpanLocation";
            this.lblSpanLocation.Size = new System.Drawing.Size(84, 34);
            this.lblSpanLocation.TabIndex = 13;
            this.lblSpanLocation.Text = "Start og slut\r\npunkter:";
            // 
            // lblProjectNo
            // 
            this.lblProjectNo.AutoSize = true;
            this.lblProjectNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjectNo.Location = new System.Drawing.Point(3, 63);
            this.lblProjectNo.Name = "lblProjectNo";
            this.lblProjectNo.Size = new System.Drawing.Size(68, 17);
            this.lblProjectNo.TabIndex = 12;
            this.lblProjectNo.Text = "Strek. Nr.";
            // 
            // lblProjectName
            // 
            this.lblProjectName.AutoSize = true;
            this.lblProjectName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjectName.Location = new System.Drawing.Point(3, 39);
            this.lblProjectName.Name = "lblProjectName";
            this.lblProjectName.Size = new System.Drawing.Size(110, 17);
            this.lblProjectName.TabIndex = 11;
            this.lblProjectName.Text = "Project Navn/ID:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(48, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(159, 22);
            this.label4.TabIndex = 10;
            this.label4.Text = "Project Information";
            // 
            // tabFrontForm
            // 
            this.tabFrontForm.Controls.Add(this.tabDataEntry);
            this.tabFrontForm.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabFrontForm.ItemSize = new System.Drawing.Size(99, 20);
            this.tabFrontForm.Location = new System.Drawing.Point(1, 1);
            this.tabFrontForm.Multiline = true;
            this.tabFrontForm.Name = "tabFrontForm";
            this.tabFrontForm.Padding = new System.Drawing.Point(0, 0);
            this.tabFrontForm.SelectedIndex = 0;
            this.tabFrontForm.Size = new System.Drawing.Size(1102, 625);
            this.tabFrontForm.TabIndex = 1;
            this.tabFrontForm.Tag = "";
            // 
            // FrontForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1087, 609);
            this.Controls.Add(this.tabFrontForm);
            this.Name = "FrontForm";
            this.Text = "KL Span";
            this.tabDataEntry.ResumeLayout(false);
            this.tabDataEntry.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDnVbo)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.pnlSKriv.ResumeLayout(false);
            this.pnlSKriv.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.antall_ledd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDnR_3_5spenn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDnseksjPos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDnOffset)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDnFmin)).EndInit();
            this.pnlLeddParams.ResumeLayout(false);
            this.pnlLeddParams.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LeddRad10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeddRad9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeddRad8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeddRad7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeddRad6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeddRad5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeddRad4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeddRad3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeddRad2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeddLeng10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeddLeng9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeddLeng8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeddLeng7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeddLeng6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeddLeng5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeddLeng4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeddLeng3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeddLeng2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeddLeng1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeddRad1)).EndInit();
            this.PlotSelector.ResumeLayout(false);
            this.PlotSelector.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nrUpDnSpennNr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nrUpDnLedpartNr)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LedPart5MaksLeng)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LedPart4MaksLeng)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LedPart3MaksLeng)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LedPart2MaksLeng)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LedPart1MaksLeng)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LedPart5MaksTall)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LedPart4MaksTall)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LedPart3MaksTall)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LedPart2MaksTall)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LedPart1MaksTall)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDnStrekHast)).EndInit();
            this.tabFrontForm.ResumeLayout(false);
            this.ResumeLayout(false);

        }
        private System.Windows.Forms.Label[] lblLedd;
        private System.Windows.Forms.TextBox[] LeddStart;
        private System.Windows.Forms.TextBox[] LeddEnd;
        private System.Windows.Forms.NumericUpDown[] LeddLeng;
        private System.Windows.Forms.ComboBox[] TypeKurve;
        private System.Windows.Forms.NumericUpDown[] LeddRad;
        private System.Windows.Forms.ComboBox[] LeddRetn;
        private System.Windows.Forms.TextBox[] LedPart_leng;
        private System.Windows.Forms.TextBox[] LedPart_TallSpn;
        private System.Windows.Forms.TextBox[] LedPart_start;
        private System.Windows.Forms.TextBox[] LedPart_end;
        private System.Windows.Forms.TextBox[] LedPartTallSpn;
        private System.Windows.Forms.NumericUpDown[] LedPartMaksTall;
        private System.Windows.Forms.NumericUpDown[] LedPartMaksLeng;
        private System.Windows.Forms.ComboBox[] LedPartLøpRet;
        public System.Windows.Forms.Button[] btnLeddPart;

        #endregion
        private System.Windows.Forms.TabPage tabDataEntry;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.NumericUpDown numUpDnR_3_5spenn;
        private System.Windows.Forms.Label lbl3_5_spenn;
        private System.Windows.Forms.CheckBox ckBxkm;
        private System.Windows.Forms.Button btnTrasePlot;
        private System.Windows.Forms.NumericUpDown numUpDnseksjPos;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblTraseLedd;
        private System.Windows.Forms.NumericUpDown numUpDnOffset;
        private System.Windows.Forms.Label lbl_offset;
        private System.Windows.Forms.ComboBox cmbLo;
        private System.Windows.Forms.NumericUpDown numUpDnFmin;
        private System.Windows.Forms.Button btnVindUtb;
        private System.Windows.Forms.Label lbl_m_s;
        private System.Windows.Forms.Label lbl_Vbo_bo;
        private System.Windows.Forms.Label lbl_Vw_V;
        private System.Windows.Forms.Label lbl_N;
        private System.Windows.Forms.Label lbl_Fw_w;
        private System.Windows.Forms.Label lbl_Fw_F;
        private System.Windows.Forms.TextBox txtVindKraft;
        private System.Windows.Forms.TextBox txtHcw;
        private System.Windows.Forms.TextBox txtHca;
        private System.Windows.Forms.Label lbl_cm1;
        private System.Windows.Forms.Label lbl_N2;
        private System.Windows.Forms.Label lbl_kN2;
        private System.Windows.Forms.Label lbl_kN;
        private System.Windows.Forms.Label lbl_m2;
        private System.Windows.Forms.Label lblTillatVinUt;
        private System.Windows.Forms.Label lbl_Fmin_min;
        private System.Windows.Forms.Label lbl_Fmin_F;
        private System.Windows.Forms.Label lbl_HCW_CW;
        private System.Windows.Forms.Label lbl_HCA_CA;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label lbl_HCW_H;
        private System.Windows.Forms.Label lbl_HCA_H;
        private System.Windows.Forms.Label lbl_Lo_o;
        private System.Windows.Forms.ComboBox cmbSystemType;
        private System.Windows.Forms.Label lblSystemType;
        private System.Windows.Forms.Button btnBeregn;
        private System.Windows.Forms.NumericUpDown antall_ledd;
        private System.Windows.Forms.Panel pnlLeddParams;
        private System.Windows.Forms.ComboBox LeddRetn10;
        private System.Windows.Forms.ComboBox LeddRetn9;
        private System.Windows.Forms.ComboBox LeddRetn8;
        private System.Windows.Forms.ComboBox LeddRetn7;
        private System.Windows.Forms.ComboBox LeddRetn6;
        private System.Windows.Forms.ComboBox LeddRetn5;
        private System.Windows.Forms.ComboBox LeddRetn4;
        private System.Windows.Forms.ComboBox LeddRetn3;
        private System.Windows.Forms.ComboBox LeddRetn2;
        private System.Windows.Forms.ComboBox comboBox9;
        private System.Windows.Forms.ComboBox LeddRetn1;
        private System.Windows.Forms.ComboBox TypeKurve10;
        private System.Windows.Forms.NumericUpDown LeddRad10;
        private System.Windows.Forms.ComboBox TypeKurve9;
        private System.Windows.Forms.NumericUpDown LeddRad9;
        private System.Windows.Forms.ComboBox TypeKurve8;
        private System.Windows.Forms.NumericUpDown LeddRad8;
        private System.Windows.Forms.ComboBox TypeKurve7;
        private System.Windows.Forms.NumericUpDown LeddRad7;
        private System.Windows.Forms.ComboBox TypeKurve6;
        private System.Windows.Forms.NumericUpDown LeddRad6;
        private System.Windows.Forms.ComboBox TypeKurve5;
        private System.Windows.Forms.NumericUpDown LeddRad5;
        private System.Windows.Forms.ComboBox TypeKurve4;
        private System.Windows.Forms.NumericUpDown LeddRad4;
        private System.Windows.Forms.ComboBox TypeKurve3;
        private System.Windows.Forms.NumericUpDown LeddRad3;
        private System.Windows.Forms.ComboBox TypeKurve2;
        private System.Windows.Forms.NumericUpDown LeddRad2;
        private System.Windows.Forms.NumericUpDown LeddLeng10;
        private System.Windows.Forms.NumericUpDown LeddLeng9;
        private System.Windows.Forms.NumericUpDown LeddLeng8;
        private System.Windows.Forms.NumericUpDown LeddLeng7;
        private System.Windows.Forms.NumericUpDown LeddLeng6;
        private System.Windows.Forms.NumericUpDown LeddLeng5;
        private System.Windows.Forms.NumericUpDown LeddLeng4;
        private System.Windows.Forms.NumericUpDown LeddLeng3;
        private System.Windows.Forms.NumericUpDown LeddLeng2;
        private System.Windows.Forms.NumericUpDown numericUpDown2;
        private System.Windows.Forms.NumericUpDown LeddLeng1;
        private System.Windows.Forms.TextBox LeddEnd10;
        private System.Windows.Forms.TextBox LeddStart10;
        private System.Windows.Forms.Label lblLedd10;
        private System.Windows.Forms.TextBox LeddEnd9;
        private System.Windows.Forms.TextBox LeddStart9;
        private System.Windows.Forms.Label lblLedd9;
        private System.Windows.Forms.TextBox LeddEnd8;
        private System.Windows.Forms.TextBox LeddStart8;
        private System.Windows.Forms.Label lblLedd8;
        private System.Windows.Forms.TextBox LeddEnd7;
        private System.Windows.Forms.TextBox LeddStart7;
        private System.Windows.Forms.Label lblLedd7;
        private System.Windows.Forms.TextBox LeddEnd6;
        private System.Windows.Forms.TextBox LeddStart6;
        private System.Windows.Forms.Label lblLedd6;
        private System.Windows.Forms.TextBox LeddEnd5;
        private System.Windows.Forms.TextBox LeddStart5;
        private System.Windows.Forms.Label lblLedd5;
        private System.Windows.Forms.TextBox LeddEnd4;
        private System.Windows.Forms.TextBox LeddStart4;
        private System.Windows.Forms.Label lblLedd4;
        private System.Windows.Forms.TextBox LeddEnd3;
        private System.Windows.Forms.TextBox LeddStart3;
        private System.Windows.Forms.Label lblLedd3;
        private System.Windows.Forms.TextBox LeddEnd2;
        private System.Windows.Forms.TextBox LeddStart2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label lblLedd2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.ComboBox TypeKurve1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox LeddEnd1;
        private System.Windows.Forms.TextBox LeddStart1;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Label lblLedd1;
        private System.Windows.Forms.NumericUpDown LeddRad1;
        private System.Windows.Forms.Panel PlotSelector;
        private System.Windows.Forms.NumericUpDown nrUpDnSpennNr;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.RadioButton rdBtnVUtbSpan;
        private System.Windows.Forms.RadioButton rdBtnVUtbLedPart;
        private System.Windows.Forms.RadioButton rdBtnTrase;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.NumericUpDown nrUpDnLedpartNr;
        private System.Windows.Forms.Label lblLedpartNr;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnLeddPart5;
        private System.Windows.Forms.Button btnLeddPart4;
        private System.Windows.Forms.Button btnLeddPart3;
        private System.Windows.Forms.Button btnLeddPart2;
        private System.Windows.Forms.Button btnLeddPart1;
        private System.Windows.Forms.ComboBox LedPart5LøpRet;
        private System.Windows.Forms.ComboBox LedPart4LøpRet;
        private System.Windows.Forms.ComboBox LedPart3LøpRet;
        private System.Windows.Forms.ComboBox LedPart2LøpRet;
        private System.Windows.Forms.ComboBox LedPart1LøpRet;
        private System.Windows.Forms.NumericUpDown LedPart5MaksLeng;
        private System.Windows.Forms.NumericUpDown LedPart4MaksLeng;
        private System.Windows.Forms.NumericUpDown LedPart3MaksLeng;
        private System.Windows.Forms.NumericUpDown LedPart2MaksLeng;
        private System.Windows.Forms.NumericUpDown LedPart1MaksLeng;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown LedPart5MaksTall;
        private System.Windows.Forms.NumericUpDown LedPart4MaksTall;
        private System.Windows.Forms.NumericUpDown LedPart3MaksTall;
        private System.Windows.Forms.NumericUpDown LedPart2MaksTall;
        private System.Windows.Forms.NumericUpDown LedPart1MaksTall;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox LedPart5TallSpn;
        private System.Windows.Forms.TextBox LedPart4TallSpn;
        private System.Windows.Forms.TextBox LedPart3TallSpn;
        private System.Windows.Forms.TextBox LedPart2TallSpn;
        private System.Windows.Forms.TextBox LedPart1TallSpn;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox LedPart5_leng;
        private System.Windows.Forms.TextBox LedPart4_leng;
        private System.Windows.Forms.TextBox LedPart3_leng;
        private System.Windows.Forms.TextBox LedPart2_leng;
        private System.Windows.Forms.TextBox LedPart1_leng;
        private System.Windows.Forms.TextBox LedPart5_end;
        private System.Windows.Forms.TextBox LedPart5_start;
        private System.Windows.Forms.TextBox LedPart4_end;
        private System.Windows.Forms.TextBox LedPart4_start;
        private System.Windows.Forms.TextBox LedPart3_end;
        private System.Windows.Forms.TextBox LedPart3_start;
        private System.Windows.Forms.TextBox LedPart2_end;
        private System.Windows.Forms.TextBox LedPart2_start;
        public System.Windows.Forms.TextBox LedPart1_end;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox LedPart1_start;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lblKurveLengde;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label lblTraseSammenstilling;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtSluttpkt;
        private System.Windows.Forms.Label lblToMast;
        private System.Windows.Forms.Label lblFromMast;
        private System.Windows.Forms.TextBox txtUtfortdato;
        private System.Windows.Forms.TextBox txtUtfortav;
        private System.Windows.Forms.TextBox txtStartpkt;
        private System.Windows.Forms.TextBox txtProjectNumber;
        private System.Windows.Forms.TextBox txtProjectName;
        private System.Windows.Forms.Label lblDateOfDesign;
        private System.Windows.Forms.Label lblNameOfDesigner;
        private System.Windows.Forms.Label lblSpanLocation;
        private System.Windows.Forms.Label lblProjectNo;
        private System.Windows.Forms.Label lblProjectName;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TabControl tabFrontForm;
        private System.Windows.Forms.Panel pnlSKriv;
        private System.Windows.Forms.Button btnHentData;
        private System.Windows.Forms.OpenFileDialog OpenTraseFile;
        private System.Windows.Forms.OpenFileDialog OpenProsjektFile;
        private System.Windows.Forms.FolderBrowserDialog SaveResultsTo;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.RadioButton rdbtnImport;
        private System.Windows.Forms.Button btnVindKart;
        private System.Windows.Forms.Label lbl_Vb_kast_bkast;
        private System.Windows.Forms.Label lblVbkast_V;
        private System.Windows.Forms.TextBox txtVind_kast;
        private System.Windows.Forms.NumericUpDown numUpDnVbo;
        private System.Windows.Forms.ComboBox cmbE_R;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button btnOppdaterTraseLeng;
        private System.Windows.Forms.RadioButton rdbtnSkrive;
        private System.Windows.Forms.Label lblEksportmappe;
        private System.Windows.Forms.Button btnExportmappe;
        private System.Windows.Forms.Button btnHentProsjektInfo;
        private System.Windows.Forms.Button btnLagreProsjektInfo;
        private System.Windows.Forms.Button btnLagreTrasedata;
        private System.Windows.Forms.Button btnLagreledpartdata;
        private System.Windows.Forms.Button btnLagrePlot;
        private System.Windows.Forms.NumericUpDown numUpDnStrekHast;
    }
}

