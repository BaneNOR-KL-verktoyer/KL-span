﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OxyPlot;
using OxyPlot.WindowsForms;
using KLAppGlobal;

namespace KLAppGlobal
{
    public partial class TrasePlotForm : Form
    {
        public TrasePlotForm()
        {
            InitializeComponent();
        }

        private void SavePlot_Click(object sender, EventArgs e)
        {

            //PngExporter.Export(PlotViewer.ActualModel, @"C:\Users\Teme\Desktop\CPP Projects\file.png", 600, 400, OxyColors.White);//
        }
    }
}
