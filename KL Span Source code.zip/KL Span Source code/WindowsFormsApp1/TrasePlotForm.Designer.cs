﻿namespace KLAppGlobal
{
    partial class TrasePlotForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PlotViewer = new OxyPlot.WindowsForms.PlotView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // PlotViewer
            // 
            this.PlotViewer.BackColor = System.Drawing.Color.LightCyan;
            this.PlotViewer.Location = new System.Drawing.Point(0, 6);
            this.PlotViewer.Name = "PlotViewer";
            this.PlotViewer.PanCursor = System.Windows.Forms.Cursors.Hand;
            this.PlotViewer.Size = new System.Drawing.Size(957, 454);
            this.PlotViewer.TabIndex = 0;
            this.PlotViewer.Text = "Trase Plot";
            this.PlotViewer.ZoomHorizontalCursor = System.Windows.Forms.Cursors.SizeWE;
            this.PlotViewer.ZoomRectangleCursor = System.Windows.Forms.Cursors.SizeNWSE;
            this.PlotViewer.ZoomVerticalCursor = System.Windows.Forms.Cursors.SizeNS;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.PlotViewer);
            this.panel1.Location = new System.Drawing.Point(5, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(956, 463);
            this.panel1.TabIndex = 1;
            // 
            // TrasePlotForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(963, 470);
            this.Controls.Add(this.panel1);
            this.Name = "TrasePlotForm";
            this.Text = "TrasePlot";
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        public OxyPlot.WindowsForms.PlotView PlotViewer;
        private System.Windows.Forms.Panel panel1;
    }
}