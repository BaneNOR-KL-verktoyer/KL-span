﻿using OxyPlot;
using OxyPlot.Series;
using OxyPlot.WindowsForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;

namespace KLAppGlobal
{
    public partial class FrontForm : Form
    {
        FormCollection formsList = Application.OpenForms;
        public ResultsForm P1 = new ResultsForm();
        public ResultsForm P2 = new ResultsForm();
        public ResultsForm P3 = new ResultsForm();
        public ResultsForm P4 = new ResultsForm();
        public ResultsForm P5 = new ResultsForm();
        public VindUtblForm Q = new VindUtblForm();
        public TrasePlotForm TrasePlot = new TrasePlotForm();
        public OCLSystem Sys = new OCLSystem();
        public Create_OCL_wire_Table OCLWireTable = new Create_OCL_wire_Table();

        public KL_span temp_span = new KL_span();
        public TraseLedd temp_TraseLedd0 = new TraseLedd();
        public TraseLedd temp_TraseLedd1 = new TraseLedd();
        public TraseLedd chopped_TraseLedd = new TraseLedd();
        public TraseLedd[] TraseLedder;
        public LedPart[] LedParter;
        public Plotter plottrase = new Plotter();
        VindUtblTabel VindUTB = new VindUtblTabel(0);
        public System.Windows.Forms.Label[][] SpennTabel;
        public int n = 1;           double L_tot;           double ϴ_tot;
        double offset;              double seksjPos;        double xi;
        string LengdeOverskrid;     bool SeksjoneringSatt = false;
        string LeddpartOvergang = "3spenn";                 string SpennType = "Normal";
        int i = 0; int j = 0; int v = 0; int q = 0; //i=Ledd teller, j=Ledningspart teller, q=Spenn lengde teller
                                                    // Beregn nominell spennlengde til hver eneste traseledd
        public string prosjektmappe = null;
        string ProsjektInfofileName = null;
        string TrasedatafileName = null;
        string LedpartdatafileName = null;
        string[] SheetNames = null;
        DataSet TraseDSet = new DataSet();

        public string Lagrested
        {
            get { return prosjektmappe; }
        }
        public FrontForm()
        {
            InitializeComponent();
            P1.Activate(); P2.Activate(); P3.Activate(); P4.Activate(); P5.Activate();
            foreach (TabPage tp in tabFrontForm.TabPages) tp.Text = tp.Text.Replace("\\n", "\n");
            lblLedd = new System.Windows.Forms.Label[] { lblLedd1, lblLedd2, lblLedd3, lblLedd4, lblLedd5, lblLedd6, lblLedd7, lblLedd8, lblLedd9, lblLedd10 };
            LeddStart = new System.Windows.Forms.TextBox[] { LeddStart1, LeddStart2, LeddStart3, LeddStart4, LeddStart5, LeddStart6, LeddStart7, LeddStart8, LeddStart9, LeddStart10 };
            LeddEnd = new System.Windows.Forms.TextBox[] { LeddEnd1, LeddEnd2, LeddEnd3, LeddEnd4, LeddEnd5, LeddEnd6, LeddEnd7, LeddEnd8, LeddEnd9, LeddEnd10 };
            LeddLeng = new System.Windows.Forms.NumericUpDown[] { LeddLeng1, LeddLeng2, LeddLeng3, LeddLeng4, LeddLeng5, LeddLeng6, LeddLeng7, LeddLeng8, LeddLeng9, LeddLeng10 };
            TypeKurve = new System.Windows.Forms.ComboBox[] { TypeKurve1, TypeKurve2, TypeKurve3, TypeKurve4, TypeKurve5, TypeKurve6, TypeKurve7, TypeKurve8, TypeKurve9, TypeKurve10 };
            LeddRad = new System.Windows.Forms.NumericUpDown[] { LeddRad1, LeddRad2, LeddRad3, LeddRad4, LeddRad5, LeddRad6, LeddRad7, LeddRad8, LeddRad9, LeddRad10 };
            LeddRetn = new System.Windows.Forms.ComboBox[] { LeddRetn1, LeddRetn2, LeddRetn3, LeddRetn4, LeddRetn5, LeddRetn6, LeddRetn7, LeddRetn8, LeddRetn9, LeddRetn10 };
            LedPart_leng = new System.Windows.Forms.TextBox[] { LedPart1_leng, LedPart2_leng, LedPart3_leng, LedPart4_leng, LedPart5_leng };
            LedPart_TallSpn = new System.Windows.Forms.TextBox[] { LedPart1TallSpn, LedPart2TallSpn, LedPart3TallSpn, LedPart4TallSpn, LedPart5TallSpn };
            LedPart_start = new System.Windows.Forms.TextBox[] { LedPart1_start, LedPart2_start, LedPart3_start, LedPart4_start, LedPart5_start };
            LedPart_end = new System.Windows.Forms.TextBox[] { LedPart1_end, LedPart2_end, LedPart3_end, LedPart4_end, LedPart5_end };
            LedPartTallSpn = new System.Windows.Forms.TextBox[] { LedPart1TallSpn, LedPart2TallSpn, LedPart3TallSpn, LedPart4TallSpn, LedPart5TallSpn };
            LedPartMaksTall = new System.Windows.Forms.NumericUpDown[] { LedPart1MaksTall, LedPart2MaksTall, LedPart3MaksTall, LedPart4MaksTall, this.LedPart5MaksTall };
            LedPartMaksLeng = new System.Windows.Forms.NumericUpDown[] { LedPart1MaksLeng, LedPart2MaksLeng, LedPart3MaksLeng, LedPart4MaksLeng, this.LedPart5MaksLeng };
            LedPartLøpRet = new System.Windows.Forms.ComboBox[] { LedPart1LøpRet, LedPart2LøpRet, LedPart3LøpRet, LedPart4LøpRet, LedPart5LøpRet };
            btnLeddPart = new System.Windows.Forms.Button[] { btnLeddPart1, btnLeddPart2, btnLeddPart3, btnLeddPart4, btnLeddPart5 };
            SpennTabel = new System.Windows.Forms.Label[21][];
            for (int row = 0; row < 21; row++) { SpennTabel[row] = new System.Windows.Forms.Label[13]; }
            antall_ledd.Value = 1;
            TraseLedder = new TraseLedd[10]; 
            for (int i = 0; i < 10; i++) { TraseLedder[i] = new TraseLedd(); }
            LedParter = new LedPart[5];
            SheetNames = new string[5];
            for (int i = 0; i < 5; i++) { LedParter[i] = new LedPart(); }
            Sys.Ktwire = new Wire(OCLWireTable.DT.Rows.Find("AC_120_Cu_ETP"));
            Sys.Blwire = new Wire(OCLWireTable.DT.Rows.Find("DIN_48_201_70_BzII"));
            cmbE_R.SelectedIndex = 0;
            cmbE_R.SelectedText = "Type 1";
            cmbSystemType.SelectedIndex = 1;
            cmbSystemType.SelectedText = "S20";
            cmbLo.SelectedIndex = 0;
            cmbLo.SelectedText = "65";
        }
        private void txtProjectName_Enter(object sender, EventArgs e)
        {
            ToolTip tt = new ToolTip();         tt.IsBalloon = true;
            tt.InitialDelay = 0;                tt.ShowAlways = false;
            tt.SetToolTip(txtProjectName, "Enter project name.");
        }
        private void txtProjectNumber_Enter(object sender, EventArgs e)
        {
            ToolTip tt = new ToolTip();         tt.IsBalloon = true;
            tt.InitialDelay = 0;                tt.ShowAlways = false;
            tt.SetToolTip(txtProjectNumber, "Enter project number.");
        }
        private void txtDesigner_Enter(object sender, EventArgs e)
        {
            ToolTip tt = new ToolTip();         tt.IsBalloon = true;
            tt.InitialDelay = 0;                tt.ShowAlways = false;
            tt.SetToolTip(txtUtfortav, "Enter span designer's name.");
        }
        private void txtDate_Enter(object sender, EventArgs e)
        {
            ToolTip tt = new ToolTip();         tt.IsBalloon = true;
            tt.InitialDelay = 0;                tt.ShowAlways = false;
            tt.SetToolTip(txtUtfortdato, "Enter date of span design.");
        }
        private void cmbSystemType_Enter(object sender, EventArgs e)
        {
            ToolTip tt = new ToolTip();         tt.IsBalloon = true;
            tt.InitialDelay = 0;                tt.ShowAlways = false;
            tt.SetToolTip(cmbSystemType, "Velg typesystem.");
        }
        private void btnVindUtb_Click(object sender, EventArgs e)
        {
            Q.Activate();
            if (Q.IsDisposed) 
            {  Q = new VindUtblForm(); Q.Change_E_R(cmbE_R.SelectedIndex); }
            Q.Show();
        }
        private void btnLeddPart1_Click(object sender, EventArgs e) { string caption = "½Led.part 1 - Spennliste"; List_results(0, P1, caption); }
        private void btnLeddPart2_Click(object sender, EventArgs e) { string caption = "½Led.part 2 - Spennliste"; List_results(1, P2, caption); }
        private void btnLeddPart3_Click(object sender, EventArgs e) { string caption = "½Led.part 3 - Spennliste"; List_results(2, P3, caption); }
        private void btnLeddPart4_Click(object sender, EventArgs e) { string caption = "½Led.part 4 - Spennliste"; List_results(3, P4, caption); }
        private void btnLeddPart5_Click(object sender, EventArgs e) { string caption = "½Led.part 5 - Spennliste"; List_results(4, P5, caption); }
        private void List_results(int j, ResultsForm P, string caption)
        {
            P.Activate();
            if (P.IsDisposed) {; } else{ P.Dispose(); }
            { P = new ResultsForm(); }
            P.Text = caption;
            {
                SpennTabel[0] =  new System.Windows.Forms.Label[] { P.CellA00, P.CellB00, P.CellC00, P.CellD00, P.CellE00, P.CellF00, P.CellG00, P.CellH00, P.CellI00, P.CellJ00, P.CellK00, P.CellL00, P.CellM00 };
                SpennTabel[1] =  new System.Windows.Forms.Label[] { P.CellA01, P.CellB01, P.CellC01, P.CellD01, P.CellE01, P.CellF01, P.CellG01, P.CellH01, P.CellI01, P.CellJ01, P.CellK01, P.CellL01, P.CellM01 };
                SpennTabel[2] =  new System.Windows.Forms.Label[] { P.CellA02, P.CellB02, P.CellC02, P.CellD02, P.CellE02, P.CellF02, P.CellG02, P.CellH02, P.CellI02, P.CellJ02, P.CellK02, P.CellL02, P.CellM02 };
                SpennTabel[3] =  new System.Windows.Forms.Label[] { P.CellA03, P.CellB03, P.CellC03, P.CellD03, P.CellE03, P.CellF03, P.CellG03, P.CellH03, P.CellI03, P.CellJ03, P.CellK03, P.CellL03, P.CellM03 };
                SpennTabel[4] =  new System.Windows.Forms.Label[] { P.CellA04, P.CellB04, P.CellC04, P.CellD04, P.CellE04, P.CellF04, P.CellG04, P.CellH04, P.CellI04, P.CellJ04, P.CellK04, P.CellL04, P.CellM04 };
                SpennTabel[5] =  new System.Windows.Forms.Label[] { P.CellA05, P.CellB05, P.CellC05, P.CellD05, P.CellE05, P.CellF05, P.CellG05, P.CellH05, P.CellI05, P.CellJ05, P.CellK05, P.CellL05, P.CellM05 };
                SpennTabel[6] =  new System.Windows.Forms.Label[] { P.CellA06, P.CellB06, P.CellC06, P.CellD06, P.CellE06, P.CellF06, P.CellG06, P.CellH06, P.CellI06, P.CellJ06, P.CellK06, P.CellL06, P.CellM06 };
                SpennTabel[7] =  new System.Windows.Forms.Label[] { P.CellA07, P.CellB07, P.CellC07, P.CellD07, P.CellE07, P.CellF07, P.CellG07, P.CellH07, P.CellI07, P.CellJ07, P.CellK07, P.CellL07, P.CellM07 };
                SpennTabel[8] =  new System.Windows.Forms.Label[] { P.CellA08, P.CellB08, P.CellC08, P.CellD08, P.CellE08, P.CellF08, P.CellG08, P.CellH08, P.CellI08, P.CellJ08, P.CellK08, P.CellL08, P.CellM08 };
                SpennTabel[9] =  new System.Windows.Forms.Label[] { P.CellA09, P.CellB09, P.CellC09, P.CellD09, P.CellE09, P.CellF09, P.CellG09, P.CellH09, P.CellI09, P.CellJ09, P.CellK09, P.CellL09, P.CellM09 };
                SpennTabel[10] = new System.Windows.Forms.Label[] { P.CellA10, P.CellB10, P.CellC10, P.CellD10, P.CellE10, P.CellF10, P.CellG10, P.CellH10, P.CellI10, P.CellJ10, P.CellK10, P.CellL10, P.CellM10 };
                SpennTabel[11] = new System.Windows.Forms.Label[] { P.CellA11, P.CellB11, P.CellC11, P.CellD11, P.CellE11, P.CellF11, P.CellG11, P.CellH11, P.CellI11, P.CellJ11, P.CellK11, P.CellL11, P.CellM11 };
                SpennTabel[12] = new System.Windows.Forms.Label[] { P.CellA12, P.CellB12, P.CellC12, P.CellD12, P.CellE12, P.CellF12, P.CellG12, P.CellH12, P.CellI12, P.CellJ12, P.CellK12, P.CellL12, P.CellM12 };
                SpennTabel[13] = new System.Windows.Forms.Label[] { P.CellA13, P.CellB13, P.CellC13, P.CellD13, P.CellE13, P.CellF13, P.CellG13, P.CellH13, P.CellI13, P.CellJ13, P.CellK13, P.CellL13, P.CellM13 };
                SpennTabel[14] = new System.Windows.Forms.Label[] { P.CellA14, P.CellB14, P.CellC14, P.CellD14, P.CellE14, P.CellF14, P.CellG14, P.CellH14, P.CellI14, P.CellJ14, P.CellK14, P.CellL14, P.CellM14 };
                SpennTabel[15] = new System.Windows.Forms.Label[] { P.CellA15, P.CellB15, P.CellC15, P.CellD15, P.CellE15, P.CellF15, P.CellG15, P.CellH15, P.CellI15, P.CellJ15, P.CellK15, P.CellL15, P.CellM15 };
                SpennTabel[16] = new System.Windows.Forms.Label[] { P.CellA16, P.CellB16, P.CellC16, P.CellD16, P.CellE16, P.CellF16, P.CellG16, P.CellH16, P.CellI16, P.CellJ16, P.CellK16, P.CellL16, P.CellM16 };
                SpennTabel[17] = new System.Windows.Forms.Label[] { P.CellA17, P.CellB17, P.CellC17, P.CellD17, P.CellE17, P.CellF17, P.CellG17, P.CellH17, P.CellI17, P.CellJ17, P.CellK17, P.CellL17, P.CellM17 };
                SpennTabel[18] = new System.Windows.Forms.Label[] { P.CellA18, P.CellB18, P.CellC18, P.CellD18, P.CellE18, P.CellF18, P.CellG18, P.CellH18, P.CellI18, P.CellJ18, P.CellK18, P.CellL18, P.CellM18 };
                SpennTabel[19] = new System.Windows.Forms.Label[] { P.CellA19, P.CellB19, P.CellC19, P.CellD19, P.CellE19, P.CellF19, P.CellG19, P.CellH19, P.CellI19, P.CellJ19, P.CellK19, P.CellL19, P.CellM19 };
                SpennTabel[20] = new System.Windows.Forms.Label[] { P.CellA20, P.CellB20, P.CellC20, P.CellD20, P.CellE20, P.CellF20, P.CellG20, P.CellH20, P.CellI20, P.CellJ20, P.CellK20, P.CellL20, P.CellM20 };
            }
            for (int q=0; q <= LedParter[j].antall_spenn; q++)
            {
                SpennTabel[q + 1][0].Text = (Math.Round(LedParter[j].Spenner[q].x1, 1)).ToString("0.0");
                if(Math.Abs(LedParter[j].Spenner[q].R) > 1e6)
                { SpennTabel[q + 1][1].Text = "∞"; }
                else { SpennTabel[q + 1][1].Text = (Math.Round(LedParter[j].Spenner[q].R)).ToString();}
                SpennTabel[q + 1][2].Text = (Math.Round(LedParter[j].Spenner[q].a, 1)).ToString();
                SpennTabel[q + 1][3].Text = (Math.Round(LedParter[j].Spenner[q].b1 * 100)).ToString();
                SpennTabel[q + 1][4].Text = (Math.Round(LedParter[j].Spenner[q].b2 * 100)).ToString();
                SpennTabel[q + 1][5].Text = (Math.Round(LedParter[j].Spenner[q].Fd_B1)).ToString();
                SpennTabel[q + 1][6].Text = (Math.Round(LedParter[j].Spenner[q].Fd_B2)).ToString();
                SpennTabel[q + 1][7].Text = (Math.Round(LedParter[j].Spenner[q].c * 100)).ToString();
                SpennTabel[q + 1][8].Text = (Math.Round(LedParter[j].Spenner[q].E * 100)).ToString();
                SpennTabel[q + 1][9].Text = (Math.Round(LedParter[j].Spenner[q].e_l * 100)).ToString();
                SpennTabel[q + 1][10].Text = (Math.Round(LedParter[j].Spenner[q].e_r * 100)).ToString();
                SpennTabel[q + 1][11].Text = LedParter[j].Spenner[q].SpennType;
            }
            for (int q = 20; q >= LedParter[j].antall_spenn+1; q--)
            { for (int m = 0; m < 12; m++) { SpennTabel[q][m].Visible = false;} }
            for(int q = 0; q<21; q++) 
            { for (int m = 12; m < 13; m++) { SpennTabel[q][m].Visible = false; } }
            P.Show();
        }
        private void numUpDnFmin_Enter(object sender, EventArgs e)
        {
            ToolTip tt = new ToolTip();         tt.IsBalloon = true;
            tt.InitialDelay = 0;                tt.ShowAlways = false;
            tt.SetToolTip(numUpDnFmin, "Sett inn tall mellom 80 og 100.");
        }
        private void cmbLo_Enter(object sender, EventArgs e)
        {
            ToolTip tt = new ToolTip();         tt.IsBalloon = true;
            tt.InitialDelay = 0;                tt.ShowAlways = false;
            tt.SetToolTip(cmbLo, "Velg max spenn lengde i rett linje.");
        }
        private void answer_antalLedd_enter(object sender, EventArgs e)
        {
            for (int i = 1; i < 10; i++)
            {
                int m = (int)antall_ledd.Value;
                if (i < m)
                {
                    this.lblLedd[i].Visible = true;         this.LeddStart[i].Visible = true;
                    this.LeddEnd[i].Visible = true;         this.LeddLeng[i].Visible = true;
                    this.TypeKurve[i].Visible = true;
                    if (TypeKurve[i].Text == "Kurve") { LeddRad[i].Visible = true; LeddRetn[i].Visible = true; }
                    else { LeddRad[i].Visible = false; LeddRetn[i].Visible = false; }
                }
                else
                {
                    this.lblLedd[i].Visible = false;        this.LeddStart[i].Visible = false;
                    this.LeddEnd[i].Visible = false;        this.LeddLeng[i].Visible = false;
                    this.TypeKurve[i].Visible = false;      this.LeddRad[i].Visible = false;
                    this.LeddRetn[i].Visible = false;
                }
            }
        }
        private void TypeKurve1_Change(object sender, EventArgs e)
        {
            if(TypeKurve1.Text == "Kurve") { LeddRad1.Visible = true; LeddRetn1.Visible = true; }
            else { LeddRad1.Visible = false; LeddRetn1.Visible = false; }
        }
        private void TypeKurve2_Change(object sender, EventArgs e)
        {
            if (TypeKurve2.Text == "Kurve") { LeddRad2.Visible = true; LeddRetn2.Visible = true; }
            else { LeddRad2.Visible = false; LeddRetn2.Visible = false; }
        }
        private void TypeKurve3_Change(object sender, EventArgs e)
        {
            if (TypeKurve3.Text == "Kurve") { LeddRad3.Visible = true; LeddRetn3.Visible = true; }
            else { LeddRad3.Visible = false; LeddRetn3.Visible = false; }
        }
        private void TypeKurve4_Change(object sender, EventArgs e)
        {
            if (TypeKurve4.Text == "Kurve") { LeddRad4.Visible = true; LeddRetn4.Visible = true; }
            else { LeddRad4.Visible = false; LeddRetn4.Visible = false; }
        }
        private void TypeKurve5_Change(object sender, EventArgs e)
        {
            if (TypeKurve5.Text == "Kurve") { LeddRad5.Visible = true; LeddRetn5.Visible = true; }
            else { LeddRad5.Visible = false; LeddRetn5.Visible = false; }
        }
        private void TypeKurve6_Change(object sender, EventArgs e)
        {
            if (TypeKurve6.Text == "Kurve") { LeddRad6.Visible = true; LeddRetn6.Visible = true; }
            else { LeddRad6.Visible = false; LeddRetn6.Visible = false; }
        }
        private void TypeKurve7_Change(object sender, EventArgs e)
        {
            if (TypeKurve7.Text == "Kurve") { LeddRad7.Visible = true; LeddRetn7.Visible = true; }
            else { LeddRad7.Visible = false; LeddRetn7.Visible = false; }
        }
        private void TypeKurve8_Change(object sender, EventArgs e)
        {
            if (TypeKurve8.Text == "Kurve") { LeddRad8.Visible = true; LeddRetn8.Visible = true; }
            else { LeddRad8.Visible = false; LeddRetn8.Visible = false; }
        }
        private void TypeKurve9_Change(object sender, EventArgs e)
        {
            if (TypeKurve9.Text == "Kurve") { LeddRad9.Visible = true; LeddRetn9.Visible = true; }
            else { LeddRad9.Visible = false; LeddRetn9.Visible = false; }
        }
        private void TypeKurve10_Change(object sender, EventArgs e)
        {
            if (TypeKurve10.Text == "Kurve") { LeddRad10.Visible = true; LeddRetn10.Visible = true; }
            else { LeddRad10.Visible = false; LeddRetn10.Visible = false; }
        }
        private void LeddEnd1_Change(object sender, EventArgs e) 
        {
            if (ckBxkm.Checked == true) { try { LeddStart2.Text = LeddEnd1.Text;} catch { LeddEnd1.Text = LeddStart2.Text; } }
        }
        private void LeddEnd2_Change(object sender, EventArgs e)
        {
            if (ckBxkm.Checked == true) { try { LeddStart3.Text = LeddEnd2.Text; } catch {LeddEnd2.Text = LeddStart3.Text; } }
        }
        private void LeddEnd3_Change(object sender, EventArgs e)
        {
            if (ckBxkm.Checked == true) { try { LeddStart4.Text = LeddEnd3.Text; } catch { LeddEnd3.Text = LeddStart4.Text; } }
        }
        private void LeddEnd4_Change(object sender, EventArgs e)
        {
            if (ckBxkm.Checked == true) { try { LeddStart5.Text = LeddEnd4.Text; } catch { } }
        }
        private void LeddEnd5_Change(object sender, EventArgs e)
        {
            if (ckBxkm.Checked == true) { try { LeddStart6.Text = LeddEnd5.Text; } catch { } }
        }
        private void LeddEnd6_Change(object sender, EventArgs e)
        {
            if (ckBxkm.Checked == true) { try { LeddStart7.Text = LeddEnd6.Text; } catch { } }
        }
        private void LeddEnd7_Change(object sender, EventArgs e)
        {
            if (ckBxkm.Checked == true) { try { LeddStart8.Text = LeddEnd7.Text; } catch {  } }
        }
        private void LeddEnd8_Change(object sender, EventArgs e)
        {
            if (ckBxkm.Checked == true) { try { LeddStart9.Text = LeddEnd8.Text;  } catch { } }
        }
        private void LeddEnd9_Change(object sender, EventArgs e)
        {
            if (ckBxkm.Checked == true) { try { LeddStart10.Text = LeddEnd9.Text; } catch { } }
        }
        private void LeddEnd10_Change(object sender, EventArgs e)
        {
            if (ckBxkm.Checked == true) {  try { } catch { } }
        }
        private void TypeKurve2_Enter(object sender, EventArgs e)
        {
            if ((string)TypeKurve1.SelectedItem == "Overgang" || (string)TypeKurve3.SelectedItem == "Overgang" ||n==2)
            { TypeKurve2.Items.Remove("Overgang"); }
            else if (TypeKurve2.Items.Count==2){ TypeKurve2.Items.Add("Overgang"); }
        }
        private void TypeKurve3_Enter(object sender, EventArgs e)
        {
            if ((string)TypeKurve2.SelectedItem == "Overgang" || (string)TypeKurve4.SelectedItem == "Overgang" || n == 3)
            { TypeKurve3.Items.Remove("Overgang"); }
            else if (TypeKurve3.Items.Count == 2) { TypeKurve3.Items.Add("Overgang"); }
        }
        private void TypeKurve4_Enter(object sender, EventArgs e)
        {
            if ((string)TypeKurve3.SelectedItem == "Overgang" || (string)TypeKurve5.SelectedItem == "Overgang" || n == 4)
            { TypeKurve4.Items.Remove("Overgang"); }
            else if (TypeKurve4.Items.Count == 2) { TypeKurve4.Items.Add("Overgang"); }
        }
        private void TypeKurve5_Enter(object sender, EventArgs e)
        {
            if ((string)TypeKurve4.SelectedItem == "Overgang" || (string)TypeKurve6.SelectedItem == "Overgang" || n == 5)
            { TypeKurve5.Items.Remove("Overgang"); }
            else if (TypeKurve5.Items.Count == 2) { TypeKurve5.Items.Add("Overgang"); }
        }
        private void TypeKurve6_Enter(object sender, EventArgs e)
        {
            if ((string)TypeKurve5.SelectedItem == "Overgang" || (string)TypeKurve7.SelectedItem == "Overgang" || n == 6)
            { TypeKurve6.Items.Remove("Overgang"); }
            else if (TypeKurve6.Items.Count == 2) { TypeKurve6.Items.Add("Overgang"); }
        }
        private void TypeKurve7_Enter(object sender, EventArgs e)
        {
            if ((string)TypeKurve6.SelectedItem == "Overgang" || (string)TypeKurve8.SelectedItem == "Overgang" || n == 7)
            { TypeKurve7.Items.Remove("Overgang"); }
            else if (TypeKurve7.Items.Count == 2) { TypeKurve7.Items.Add("Overgang"); }
        }
        private void TypeKurve8_Enter(object sender, EventArgs e)
        {
            if ((string)TypeKurve7.SelectedItem == "Overgang" || (string)TypeKurve9.SelectedItem == "Overgang" || n == 8)
            { TypeKurve8.Items.Remove("Overgang"); }
            else if (TypeKurve8.Items.Count == 2) { TypeKurve8.Items.Add("Overgang"); }
        }
        private void TypeKurve9_Enter(object sender, EventArgs e)
        {
            if ((string)TypeKurve8.SelectedItem == "Overgang" || (string)TypeKurve10.SelectedItem == "Overgang" || n == 9)
            { TypeKurve9.Items.Remove("Overgang"); }
            else if (TypeKurve9.Items.Count == 2) { TypeKurve9.Items.Add("Overgang"); }
        }
        //Main data processing
        public void Beregn(object sender, EventArgs e) 
        { 
            for (int i = Application.OpenForms.Count - 1; i >= 0; i--)
            {
                if (Application.OpenForms[i].Text != "KL Span")
                    Application.OpenForms[i].Close();
            }
            GetInnputdata();
            if (numUpDnOffset.Value < (decimal)TraseLedder[0].x1 || numUpDnOffset.Value > (decimal)TraseLedder[n-1].x2) { MessageBox.Show("Offset er utenfør strekningsseksjon!"); return; }
            for (int i = 0; i < n; i++)
            {
                try { LeddLeng[i].Value = Convert.ToDecimal(LeddEnd[i].Text) - Convert.ToDecimal(LeddStart[i].Text); }
                catch { MessageBox.Show("Offending Input! \n (Ikke konsekvent punkter!)", "Error"); return; }
            }
            AntallLedPart(); 
        }
        public void GetInnputdata()
        {
            if (cmbSystemType.SelectedIndex == 0) { Sys.H = 2 * 15000; }
            else if (cmbSystemType.SelectedIndex == 1){ Sys.H = 2 * 10000; }
            else if (cmbSystemType.SelectedIndex == 2) { Sys.H = 2 * 7060; } 
            else { Sys.H = 2 * 10000; }
            if (cmbLo.SelectedIndex == 0) { Sys.lo = 65; }
            else if (cmbLo.SelectedIndex == 1) { Sys.lo = 70; }
            else if (cmbLo.SelectedIndex == 2) { Sys.lo = 75; }
            else { Sys.lo = 65; }
            Sys.Vw = Convert.ToDouble(txtVind_kast.Text);
            //Display dependent parameters
            txtHca.Text = (Math.Round(Sys.H / 2 / 1000, 2)).ToString();
            txtHcw.Text = (Math.Round(Sys.H / 2 / 1000, 2)).ToString();
            n = (int)antall_ledd.Value;
            for (int i = 0; i < n; i++)
            {
                TraseLedder[i].x1 = Convert.ToDouble(LeddStart[i].Text);
                TraseLedder[i].x2 = Convert.ToDouble(LeddEnd[i].Text);
                TraseLedder[i].L = TraseLedder[i].x2 - TraseLedder[i].x1;
                TraseLedder[i].TypeKurve = TypeKurve[i].Text;
                TraseLedder[i].KurveRetning = LeddRetn[i].Text;
                TraseLedder[i].KL.H = Sys.H;
                TraseLedder[i].KL.lo = Sys.lo;
                TraseLedder[i].KL.Vw = Sys.Vw;
                TraseLedder[i].KL.Fdmin = Sys.Fdmin;
                if(TraseLedder[i].TypeKurve == "Kurve")
                {
                    if (TraseLedder[i].KurveRetning == "-") { TraseLedder[i].KL.sgn = -1;}
                    else if (TraseLedder[i].KurveRetning == "+") { TraseLedder[i].KL.sgn = 1; }
                    TraseLedder[i].R1 = Convert.ToDouble(LeddRad[i].Text) * TraseLedder[i].KL.sgn;
                    TraseLedder[i].R2 = TraseLedder[i].R1;
                }
                else if (TraseLedder[i].TypeKurve == "Rett linje")
                { TraseLedder[i].R1 = 1e7; TraseLedder[i].R2 = 1e7; }
            }
            for (int i = 0; i < n; i++)
            {
                if (TraseLedder[i].TypeKurve == "Overgang")
                {
                    TraseLedder[i].R1 = TraseLedder[i-1].R2;
                    TraseLedder[i].R2 = TraseLedder[i+1].R1;
                }
                TraseLedder[i].Δϴ = TraseLedder[i].Calc_Δϴ(0);
            }
            for (int j = 0; j < 5; j++)
            {
                if (LedPartLøpRet[j].Text == "|→Ͽ")
                {LedParter[j].løp = "Fiks pkt. til lodd avs."; }
                else if (LedPartLøpRet[j].Text == "Ͼ←|")  { LedParter[j].løp = "Lodd avs. til fiks pkt."; }
                LedParter[j].max_lengde = Convert.ToDouble(LedPartMaksLeng[j].Text);
                LedParter[j].max_antall_spenn = Convert.ToInt32(LedPartMaksTall[j].Text);
            }
        }
        public void AntallLedPart()
        {
            L_tot = 0; ϴ_tot = 0;
            offset = Convert.ToDouble(numUpDnOffset.Text);
            seksjPos = Convert.ToDouble(numUpDnseksjPos.Text);
            xi = offset; LengdeOverskrid = "Nei";
            SeksjoneringSatt = false; LeddpartOvergang = "3spenn";
            SpennType = "Normal";
            VindUTB = new VindUtblTabel(cmbE_R.SelectedIndex);
            i = 0; j = 0; v = 0; q = 0;
            for (i = 0; i < n; i++)
            {
                TraseLedder[i].Segment_calc();
                TraseLedder[i].KL.E = VindUtblTabel.Find_E(TraseLedder[i].KL.R, VindUTB);
                TraseLedder[i].KL.CalcSpan(SpennType);
                L_tot = L_tot + TraseLedder[i].L;
                TraseLedder[i].ϴ2 = TraseLedder[i].ϴ1 - TraseLedder[i].Δϴ;
                TraseLedder[i].KL.b1 = TraseLedder[i].KL.B1 * TraseLedder[i].KL.sgn;
            }
            if (L_tot <= xi - TraseLedder[0].x1) { return; }
            
            for (j = 0; j < 5; j++)
            {
                LedParter[j].lengde = 0; LedParter[j].antall_spenn = 0; LedParter[j].nr = j;
                LedParter[j].start = 0; LedParter[j].end = 0;
            }
            LedParter[0].start = xi; LengdeOverskrid = "Nei";
            j = 0; int d = 0;
            while (j < 5 && d < 100)
            {
                d++; if (d > 2000) { MessageBox.Show("Offending Input! ", "Error"); return; }
                for (i = 0; TraseLedder[i].x2 <= xi;) { if (i < n - 1) { i++; } else { break; } }
                temp_TraseLedd1 = (TraseLedd)TraseLedder[i].Clone();
                temp_TraseLedd1.L = TraseLedder[i].x2 - xi;
                temp_TraseLedd1.Δϴ = TraseLedder[i].Calc_Δϴ(xi - temp_TraseLedd1.x1);
                if (temp_TraseLedd1.Δϴ == 0) { temp_TraseLedd1.KL.R = 1e7; }
                else { temp_TraseLedd1.KL.R = temp_TraseLedd1.L / temp_TraseLedd1.Δϴ; }
                if (q > 0) 
                {
                    //if((temp_TraseLedd1.KL.SpennType =="Veksl_avspenning" || temp_TraseLedd1.KL.SpennType == "Seksj_avspenning") && LedParter[j].løp == "Fiks pkt. til lodd avs.")
                    //{ LedParter[j].Spenner[q - 1].b2 = LedParter[j].Spenner[q - 1].b2 + LedParter[j].Spenner[q - 1].Kt_avst;  }
                    //else
                    { temp_TraseLedd1.KL.b1 = Math.Max(Math.Min(LedParter[j].Spenner[q - 1].b2, 0.5), -0.5); }
                } // Zigzag shall not exceed 0.5 m
                temp_TraseLedd1.KL.CalcSpan(SpennType);
                v = 0; //Ledd teller i sammensatt ledd temp_TraseLedd   
                while (temp_TraseLedd1.L < temp_TraseLedd1.KL.a)
                {
                    if (i < n - 1) { i++; v++; } else { break; } //Break from the inner loop
                    temp_TraseLedd0 = (TraseLedd)temp_TraseLedd1.Clone();
                    temp_TraseLedd1.L = temp_TraseLedd1.L + TraseLedder[i].L;
                    temp_TraseLedd1.Δϴ = temp_TraseLedd1.Δϴ + TraseLedder[i].Δϴ;
                    if (temp_TraseLedd1.Δϴ == 0) { temp_TraseLedd1.KL.R = 1e7; }
                    else { temp_TraseLedd1.KL.R = temp_TraseLedd1.L / temp_TraseLedd1.Δϴ; }
                    temp_TraseLedd1.KL.CalcSpan(SpennType);
                }
                if (temp_TraseLedd1.L < temp_TraseLedd1.KL.a) { break; }
                if (temp_TraseLedd1.L > temp_TraseLedd1.KL.a && v > 0)
                {
                    chopped_TraseLedd = (TraseLedd)TraseLedder[i].Clone();
                    int z = 0;//Counter for detecting offending input (eg: consecutive sharp turns in opposing directions.)
                    while (Math.Abs(temp_TraseLedd1.L - temp_TraseLedd1.KL.a) > 0.1)
                    {
                        if (z > 1000) { MessageBox.Show("Offending Input! ", "Error"); DisableOutput(); return; }
                        chopped_TraseLedd.L = Math.Max(0, temp_TraseLedd1.KL.a - (TraseLedder[i].x1 - xi));
                        chopped_TraseLedd.Δϴ = TraseLedder[i].Δϴ - TraseLedder[i].Calc_Δϴ(chopped_TraseLedd.L);
                        temp_TraseLedd1.L = temp_TraseLedd0.L + chopped_TraseLedd.L;
                        temp_TraseLedd1.Δϴ = temp_TraseLedd0.Δϴ + chopped_TraseLedd.Δϴ;
                        if (temp_TraseLedd1.Δϴ == 0) { temp_TraseLedd1.KL.R = 1e7; }
                        else { temp_TraseLedd1.KL.R = temp_TraseLedd1.L / temp_TraseLedd1.Δϴ; }
                        temp_TraseLedd1.KL.CalcSpan(SpennType);
                        z++;
                    }
                }
                if (LedParter[j].løp == "Fiks pkt. til lodd avs.")
                {
                    if ((LedParter[j].lengde + temp_TraseLedd1.KL.a) <= LedParter[j].max_lengde)
                    {
                        LedParter[j].Spenner[q] = (KL_span)temp_TraseLedd1.KL.Clone();
                        LedParter[j].Spenner[q].x1 = xi;
                        LedParter[j].Spenner[q].SpennType = SpennType;
                        xi = xi + LedParter[j].Spenner[q].a;
                        LedParter[j].Spenner[q].x2 = xi;
                        LedParter[j].antall_spenn = q + 1;
                        LedParter[j].lengde = LedParter[j].lengde + LedParter[j].Spenner[q].a;
                        LedParter[j].end = xi;  if (q == 0) { LedParter[j].Spenner[0].SpennType = "Fiks linje"; }
                        q++;
                        if (LengdeOverskrid == "Nei")
                        {
                            if (q == LedParter[j].max_antall_spenn - 2 && (xi < seksjPos || SeksjoneringSatt == true)) { SpennType = "Veksling"; }
                            else if (q == LedParter[j].max_antall_spenn - 2 && (xi >= seksjPos && SeksjoneringSatt == false)) { SpennType = "Seksjonering"; }
                            else if (q == LedParter[j].max_antall_spenn - 1 && (xi < seksjPos || SeksjoneringSatt == true))
                            {
                                if (Math.Abs(LedParter[j].Spenner[q - 1].R) < (double)numUpDnR_3_5spenn.Value)
                                {
                                    SpennType = "Veksl_5Spn_2nd";
                                    LedParter[j].antall_spenn = LedParter[j].antall_spenn - 3;
                                    LedParter[j].lengde = LedParter[j].lengde - LedParter[j].Spenner[q - 1].a - LedParter[j].Spenner[q - 2].a - LedParter[j].Spenner[q - 3].a;
                                    xi = xi - LedParter[j].Spenner[q - 1].a - LedParter[j].Spenner[q - 2].a - LedParter[j].Spenner[q - 3].a;
                                    LedParter[j].end = xi;
                                    q = q - 3;
                                    LengdeOverskrid = "Ja";
                                }
                                else { SpennType = "Veksl_avspenning"; }
                            }
                            else if (q == LedParter[j].max_antall_spenn - 1 && (xi >= seksjPos && SeksjoneringSatt == false))
                            {
                                if (Math.Abs(LedParter[j].Spenner[q - 1].R) < (double)numUpDnR_3_5spenn.Value)
                                {
                                    SpennType = "Seksj_5Spn_2nd";
                                    LedParter[j].antall_spenn = LedParter[j].antall_spenn - 3;
                                    LedParter[j].lengde = LedParter[j].lengde - LedParter[j].Spenner[q - 1].a - LedParter[j].Spenner[q - 2].a - LedParter[j].Spenner[q - 3].a;
                                    xi = xi - LedParter[j].Spenner[q - 1].a - LedParter[j].Spenner[q - 2].a - LedParter[j].Spenner[q - 3].a;
                                    LedParter[j].end = xi;
                                    q = q - 3;
                                    LengdeOverskrid = "Ja";
                                }
                                else { SpennType = "Seksj_avspenning"; }
                            }
                            else if (q == LedParter[j].max_antall_spenn)
                            {
                                j++; q = 0; 
                                if (SpennType == "Seksj_avspenning") { SeksjoneringSatt = true; }
                                if (j < 5) { LedParter[j].løp = "Lodd avs. til fiks pkt."; SpennType = "Normal"; LengdeOverskrid = "Nei"; LeddpartOvergang = "3spenn"; }
                            }
                        }
                        else if (LengdeOverskrid == "Ja")
                        {
                            if (SpennType == "Veksling")
                            {
                                if (Math.Abs(LedParter[j].Spenner[q - 1].R) < (double)numUpDnR_3_5spenn.Value)
                                {
                                    SpennType = "Veksl_5Spn_2nd";
                                    LedParter[j].antall_spenn = LedParter[j].antall_spenn - 3;
                                    LedParter[j].lengde = LedParter[j].lengde - LedParter[j].Spenner[q - 1].a - LedParter[j].Spenner[q - 2].a - LedParter[j].Spenner[q - 3].a;
                                    xi = xi - LedParter[j].Spenner[q - 1].a - LedParter[j].Spenner[q - 2].a - LedParter[j].Spenner[q - 3].a;
                                    LedParter[j].end = xi;
                                    q = q - 3;
                                }
                                else { SpennType = "Veksl_avspenning"; }
                            }
                            else if (SpennType == "Seksjonering")
                            {
                                if (Math.Abs(LedParter[j].Spenner[q - 1].R) < (double)numUpDnR_3_5spenn.Value)
                                {
                                    SpennType = "Seksj_5Spn_2nd";
                                    LedParter[j].antall_spenn = LedParter[j].antall_spenn - 3;
                                    LedParter[j].lengde = LedParter[j].lengde - LedParter[j].Spenner[q - 1].a - LedParter[j].Spenner[q - 2].a - LedParter[j].Spenner[q - 3].a;
                                    xi = xi - LedParter[j].Spenner[q - 1].a - LedParter[j].Spenner[q - 2].a - LedParter[j].Spenner[q - 3].a;
                                    LedParter[j].end = xi;
                                    q = q - 3;
                                }
                                else { SpennType = "Seksj_avspenning"; }
                            }
                            else if (SpennType == "Veksl_avspenning" || SpennType == "Seksj_avspenning")
                            {
                                j++; q = 0; 
                                if (SpennType == "Seksj_avspenning") { SeksjoneringSatt = true; }
                                if (j < 5) { LedParter[j].løp = "Lodd avs. til fiks pkt."; SpennType = "Normal"; LengdeOverskrid = "Nei"; LeddpartOvergang = "3spenn"; }
                            }
                            else if (SpennType == "Veksl_5Spn_2nd") { SpennType = "Veksl_5Spn_3rd"; }
                            else if (SpennType == "Veksl_5Spn_3rd") { SpennType = "Veksl_5Spn_4th"; }
                            else if (SpennType == "Veksl_5Spn_4th") { SpennType = "Veksl_5Spn_avsp"; }
                            else if (SpennType == "Seksj_5Spn_2nd") { SpennType = "Seksj_5Spn_3rd"; }
                            else if (SpennType == "Seksj_5Spn_3rd") { SpennType = "Seksj_5Spn_4th"; }
                            else if (SpennType == "Seksj_5Spn_4th") { SpennType = "Seksj_5Spn_avsp"; }
                            else if (SpennType == "Seksj_5Spn_avsp" || SpennType == "Veksl_5Spn_avsp")
                            {
                                j++; q = 0; 
                                if (SpennType == "Seksj_5Spn_avsp" ) { SeksjoneringSatt = true; }
                                if (j < 5) { LedParter[j].løp = "Lodd avs. til fiks pkt."; SpennType = "Normal"; LengdeOverskrid = "Nei"; LeddpartOvergang = "5spenn"; }
                            }
                        }
                    }
                    else if ((LedParter[j].lengde + temp_TraseLedd1.KL.a) > LedParter[j].max_lengde)
                    {
                        LengdeOverskrid = "Ja";
                        if (SpennType == "Veksl_avspenning" || SpennType == "Seksj_avspenning") //Trekk tilbakke to spenlengder og beregn spenner på nytt
                        {
                            LedParter[j].antall_spenn = LedParter[j].antall_spenn - 2;
                            LedParter[j].lengde = LedParter[j].lengde - LedParter[j].Spenner[q - 1].a - LedParter[j].Spenner[q - 2].a;
                            xi = xi - LedParter[j].Spenner[q - 1].a - LedParter[j].Spenner[q - 2].a;
                            LedParter[j].end = xi;
                            if (SpennType == "Veksl_avspenning") { SpennType = "Veksling"; }
                            else if (SpennType == "Seksj_avspenning") { SpennType = "Seksjonering"; }
                            q = q - 2;
                        }
                        else if (SpennType == "Veksling" || SpennType == "Seksjonering") //Trekk tilbakke en spenlengde og beregn spenn på nytt
                        {
                            LedParter[j].antall_spenn = LedParter[j].antall_spenn - 1;
                            LedParter[j].lengde = LedParter[j].lengde - LedParter[j].Spenner[q - 1].a;
                            xi = xi - LedParter[j].Spenner[q - 1].a;
                            LedParter[j].end = xi;
                            q = q - 1;
                        }
                        else if (SpennType == "Normal") //Trekk tilbakke en spenlengde og beregn spenn på nytt
                        {
                            LedParter[j].antall_spenn = LedParter[j].antall_spenn - 1;
                            LedParter[j].lengde = LedParter[j].lengde - LedParter[j].Spenner[q - 1].a;
                            xi = xi - LedParter[j].Spenner[q - 1].a;
                            LedParter[j].end = xi;
                            if (xi < seksjPos && SeksjoneringSatt == false) { SpennType = "Veksling"; }
                            else { SpennType = "Seksjonering"; }
                            q = q - 1;
                        }
                        else if (SpennType == "Veksl_5Spn_avsp" || SpennType == "Seksj_5Spn_avsp")
                        {
                            LedParter[j].antall_spenn = LedParter[j].antall_spenn - 4;
                            double trekk_bak = LedParter[j].Spenner[q - 1].a + LedParter[j].Spenner[q - 2].a + LedParter[j].Spenner[q - 3].a + LedParter[j].Spenner[q - 4].a;
                            LedParter[j].lengde = LedParter[j].lengde - trekk_bak;
                            xi = xi - trekk_bak;
                            LedParter[j].end = xi;
                            if (SpennType == "Veksl_5Spn_avsp") { SpennType = "Veksl_5Spn_2nd"; }
                            else { SpennType = "Seksj_5Spn_2nd"; }
                            q = q - 4;
                        }
                        else if (SpennType == "Veksl_5Spn_4th" || SpennType == "Seksj_5Spn_4th")
                        {
                            LedParter[j].antall_spenn = LedParter[j].antall_spenn - 3;
                            double trekk_bak = LedParter[j].Spenner[q - 1].a + LedParter[j].Spenner[q - 2].a + LedParter[j].Spenner[q - 3].a;
                            LedParter[j].lengde = LedParter[j].lengde - trekk_bak;
                            xi = xi - trekk_bak;
                            LedParter[j].end = xi;
                            if (SpennType == "Veksl_5Spn_4th") { SpennType = "Veksl_4Spn_2nd"; }
                            else { SpennType = "Seksj_4Spn_2nd"; }
                            q = q - 3;
                        }
                    }
                }
                else if (LedParter[j].løp == "Lodd avs. til fiks pkt.")
                {
                    if ((LedParter[j].lengde + temp_TraseLedd1.KL.a) <= LedParter[j].max_lengde && LedParter[j].antall_spenn <= LedParter[j].max_antall_spenn - 1)
                    {
                        if (j > 0 && q <= 1 && LeddpartOvergang == "3spenn")
                        {
                            if (q == 0)
                            {
                                LedParter[j].Spenner[q] = (KL_span)(LedParter[j - 1].Spenner[LedParter[j - 1].antall_spenn - 3].Clone());
                                LedParter[j].Spenner[q].b1 = LedParter[j].Spenner[q].Lu * Math.Sign(LedParter[j].Spenner[q].Mast_zpos);
                                LedParter[j].Spenner[q].b2 = LedParter[j].Spenner[q].b2 + (LedParter[j - 1].Spenner[LedParter[j - 1].antall_spenn - 2].Kt_avst) * (LedParter[j - 1].Spenner[LedParter[j - 1].antall_spenn - 2].sgn);
                                LedParter[j].Spenner[q].SpennType = LedParter[j - 1].Spenner[LedParter[j - 1].antall_spenn - 1].SpennType;
                                xi = LedParter[j].Spenner[q].x1 + LedParter[j].Spenner[q].a;
                                LedParter[j].start = xi;
                                LedParter[j].antall_spenn = q + 1;
                                LedParter[j].lengde = LedParter[j].lengde + LedParter[j].Spenner[q].a;
                                LedParter[j].Spenner[q].Calc_FdB1_FdB2_c(LedParter[j].Spenner[q].a, LedParter[j].Spenner[q].b1, LedParter[j].Spenner[q].b2); // Beregn sidekrefterfor avspenningsfspenn
                                LedParter[j].end = xi; q++;
                            }
                            else if (q == 1)
                            {
                                LedParter[j].Spenner[q] = (KL_span)LedParter[j - 1].Spenner[LedParter[j - 1].antall_spenn - 2].Clone();
                                LedParter[j].Spenner[q].b1 = LedParter[j].Spenner[q].b1 + (LedParter[j].Spenner[q].Kt_avst) * (LedParter[j].Spenner[q].sgn);
                                LedParter[j].Spenner[q].b2 = LedParter[j].Spenner[q].b2 + (LedParter[j].Spenner[q].Kt_avst) * (LedParter[j].Spenner[q].sgn);
                                xi = LedParter[j].Spenner[q].x1 + LedParter[j].Spenner[q].a;
                                LedParter[j].antall_spenn = q + 1;
                                LedParter[j].lengde = LedParter[j].lengde + LedParter[j].Spenner[q].a;
                                LedParter[j].end = xi; q++; SpennType = "Normal";
                            }
                        }
                        else if (j > 0 && q <= 3 && LeddpartOvergang == "5spenn")
                        {
                            if (q == 0)
                            {
                                LedParter[j].Spenner[q] = (KL_span)(LedParter[j - 1].Spenner[LedParter[j - 1].antall_spenn - 5].Clone());
                                LedParter[j].Spenner[q].b1 = LedParter[j].Spenner[q].Lu * Math.Sign(LedParter[j].Spenner[q].Mast_zpos);
                                LedParter[j].Spenner[q].b2 = LedParter[j].Spenner[q].b2 + (LedParter[j - 1].Spenner[LedParter[j - 1].antall_spenn - 4].Kt_avst * LedParter[j].Spenner[q].sgn);
                                LedParter[j].Spenner[q].SpennType = LedParter[j - 1].Spenner[LedParter[j - 1].antall_spenn - 1].SpennType;
                                xi = LedParter[j].Spenner[q].x1 + LedParter[j].Spenner[q].a;
                                LedParter[j].start = xi;
                                LedParter[j].antall_spenn = q + 1;
                                LedParter[j].lengde = LedParter[j].lengde + LedParter[j].Spenner[q].a;
                                LedParter[j].end = xi; q++;
                            }
                            else if (0 < q && q <= 3)
                            {
                                LedParter[j].Spenner[q] = (KL_span)LedParter[j - 1].Spenner[LedParter[j - 1].antall_spenn - (5 - q)].Clone();
                                LedParter[j].Spenner[q].b1 = LedParter[j].Spenner[q].b1 + (LedParter[j].Spenner[q].Kt_avst * LedParter[j].Spenner[q].sgn);
                                LedParter[j].Spenner[q].b2 = LedParter[j].Spenner[q].b2 + (LedParter[j].Spenner[q].Kt_avst * LedParter[j].Spenner[q].sgn);
                                xi = LedParter[j].Spenner[q].x1 + LedParter[j].Spenner[q].a;
                                LedParter[j].antall_spenn = q + 1;
                                LedParter[j].lengde = LedParter[j].lengde + LedParter[j].Spenner[q].a;
                                LedParter[j].end = xi; q++;
                            }
                        }
                        else
                        {
                            if (j == 0 && q == 0 && Math.Abs(temp_TraseLedd1.KL.R) < (double)numUpDnR_3_5spenn.Value && SpennType != "Veksl_5Spn_avsp") 
                            { 
                                MessageBox.Show("Lodd avspenning på starten av krappe kurv!"); DisableOutput(); return; 
                            }
                            else if (j == 0 && q == 0 && Math.Abs(temp_TraseLedd1.KL.R) >= (double)numUpDnR_3_5spenn.Value && SpennType != "Veksl_avspenning") 
                            { SpennType = "Veksl_avspenning"; }
                            else if (j == 0 && q == 1 && LedParter[j].Spenner[q-1].SpennType == "Veksl_avspenning" && SpennType != "Veksling")
                            {
                                SpennType = "Veksling";
                                LedParter[j].Spenner[q - 1].b2 = temp_TraseLedd1.KL.b1; LedParter[j].Spenner[q - 1].b1 = temp_TraseLedd1.KL.b2;
                            }

                            else if (j == 0 && q == 2 && SpennType != "Normal") { SpennType = "Normal"; }
                            else
                            {
                                LedParter[j].Spenner[q] = (KL_span)temp_TraseLedd1.KL.Clone();
                                LedParter[j].Spenner[q].x1 = xi;
                                LedParter[j].Spenner[q].SpennType = SpennType;
                                xi = xi + LedParter[j].Spenner[q].a;
                                LedParter[j].Spenner[q].x2 = xi;
                                LedParter[j].antall_spenn = q + 1;
                                LedParter[j].lengde = LedParter[j].lengde + LedParter[j].Spenner[q].a;
                                LedParter[j].end = xi; q++;
                                if (j == 0 && q == 1 && (SpennType == "Veksl_avspenning" || SpennType == "Veksl_5Spn_avsp"))
                                {
                                    SpennType = "Veksling"; LedParter[j].Spenner[q - 1].b2 = temp_TraseLedd1.KL.b1; LedParter[j].Spenner[q - 1].b1 = temp_TraseLedd1.KL.b2;
                                    if (Math.Abs(LedParter[j].Spenner[q - 1].R) < (double)numUpDnR_3_5spenn.Value)
                                    { SpennType = "Veksl_5Spn_2nd"; }
                                }
                            }
                        }
                    }
                    else if ((LedParter[j].lengde + temp_TraseLedd1.KL.a) > LedParter[j].max_lengde || LedParter[j].antall_spenn == LedParter[j].max_antall_spenn)
                    { {  LedParter[j].Spenner[LedParter[j].antall_spenn-1].SpennType = "Fiks linje"; j++; q = 0;
                            if (j < 5) { LedParter[j].start = xi; LedParter[j].løp = "Fiks pkt. til lodd avs."; SpennType = "Normal"; } } 
                    }
                }
                if ((xi - TraseLedder[0].x1) + temp_TraseLedd1.KL.a > L_tot || j==5) { break; }
            }
            for (int k = 0; k < 5; k++)
            {
                LedPart_leng[k].Text = (Math.Round(LedParter[k].lengde, 1)).ToString();
                LedPart_TallSpn[k].Text = Convert.ToString(LedParter[k].antall_spenn);
                LedPart_start[k].Text = (Math.Round(LedParter[k].start, 1)).ToString();
                LedPart_end[k].Text = (Math.Round(LedParter[k].end, 1)).ToString();
                if (LedParter[k].antall_spenn > 0) { nrUpDnLedpartNr.Maximum = k + 1; btnLeddPart[k].Enabled = true; }
                else { btnLeddPart[k].Enabled = false; }
            }
            EnableOutput();
        }
        private void LedPart1LøpRet_TextChanged(object sender, EventArgs e)
        {
            for (int i=1; i<5;i++)
            {
                if(LedPartLøpRet[i-1].Text== "|→Ͽ") { LedPartLøpRet[i].Text = "Ͼ←|"; }
                else {LedPartLøpRet[i].Text = "|→Ͽ"; }
            }
        }
        private void cmbSystemType_TextChanged(object sender, EventArgs e)
        {
            if (cmbSystemType.SelectedIndex == 0) {Sys.H = 15000*2;}
            else if (cmbSystemType.SelectedIndex == 1) {Sys.H = 10000 * 2;}
            else if (cmbSystemType.SelectedIndex == 2) {Sys.H = 7060 * 2; }
            else {  Sys.H = 10000 * 2;  }
            txtHca.Text = (Math.Round(Sys.H * 1e-3 / 2, 2)).ToString();
            txtHcw.Text = (Math.Round(Sys.H * 1e-3 / 2, 2)).ToString();
            Sys.Ktwire = new Wire(OCLWireTable.DT.Rows.Find("AC_120_Cu_ETP"));
            Sys.Blwire = new Wire(OCLWireTable.DT.Rows.Find("DIN_48_201_70_BzII"));
            Sys.CalcParams();
            txtVindKraft.Text = (Math.Round(Sys.Fw, 1)).ToString();
            //Wiretype may change here.
            //E(R) may change as well (both the function and the plot)
        }
        private void cmbVind_TextChanged(object sender, EventArgs e)
        {
            Sys.Vw = Convert.ToDouble(txtVind_kast.Text);
            Sys.CalcParams();
            txtVindKraft.Text = (Math.Round(Sys.Fw, 1)).ToString();
        }
        private void cmbLo_TextChanged(object sender, EventArgs e)
        {
            if (cmbLo.SelectedIndex == 0) { Sys.lo = 65; }
            else if (cmbLo.SelectedIndex == 1) { Sys.lo = 70; }
            else if (cmbLo.SelectedIndex == 2) { Sys.lo = 75; }
            else { Sys.lo = 65; }
        }
        private void numUpDnFmin_TextChanged(object sender, EventArgs e){Sys.Fdmin = (double)numUpDnFmin.Value; }

        private void LeddLeng_ValueChanged(object sender, EventArgs e)
        {
            if (ckBxkm.Checked == false)
            {
                double p = Convert.ToDouble(LeddStart[0].Text);
                for (int i = 0; i < 10; i++)
                {
                    p = p + (double)LeddLeng[i].Value;
                    LeddEnd[i].Text = Convert.ToString(p);
                    if (i > 0) { LeddStart[i].Text = LeddEnd[i - 1].Text; }
                }
            }
        }
        private void LeddEnd1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            { e.Handled = true; }
            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            { e.Handled = true; }
        }
        private void btnTrasePlot_Click(object sender, EventArgs e)
        {
            for (int i = Application.OpenForms.Count - 1; i >= 0; i--)
            {
                if (Application.OpenForms[i].Text != "KL Span")
                    Application.OpenForms[i].Close();
            }
            TrasePlot.Activate();
            if (TrasePlot.IsDisposed) { TrasePlot = new TrasePlotForm(); }
            TrasePlot.Text = "Trase Plot";
            TrasePlot.Show();
            VindUtblTabel VindUTB = new VindUtblTabel(cmbE_R.SelectedIndex);
            j = (int)(nrUpDnLedpartNr.Value - 1); //n = (int) antall_ledd.Value;
            int spenn_nr = -1; // Velg spenn som skal vises. n=-1 betyr alle spenn i 1/2 ledningspart skal vises
            
            if (LedParter[j].antall_spenn < 1) { return; }
            
            if (rdBtnTrase.Checked == true)
            {
                plottrase.Orient(TraseLedder, n, LedParter[j]);
                plottrase.PlotCurves_trase(TrasePlot.PlotViewer, TraseLedder, LedParter[0], n);
            }
            else
            {
                plottrase.Orient(TraseLedder, n, LedParter[j]);
                if (rdBtnVUtbLedPart.Checked == true)
                {
                    spenn_nr = -1;//if (!ckBxSkjulUtbl.Checked) { spenn_nr = -1; }
                    //if(!ckBxSkjulUtbl.Checked && !ckBxVisMast.Checked) { spenn_nr = -1; }
                    //if(ckBxSkjulUtbl.Checked && !ckBxVisMast.Checked) { spenn_nr = -2; }
                    //if(ckBxVisMast.Checked) { spenn_nr = -3; }
                }
                else if (rdBtnVUtbSpan.Checked == true) { spenn_nr = (int)nrUpDnSpennNr.Value; }
                { plottrase.PlotCurves_ledpart(TrasePlot.PlotViewer, TraseLedder, LedParter[j], j, spenn_nr, VindUTB); }
            }
        }

        private void rdBtnVUtbLedPart_CheckedChanged(object sender, EventArgs e)
        { if (rdBtnVUtbLedPart.Checked) { nrUpDnLedpartNr.Enabled = true; nrUpDnSpennNr.Enabled = false; } }

        private void rdBtnVUtbSpan_CheckedChanged(object sender, EventArgs e)
        {
            int k = (int)nrUpDnLedpartNr.Value - 1;
            nrUpDnSpennNr.Maximum = LedParter[k].antall_spenn - 1;
            if (LedParter[k].løp == "Lodd avs. til fiks pkt.") { nrUpDnSpennNr.Minimum = 2; nrUpDnSpennNr.Maximum = LedParter[k].antall_spenn - 1; }
            else { nrUpDnSpennNr.Minimum = 1; nrUpDnSpennNr.Maximum = LedParter[k].antall_spenn - 2; }
            if (rdBtnVUtbSpan.Checked) { nrUpDnSpennNr.Enabled = true; nrUpDnSpennNr.Enabled = true; }
        }
        private void rdBtnTrase_CheckedChanged(object sender, EventArgs e)
        {
            if (rdBtnTrase.Checked) { nrUpDnLedpartNr.Enabled = false; nrUpDnSpennNr.Enabled = false; }
        }
        private void nrUpDnLedpartNr_ValueChanged(object sender, EventArgs e)
        {
            int k = (int)nrUpDnLedpartNr.Value - 1;
            if (LedParter[k].løp == "Lodd avs. til fiks pkt.") { nrUpDnSpennNr.Minimum = 2; nrUpDnSpennNr.Maximum = LedParter[k].antall_spenn - 1; }
            else { nrUpDnSpennNr.Minimum = 1; nrUpDnSpennNr.Maximum = LedParter[k].antall_spenn - 2; }
        }
        private void DisableOutput()
        { 
            btnLeddPart1.Enabled = false;       btnLeddPart2.Enabled = false; 
            btnLeddPart3.Enabled = false;       btnLeddPart4.Enabled = false;
            btnLeddPart5.Enabled = false;       btnTrasePlot.Enabled = false;
            PlotSelector.Enabled = false;
        }
        private void EnableOutput()
        {
            btnTrasePlot.Enabled = true;
            PlotSelector.Enabled = true;
            btnTrasePlot.Enabled = true;
            rdBtnTrase.Enabled = true;
            rdBtnVUtbLedPart.Enabled = true;
            rdBtnVUtbSpan.Enabled = true;
            btnLagrePlot.Enabled = true;
        }

        private void btnHentData_Click(object sender, EventArgs e)
        {
            OpenTraseFile.ShowDialog();
            string trasefileName = null;
            Excel.Application xlApp = new Excel.Application();
            object[,] data;
            Excel.Workbook xlWorkbook; Excel._Worksheet xlWorksheet; Excel.Range xlRange;
            trasefileName = OpenTraseFile.FileName;
            if((trasefileName.Contains(".xlsx") == false && trasefileName.Contains(".xls") == false) || trasefileName == "") { return; }
            xlApp.Workbooks.Close();
            try
            { xlWorkbook = xlApp.Workbooks.Open(trasefileName);
                  xlWorksheet = xlWorkbook.Sheets[1];  
                  xlRange = xlWorksheet.UsedRange;
                  data = xlRange.Value2;
                DataTable TraseDT = new DataTable();
                DataRow Row;
                // Create new Column in DataTable
                string cellVal = String.Empty;
                int rCnt=1; int cCnt = 1;
                for (cCnt = 1; cCnt <= xlRange.Columns.Count; cCnt++)
                {
                    var Column = new DataColumn();
                    Column.DataType = System.Type.GetType("System.String");
                    Column.ColumnName = cCnt.ToString();
                    TraseDT.Columns.Add(Column);
                    // Create row for Data Table
                    for (rCnt = 3; rCnt <= xlRange.Rows.Count; rCnt++)
                    {
                        try { cellVal = (data[rCnt, cCnt]).ToString(); }
                        catch (Microsoft.CSharp.RuntimeBinder.RuntimeBinderException) { return;}
                        // Add to the DataTable
                        if (cCnt == 1) { Row = TraseDT.NewRow(); Row[cCnt - 1] = cellVal; TraseDT.Rows.Add(Row); }
                        else { Row = TraseDT.Rows[rCnt - 3]; Row[cCnt - 1] = cellVal; }//TraseDT.Rows.Add(Row); } //
                    }
                }
                for (rCnt = 1, i = 0; rCnt <= xlRange.Rows.Count && i < 9; rCnt++, i++)
                {
                    TraseLedder[i].x1 = Convert.ToDouble(TraseDT.Rows[rCnt - 1][0]);
                    TraseLedder[i].x2 = Convert.ToDouble(TraseDT.Rows[rCnt - 1][1]);
                    if (Convert.ToString(TraseDT.Rows[rCnt - 1][2]) == "∞") { TraseLedder[i].R1 = 10e7; }
                    else { TraseLedder[i].R1 = Convert.ToDouble(TraseDT.Rows[rCnt - 1][2]); }
                    TraseLedder[i].R2 = TraseLedder[i].R1;
                    TraseLedder[i].L = TraseLedder[i].x2 - TraseLedder[i].x1;
                    if(Math.Abs(TraseLedder[i].R1) > 1e6) { TraseLedder[i].TypeKurve = "Rett linje"; }
                    else if (TraseLedder[i].R1 == 0) { TraseLedder[i].R1 = 1e7; TraseLedder[i].R2 = TraseLedder[i].R1; TraseLedder[i].TypeKurve = "Rett linje"; }
                    else 
                    { 
                        TraseLedder[i].TypeKurve = "Kurve";
                        if (Math.Sign(TraseLedder[i].R1) < 0) { TraseLedder[i].KurveRetning = "-"; }
                        else { TraseLedder[i].KurveRetning = "+"; }
                    }
                    if (i > 0)
                    {
                        if (TraseLedder[i].x1 > TraseLedder[i - 1].x2)
                        {
                            if (i < 10) { TraseLedder[i + 1] = TraseLedder[i].Clone(); }
                            TraseLedder[i].x2 = TraseLedder[i].x1;
                            TraseLedder[i].x1 = TraseLedder[i - 1].x2;
                            TraseLedder[i].L = TraseLedder[i].x2 - TraseLedder[i].x1;
                            TraseLedder[i].R2 = TraseLedder[i].R1;
                            TraseLedder[i].R1 = TraseLedder[i - 1].R2;
                            TraseLedder[i].TypeKurve = "Overgang";
                            i++;
                        }
                    }
                    n = i + 1;
                }
                //antall_ledd.Value = i;
                //n = (int)antall_ledd.Value;
                antall_ledd.Value = n;

                for (int i = 0; i < 10; i++)
                {
                    LeddStart[i].Text = Convert.ToString(TraseLedder[i].x1);
                    LeddLeng[i].Text = Convert.ToString(TraseLedder[i].L);
                    LeddEnd[i].Text = Convert.ToString(TraseLedder[i].x2);
                    TypeKurve[i].Text = TraseLedder[i].TypeKurve;
                    LeddRad[i].Text = Convert.ToString(TraseLedder[i].R1);
                    LeddRetn[i].Text = TraseLedder[i].KurveRetning;
                    lblLedd[i].Visible = true; LeddStart[i].Visible = true; LeddEnd[i].Visible = true; LeddLeng[i].Visible = true; TypeKurve[i].Visible = true;
                    if (TraseLedder[i].TypeKurve == "Kurve") { LeddRad[i].Visible = true; LeddRetn[i].Visible = true; }
                    else { LeddRad[i].Visible = false; LeddRetn[i].Visible = false; }
                }
                for (int i = n; i < 10; i++)
                {
                    lblLedd[i].Visible = false; LeddStart[i].Visible = false; LeddEnd[i].Visible = false; LeddLeng[i].Visible = false; TypeKurve[i].Visible = false;
                    LeddRad[i].Visible = false; LeddRetn[i].Visible = false;
                }
                numUpDnOffset.Minimum = 0;
                numUpDnOffset.Value = (decimal)TraseLedder[0].x1;
                xlApp.Workbooks.Close();
            }
            catch { MessageBox.Show("Data import error!"); xlApp.Workbooks.Close(); return; }
        }

        private void rdbtnImport_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbtnSkrive.Checked == true)
            { 
                btnHentData.Enabled = false; pnlSKriv.Enabled = true; pnlLeddParams.Enabled = true;
                numUpDnOffset.Enabled = true; numUpDnseksjPos.Enabled = true; btnOppdaterTraseLeng.Enabled = true; btnOppdaterTraseLeng.Show();
                for (int i = 0; i < 10; i++)
                {
                    if (ckBxkm.Checked == true) { LeddStart[0].Enabled = true; LeddEnd[i].Enabled = true; LeddLeng[i].Enabled = false; }
                    else { LeddStart[0].Enabled = false; LeddEnd[i].Enabled = false; LeddLeng[i].Enabled = true; }
                }
            }
            else { btnHentData.Enabled = true; pnlSKriv.Enabled = false; pnlLeddParams.Enabled = false; ckBxkm.Checked = true;
                 numUpDnOffset.Enabled = false; numUpDnseksjPos.Enabled = false; btnOppdaterTraseLeng.Hide();}
        }

        private void btnVindKart_Click(object sender, EventArgs e)
        {   System.Diagnostics.Process.Start(@".\Images\VindKartdel1.pdf"); }

        private void nmUpDnVbo_ValueChanged(object sender, EventArgs e)
        {   txtVind_kast.Text = Convert.ToString(Math.Round((double)numUpDnVbo.Value * Math.Sqrt(2.06)));    }

        private void cmbE_R_SelectedIndexChanged(object sender, EventArgs e) { Q.Close(); }

        private void btnOppdaterTraseLeng_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < n; i++)
            {
                decimal tempval;
                try {tempval = Convert.ToDecimal(LeddEnd[i].Text) - Convert.ToDecimal(LeddStart[i].Text);}
                catch { MessageBox.Show("Error"); return; }
                if (tempval<=0) { MessageBox.Show("Offending Input! \n (Ikke konsekvent punkter!)", "Error"); return; }
                else { LeddLeng[i].Value = tempval; }
            }
        }

        private void btnExportmappe_Click(object sender, EventArgs e)
        {
            DialogResult result = SaveResultsTo.ShowDialog();
            if (result == DialogResult.OK && !string.IsNullOrWhiteSpace(SaveResultsTo.SelectedPath))
            { lblEksportmappe.Text = Convert.ToString(SaveResultsTo.SelectedPath); }
            prosjektmappe = lblEksportmappe.Text;
        }

        private void btnHentProsjektInfo_Click(object sender, EventArgs e)
        {
            OpenProsjektFile.ShowDialog();
            string ProsjektfileName = null;
            Excel.Application xlApp = new Excel.Application();
            object[,] data;
            Excel.Workbook xlWorkbook; Excel._Worksheet xlWorksheet; Excel.Range xlRange;
            ProsjektfileName = OpenProsjektFile.FileName;
            if ((ProsjektfileName.Contains(".xlsx") == false && ProsjektfileName.Contains(".xls") == false )|| ProsjektfileName == "") { return; }
            xlApp.Workbooks.Close();
            try
            {
                xlWorkbook = xlApp.Workbooks.Open(ProsjektfileName);
                xlWorksheet = xlWorkbook.Sheets[1];
                xlRange = xlWorksheet.UsedRange;
                data = xlRange.Value2;
                DataTable ProjInfoDT = new DataTable();
                DataRow Row;
                // Create new Column in DataTable
                string cellVal = String.Empty;
                int rCnt = 1; int cCnt = 1;
                for (cCnt = 1; cCnt <= xlRange.Columns.Count; cCnt++)
                {
                    var Column = new DataColumn();
                    Column.DataType = System.Type.GetType("System.String");
                    Column.ColumnName = cCnt.ToString();
                    ProjInfoDT.Columns.Add(Column);
                    // Create row for Data Table
                    for (rCnt = 1; rCnt <= xlRange.Rows.Count; rCnt++)
                    {
                        try { cellVal = (data[rCnt, cCnt]).ToString(); }
                        catch (Microsoft.CSharp.RuntimeBinder.RuntimeBinderException) { MessageBox.Show("Prosjekt info import error!"); return; }
                        //Add to the DataTable
                        if (cCnt == 1) {  Row = ProjInfoDT.NewRow(); Row[cCnt - 1] = cellVal; ProjInfoDT.Rows.Add(Row); }
                        else { Row = ProjInfoDT.Rows[rCnt - 1]; Row[cCnt - 1] = cellVal; }
                    }
                }
                txtProjectName.Text = Convert.ToString(ProjInfoDT.Rows[0][1]);
                txtProjectNumber.Text = Convert.ToString(ProjInfoDT.Rows[1][1]);
                txtStartpkt.Text = Convert.ToString(ProjInfoDT.Rows[2][1]);
                txtSluttpkt.Text = Convert.ToString(ProjInfoDT.Rows[3][1]);
                txtUtfortav.Text = Convert.ToString(ProjInfoDT.Rows[4][1]);
                txtUtfortdato.Text = Convert.ToString(ProjInfoDT.Rows[5][1]);
                try { numUpDnStrekHast.Value = Convert.ToDecimal(ProjInfoDT.Rows[6][1]); } catch { }
                try { 
                    //cmbSystemType.SelectedText = Convert.ToString(ProjInfoDT.Rows[7][1]);
                    if (Convert.ToString(ProjInfoDT.Rows[7][1]) == "Other") { cmbSystemType.SelectedIndex = 3; }
                    else if (Convert.ToString(ProjInfoDT.Rows[7][1]) == "S35") { cmbSystemType.SelectedIndex = 2; }
                    else if (Convert.ToString(ProjInfoDT.Rows[7][1]) == "S20") { cmbSystemType.SelectedIndex = 1; }
                    else { cmbSystemType.SelectedIndex = 0; }
                } catch { }
                try {
                    if (Convert.ToString(ProjInfoDT.Rows[8][1]) == "75") { cmbLo.SelectedIndex = 2; }
                    else if (Convert.ToString(ProjInfoDT.Rows[8][1]) == "70") { cmbLo.SelectedIndex = 1; }
                    else { cmbLo.SelectedIndex = 0; }
                } catch { }
                try { 
                    //cmbE_R.SelectedText = Convert.ToString(ProjInfoDT.Rows[9][1]);
                    if (Convert.ToString(ProjInfoDT.Rows[9][1]) == "Type 3") { cmbE_R.SelectedIndex = 2; }
                    else if (Convert.ToString(ProjInfoDT.Rows[9][1]) == "Type 2") { cmbE_R.SelectedIndex = 1; }
                    else { cmbE_R.SelectedIndex = 0; }
                } catch { }
                try { numUpDnVbo.Value = Convert.ToDecimal(ProjInfoDT.Rows[10][1]); } catch { }
                try { numUpDnFmin.Value = Convert.ToDecimal(ProjInfoDT.Rows[11][1]); } catch { }
                try { numUpDnR_3_5spenn.Value = Convert.ToDecimal(ProjInfoDT.Rows[12][1]); } catch { }
                /*try { numUpDnFmin.Value = Convert.ToDecimal(ProjInfoDT.Rows[11][1]); } catch { }
                try { numUpDnR_3_5spenn.Value = Convert.ToDecimal(ProjInfoDT.Rows[12][1]); } catch { }*/

                xlApp.Workbooks.Close();
            }
            catch { MessageBox.Show("Prosjekt info import error! \n Skjekk at filen finnes i mappa og data i filen er satt riktig!"); xlApp.Workbooks.Close(); }
        }
        private void btnLagreProsjektInfo_Click(object sender, EventArgs e)
        {
            if (lblEksportmappe.Text == "Mappe er ikke velget enda!") { MessageBox.Show("Først velg mappe for data lagring!"); return; }
            try
            {
                string cellVal = String.Empty;
                ProsjektInfofileName = Convert.ToString(lblEksportmappe.Text + "\\ProsjektInfo.xls");
                DataSet ProsjektInfoDT = new DataSet();
                //Creat new table.
                DataTable DTable = new DataTable();
                DataColumn column;
                //New column col1
                column = new DataColumn();
                DataRow row;
                column.DataType = System.Type.GetType("System.String");
                column.ColumnName = "col1";
                column.ReadOnly = true;
                column.Unique = true;
                // Add the column to the table.
                DTable.Columns.Add(column);

                //New column col2
                column = new DataColumn();
                column.DataType = System.Type.GetType("System.String");
                column.ColumnName = "col2";
                column.ReadOnly = false;
                column.Unique = false;
                // Add the column to the table.
                DTable.Columns.Add(column);

                row = DTable.NewRow();
                row["col1"] = "Prosjekt Navn/ID";       row["col2"] = txtProjectName.Text;
                DTable.Rows.Add(row);
                row = DTable.NewRow();
                row["col1"] = "Streknings nummer/ID";   row["col2"] = txtProjectNumber.Text;
                DTable.Rows.Add(row);
                row = DTable.NewRow();
                row["col1"] = "Start punkt";            row["col2"] = txtStartpkt.Text;
                DTable.Rows.Add(row);
                row = DTable.NewRow();
                row["col1"] = "Slutt punkt";            row["col2"] = txtSluttpkt.Text;
                DTable.Rows.Add(row);
                row = DTable.NewRow();
                row["col1"] = "Utført av";              row["col2"] = txtUtfortav.Text;
                DTable.Rows.Add(row);
                row = DTable.NewRow();
                row["col1"] = "Utført dato";            row["col2"] = txtUtfortdato.Text;
                DTable.Rows.Add(row);
                row = DTable.NewRow();
                row["col1"] = "Hastighet klasse";       row["col2"] = Convert.ToString(numUpDnStrekHast.Value);
                DTable.Rows.Add(row);
                //Sjekk at det er ikke noen manglende data.
                for (int f = 0; f < 7; f++)
                {
                    if (Convert.ToString(DTable.Rows[f][1]) == "") { MessageBox.Show("Prosjekt info er ikke ferdig utfylt! \n Data er ikke lagret! "); return; }
                }

                row = DTable.NewRow();
                row["col1"] = "System type";            row["col2"] = Convert.ToString(cmbSystemType.SelectedItem);
                DTable.Rows.Add(row);
                row = DTable.NewRow();
                row["col1"] = "Maks spennlengde (Lo)";  row["col2"] = cmbLo.Text;
                DTable.Rows.Add(row);
                row = DTable.NewRow();
                row["col1"] = "Vindutblåsningskurve type"; row["col2"] = cmbE_R.Text;
                DTable.Rows.Add(row);
                row = DTable.NewRow();
                row["col1"] = "Vind hastighet (Vbo)"; row["col2"] = Convert.ToString(numUpDnVbo.Value);
                DTable.Rows.Add(row);
                row = DTable.NewRow();
                row["col1"] = "Fmin lettdireksjonsstag"; row["col2"] = Convert.ToString(numUpDnFmin.Value);
                DTable.Rows.Add(row);
                row = DTable.NewRow();
                row["col1"] = "R grense for 5 spenn avspenning"; row["col2"] = Convert.ToString(numUpDnR_3_5spenn.Value);
                DTable.Rows.Add(row);
                row = DTable.NewRow();
                row["col1"] = "Offset mellom KL start og trase start"; row["col2"] = Convert.ToString(numUpDnOffset.Value);
                DTable.Rows.Add(row);
                row = DTable.NewRow();
                row["col1"] = "Seksjonering etter"; row["col2"] = Convert.ToString(numUpDnseksjPos.Value);
                DTable.Rows.Add(row);
                ProsjektInfoDT.Tables.Add(DTable);
                SheetNames[0] = "Proj.Info";
                CreateExcel(ProsjektInfoDT, ProsjektInfofileName, SheetNames);
            }
            catch { }
        }

        public static void CreateExcel(DataSet ds, string excelPath, string[] SheetNames)
        {
            Excel.Application xlApp;
            Excel.Workbook xlWorkBook;
            Excel.Worksheet xlWorkSheet;
            object misValue = System.Reflection.Missing.Value;

            try
            {
                xlApp = new Excel.Application();
                xlWorkBook = xlApp.Workbooks.Add(misValue);
                for (int p = 0; p < ds.Tables.Count; p++)
                {
                    if (p < 3) { xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(p+1); }
                    else {xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.Add(After: xlWorkBook.Sheets[xlWorkBook.Sheets.Count]); }
                    xlWorkSheet.Name = SheetNames[p];
                    for (int i = 0; i < ds.Tables[p].Rows.Count; i++)
                    {
                        for (int j = 0; j < ds.Tables[p].Columns.Count; j++)
                        { xlWorkSheet.Cells[i + 1, j + 1] = ds.Tables[p].Rows[i].ItemArray[j].ToString(); }
                    }
                    releaseObject(xlWorkSheet);
                }
                xlWorkBook.SaveAs(excelPath, Excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
                xlWorkBook.Close(true, misValue, misValue);
                xlApp.Quit();
                releaseObject(xlWorkBook);
                releaseObject(xlApp);
            }
            catch (Exception ex)    {   throw ex;   }
        }

        private static void releaseObject(object obj)
        {
            try     {   System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);   obj = null; }
            catch   {   obj = null;     }
            finally {   GC.Collect();   }
        }

        private void ckBxkm_Click(object sender, EventArgs e)
        {
            if (ckBxkm.Checked == true) { btnOppdaterTraseLeng.Show(); } else { btnOppdaterTraseLeng.Hide(); }
            for (int i = 0; i < 10; i++)
            {
                if (ckBxkm.Checked == true) { LeddStart[0].Enabled = true; LeddEnd[i].Enabled = true; LeddLeng[i].Enabled = false; }
                else { LeddStart[0].Enabled = false; LeddEnd[i].Enabled = false; LeddLeng[i].Enabled = true; }
            }
        }

        private void btnLagreTrasedata_Click(object sender, EventArgs e)
        {
            if (lblEksportmappe.Text == "Mappe er ikke velget enda!") { MessageBox.Show("Først velg mappe for data lagring!"); return; }
            try
            {
                string cellVal = String.Empty;
                TrasedatafileName = Convert.ToString(lblEksportmappe.Text + "\\trasedata.xls");
                //Creat new table.
                DataTable DTable = new DataTable();
                DataColumn column;
                //New column col1
                column = new DataColumn();
                DataRow row;
                column.DataType = System.Type.GetType("System.String");
                column.ColumnName = "col1";
                column.ReadOnly = true;
                column.Unique = true;
                // Add the column to the table.
                DTable.Columns.Add(column);

                //New column col2
                column = new DataColumn();
                column.DataType = System.Type.GetType("System.String");
                column.ColumnName = "col2";
                column.ReadOnly = false;
                column.Unique = false;
                // Add the column to the table.
                DTable.Columns.Add(column);
                column = new DataColumn();
                column.DataType = System.Type.GetType("System.String");
                column.ColumnName = "col3";
                column.ReadOnly = false;
                column.Unique = false;
                // Add the column to the table.
                DTable.Columns.Add(column);
                
                row = DTable.NewRow();
                n = (int)antall_ledd.Value;
                row = DTable.NewRow();
                row["col1"] = "Startpunkt"; row["col2"] = "Endepunkt"; row["col3"] = "Sporradius";
                DTable.Rows.Add(row);
                row = DTable.NewRow();
                row["col1"] = "[m]"; row["col2"] = "[m]"; row["col3"] = "[m]";
                DTable.Rows.Add(row);
                for (int i = 0; i < n; i++)
                {
                    if (TypeKurve[i].Text != "Overgang")
                    {
                        row = DTable.NewRow();
                        row["col1"] = LeddStart[i].Text; row["col2"] = LeddEnd[i].Text;
                        if (TypeKurve[i].Text == "Rett linje") { row["col3"] = "0"; }//0 eller ∞
                        else { row["col3"] = LeddRad[i].Text; if (LeddRetn[i].Text == "-") { row["col3"] = "-" + row["col3"]; } }
                        DTable.Rows.Add(row);
                    }
                }
                TraseDSet.Tables.Add(DTable);
                SheetNames[0] = "trasedata";
                CreateExcel(TraseDSet, TrasedatafileName, SheetNames); 
            }
            catch { MessageBox.Show("Error!"); }
        }

        private void btnLagreledpartdata_Click(object sender, EventArgs e)
        {
            if (lblEksportmappe.Text == "Mappe er ikke velget enda!") { MessageBox.Show("Først velg mappe for data lagring!"); return; }
            try
            {
                DataSet LedpartDS = new DataSet();
                //Creat new table.
                DataTable DTable;
                DataColumn column;
                DataRow row;

                SheetNames[0] = "½Led.part 1"; SheetNames[1] = "½Led.part 2"; SheetNames[2] = "½Led.part 3"; SheetNames[3] = "½Led.part 4"; SheetNames[4] = "½Led.part 5";
                LedpartdatafileName = Convert.ToString(lblEksportmappe.Text + "\\Ledpartdata.xls");
                for (int j = 0; j < 5; j++) 
                {
                    if(LedParter[j].antall_spenn <= 1) { break; }
                DTable = new DataTable();
                column = new DataColumn();  column.DataType = System.Type.GetType("System.String");
                column.ColumnName = "col1"; DTable.Columns.Add(column);// Add the column to the table.

                column = new DataColumn();  column.DataType = System.Type.GetType("System.String");
                column.ColumnName = "col2"; DTable.Columns.Add(column);// Add the column to the table.

                column = new DataColumn();  column.DataType = System.Type.GetType("System.String");
                column.ColumnName = "col3"; DTable.Columns.Add(column);// Add the column to the table.

                column = new DataColumn();  column.DataType = System.Type.GetType("System.String");
                column.ColumnName = "col4"; DTable.Columns.Add(column);// Add the column to the table.

                column = new DataColumn();  column.DataType = System.Type.GetType("System.String");
                column.ColumnName = "col5"; DTable.Columns.Add(column);// Add the column to the table.

                column = new DataColumn();  column.DataType = System.Type.GetType("System.String");
                column.ColumnName = "col6"; DTable.Columns.Add(column);// Add the column to the table.

                column = new DataColumn();  column.DataType = System.Type.GetType("System.String");
                column.ColumnName = "col7"; DTable.Columns.Add(column);// Add the column to the table.

                column = new DataColumn();  column.DataType = System.Type.GetType("System.String");
                column.ColumnName = "col8"; DTable.Columns.Add(column);// Add the column to the table.

                column = new DataColumn();  column.DataType = System.Type.GetType("System.String");
                column.ColumnName = "col9"; DTable.Columns.Add(column);// Add the column to the table.

                column = new DataColumn();  column.DataType = System.Type.GetType("System.String");
                column.ColumnName = "col10";    DTable.Columns.Add(column);// Add the column to the table.

                column = new DataColumn();  column.DataType = System.Type.GetType("System.String");
                column.ColumnName = "col11";    DTable.Columns.Add(column);// Add the column to the table.

                column = new DataColumn();  column.DataType = System.Type.GetType("System.String");
                column.ColumnName = "col12";    DTable.Columns.Add(column);// Add the column to the table.

                column = new DataColumn();  column.DataType = System.Type.GetType("System.String");
                column.ColumnName = "col13";    DTable.Columns.Add(column);// Add the column to the table.

                row = DTable.NewRow();
                row["col1"] = "Start (x1)"; row["col2"] = "End (x2)"; row["col3"] = "Radius (R)"; row["col4"] = "Spennlengde (a)";
                row["col5"] = "b1"; row["col6"] = "b2"; row["col7"] = "Fd1"; row["col8"] = "Fd2";
                row["col9"] = "c"; row["col10"] = "E"; row["col11"] = "e_l"; row["col12"] = "e_r"; row["col13"] = "Spenn type";
                DTable.Rows.Add(row);

                row = DTable.NewRow();
                row["col1"] = "[m]"; row["col2"] = "[m]"; row["col3"] = "[m]"; row["col4"] = "[m]";
                row["col5"] = "[m]"; row["col6"] = "[m]"; row["col7"] = "[N]"; row["col8"] = "[N]";
                row["col9"] = "[m]"; row["col10"] = "[m]"; row["col11"] = "[m]"; row["col12"] = "[m]"; row["col13"] = "--";
                DTable.Rows.Add(row);
                for (int k=0; k < LedParter[j].antall_spenn; k++)
                {
                    row = DTable.NewRow();
                    row["col1"] = Math.Round(LedParter[j].Spenner[k].x1,0); row["col2"] = Math.Round(LedParter[j].Spenner[k].x2,0); row["col3"] = Math.Round(LedParter[j].Spenner[k].R,0 ) * Convert.ToDouble(Math.Abs(LedParter[j].Spenner[k].R)<1e6);
                    row["col4"] = Math.Round(LedParter[j].Spenner[k].a,1); row["col5"] = Math.Round(LedParter[j].Spenner[k].b1,2); row["col6"] = Math.Round(LedParter[j].Spenner[k].b2,2);
                    row["col7"] = Math.Round(LedParter[j].Spenner[k].Fd_B1,2); row["col8"] = Math.Round(LedParter[j].Spenner[k].Fd_B2,2); row["col9"] = Math.Round(LedParter[j].Spenner[k].c,2);
                    row["col10"] = Math.Round(LedParter[j].Spenner[k].E,2); row["col11"] = Math.Round(LedParter[j].Spenner[k].e_l,2); row["col12"] = Math.Round(LedParter[j].Spenner[k].e_r,2);
                    row["col13"] = LedParter[j].Spenner[k].SpennType; 

                    DTable.Rows.Add(row);
                }
                LedpartDS.Tables.Add(DTable);
                }
                CreateExcel(LedpartDS, LedpartdatafileName, SheetNames);
            }
            catch { MessageBox.Show("Error!"); }
        }

        private void btnLagrePlot_Click(object sender, EventArgs e)
        {
            if (lblEksportmappe.Text == "Mappe er ikke velget enda!") { MessageBox.Show("Først velg mappe for data lagring!"); return; }
            //try
            //{
            string filename;
                //bool temp_bool = rdBtnTrase.Checked; int temp_ledpart_nr = ;  int temp_spenn_nr;

                TrasePlot.Activate();
                if (TrasePlot.IsDisposed) { TrasePlot = new TrasePlotForm(); }
                TrasePlot.Text = String.Concat("Trasens Plot fra ", Convert.ToString((int)TraseLedder[0].x1), " til ", Convert.ToString((int)TraseLedder[n - 1].x2));
            //rdBtnTrase.Checked = true;
                plottrase.Orient(TraseLedder, n, LedParter[0]);
                plottrase.PlotCurves_trase(TrasePlot.PlotViewer, TraseLedder, LedParter[0], n);
                filename = String.Concat(lblEksportmappe.Text,"\\", TrasePlot.Text,".png"); //\\Plots\\
                PngExporter.Export(TrasePlot.PlotViewer.ActualModel, @filename, 600, 400, OxyColors.White);
                //rdBtnTrase.Checked = temp_bool;

                int spenn_nr = -1; j = 0;
                int start_spenn; int siste_spenn;
                for (int j = 0; LedParter[j].antall_spenn >= 1 && j < 4; j++)
                {
                    //if (LedParter[j].løp == "Lodd avs. til fiks pkt.") { start_spenn = Math.Min(2, LedParter[j].antall_spenn); sist_spenn = Math.Max(LedParter[j].antall_spenn - 1, 1); }
                    //else { start_spenn = 1; sist_spenn = Math.Max(LedParter[j].antall_spenn - 2, 1); }
                    plottrase.Orient(TraseLedder, n, LedParter[j]);
                    plottrase.PlotCurves_ledpart(TrasePlot.PlotViewer, TraseLedder, LedParter[j], j, spenn_nr, VindUTB);
                    filename = String.Concat(lblEksportmappe.Text,"\\Halv_Ledpart_", (int)LedParter[j].start,"_to_", (int)LedParter[j].end, ".png");
                    PngExporter.Export(TrasePlot.PlotViewer.ActualModel, @filename, 600, 400, OxyColors.White);
                }
            
                for (int j = 0; LedParter[j].antall_spenn > 1 && j < 4; j++)
                {
                    if (LedParter[j].løp == "Lodd avs. til fiks pkt.") { start_spenn = 2; siste_spenn = LedParter[j].antall_spenn - 1; }
                    else { start_spenn = 1; siste_spenn = LedParter[j].antall_spenn - 2; }    
                    for (spenn_nr = start_spenn; spenn_nr <= siste_spenn; spenn_nr++)
                    {
                        //if (LedParter[j].løp == "Lodd avs. til fiks pkt." && n == 0) { n++; }
                        //else if (LedParter[j].løp == "Fiks pkt. til lodd avs." && n == LedParter[j].max_antall_spenn) { n++; }
                        plottrase.Orient(TraseLedder, n, LedParter[j]);
                        { plottrase.PlotCurves_ledpart(TrasePlot.PlotViewer, TraseLedder, LedParter[j], j , spenn_nr, VindUTB); }
                        filename = String.Concat(lblEksportmappe.Text, "\\Halv_Ledpart_", (int)LedParter[j].start, "_to_", (int)LedParter[j].end, "_Spenn_", spenn_nr + 1,"_&_", spenn_nr + 2, ".png");
                        PngExporter.Export(TrasePlot.PlotViewer.ActualModel, @filename, 600, 400, OxyColors.White);
                    }
                }/**/
            //}
            //catch { MessageBox.Show("Error!"); }
        }
    }
}
