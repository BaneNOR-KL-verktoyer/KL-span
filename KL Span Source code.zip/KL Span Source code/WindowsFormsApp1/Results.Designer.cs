﻿namespace KLAppGlobal
{//partial class ResultsForm
    partial class ResultsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.CellA20 = new System.Windows.Forms.Label();
            this.CellB20 = new System.Windows.Forms.Label();
            this.CellC20 = new System.Windows.Forms.Label();
            this.CellD20 = new System.Windows.Forms.Label();
            this.CellE20 = new System.Windows.Forms.Label();
            this.CellF20 = new System.Windows.Forms.Label();
            this.CellG20 = new System.Windows.Forms.Label();
            this.CellH20 = new System.Windows.Forms.Label();
            this.CellI20 = new System.Windows.Forms.Label();
            this.CellJ20 = new System.Windows.Forms.Label();
            this.CellK20 = new System.Windows.Forms.Label();
            this.CellL20 = new System.Windows.Forms.Label();
            this.CellM20 = new System.Windows.Forms.Label();
            this.CellA19 = new System.Windows.Forms.Label();
            this.CellB19 = new System.Windows.Forms.Label();
            this.CellC19 = new System.Windows.Forms.Label();
            this.CellD19 = new System.Windows.Forms.Label();
            this.CellE19 = new System.Windows.Forms.Label();
            this.CellF19 = new System.Windows.Forms.Label();
            this.CellG19 = new System.Windows.Forms.Label();
            this.CellH19 = new System.Windows.Forms.Label();
            this.CellI19 = new System.Windows.Forms.Label();
            this.CellJ19 = new System.Windows.Forms.Label();
            this.CellK19 = new System.Windows.Forms.Label();
            this.CellL19 = new System.Windows.Forms.Label();
            this.CellM19 = new System.Windows.Forms.Label();
            this.CellA18 = new System.Windows.Forms.Label();
            this.CellB18 = new System.Windows.Forms.Label();
            this.CellC18 = new System.Windows.Forms.Label();
            this.CellD18 = new System.Windows.Forms.Label();
            this.CellE18 = new System.Windows.Forms.Label();
            this.CellF18 = new System.Windows.Forms.Label();
            this.CellG18 = new System.Windows.Forms.Label();
            this.CellH18 = new System.Windows.Forms.Label();
            this.CellI18 = new System.Windows.Forms.Label();
            this.CellJ18 = new System.Windows.Forms.Label();
            this.CellK18 = new System.Windows.Forms.Label();
            this.CellL18 = new System.Windows.Forms.Label();
            this.CellM18 = new System.Windows.Forms.Label();
            this.CellA17 = new System.Windows.Forms.Label();
            this.CellB17 = new System.Windows.Forms.Label();
            this.CellC17 = new System.Windows.Forms.Label();
            this.CellD17 = new System.Windows.Forms.Label();
            this.CellE17 = new System.Windows.Forms.Label();
            this.CellF17 = new System.Windows.Forms.Label();
            this.CellG17 = new System.Windows.Forms.Label();
            this.CellH17 = new System.Windows.Forms.Label();
            this.CellI17 = new System.Windows.Forms.Label();
            this.CellJ17 = new System.Windows.Forms.Label();
            this.CellK17 = new System.Windows.Forms.Label();
            this.CellL17 = new System.Windows.Forms.Label();
            this.CellM17 = new System.Windows.Forms.Label();
            this.CellA16 = new System.Windows.Forms.Label();
            this.CellB16 = new System.Windows.Forms.Label();
            this.CellC16 = new System.Windows.Forms.Label();
            this.CellD16 = new System.Windows.Forms.Label();
            this.CellE16 = new System.Windows.Forms.Label();
            this.CellF16 = new System.Windows.Forms.Label();
            this.CellG16 = new System.Windows.Forms.Label();
            this.CellH16 = new System.Windows.Forms.Label();
            this.CellI16 = new System.Windows.Forms.Label();
            this.CellJ16 = new System.Windows.Forms.Label();
            this.CellK16 = new System.Windows.Forms.Label();
            this.CellL16 = new System.Windows.Forms.Label();
            this.CellM16 = new System.Windows.Forms.Label();
            this.CellA15 = new System.Windows.Forms.Label();
            this.CellB15 = new System.Windows.Forms.Label();
            this.CellC15 = new System.Windows.Forms.Label();
            this.CellD15 = new System.Windows.Forms.Label();
            this.CellE15 = new System.Windows.Forms.Label();
            this.CellF15 = new System.Windows.Forms.Label();
            this.CellG15 = new System.Windows.Forms.Label();
            this.CellH15 = new System.Windows.Forms.Label();
            this.CellI15 = new System.Windows.Forms.Label();
            this.CellJ15 = new System.Windows.Forms.Label();
            this.CellK15 = new System.Windows.Forms.Label();
            this.CellL15 = new System.Windows.Forms.Label();
            this.CellM15 = new System.Windows.Forms.Label();
            this.CellA14 = new System.Windows.Forms.Label();
            this.CellB14 = new System.Windows.Forms.Label();
            this.CellC14 = new System.Windows.Forms.Label();
            this.CellD14 = new System.Windows.Forms.Label();
            this.CellE14 = new System.Windows.Forms.Label();
            this.CellF14 = new System.Windows.Forms.Label();
            this.CellG14 = new System.Windows.Forms.Label();
            this.CellH14 = new System.Windows.Forms.Label();
            this.CellI14 = new System.Windows.Forms.Label();
            this.CellJ14 = new System.Windows.Forms.Label();
            this.CellK14 = new System.Windows.Forms.Label();
            this.CellL14 = new System.Windows.Forms.Label();
            this.CellM14 = new System.Windows.Forms.Label();
            this.CellA13 = new System.Windows.Forms.Label();
            this.CellB13 = new System.Windows.Forms.Label();
            this.CellC13 = new System.Windows.Forms.Label();
            this.CellD13 = new System.Windows.Forms.Label();
            this.CellE13 = new System.Windows.Forms.Label();
            this.CellF13 = new System.Windows.Forms.Label();
            this.CellG13 = new System.Windows.Forms.Label();
            this.CellH13 = new System.Windows.Forms.Label();
            this.CellI13 = new System.Windows.Forms.Label();
            this.CellJ13 = new System.Windows.Forms.Label();
            this.CellK13 = new System.Windows.Forms.Label();
            this.CellL13 = new System.Windows.Forms.Label();
            this.CellM13 = new System.Windows.Forms.Label();
            this.CellA12 = new System.Windows.Forms.Label();
            this.CellB12 = new System.Windows.Forms.Label();
            this.CellC12 = new System.Windows.Forms.Label();
            this.CellD12 = new System.Windows.Forms.Label();
            this.CellE12 = new System.Windows.Forms.Label();
            this.CellF12 = new System.Windows.Forms.Label();
            this.CellG12 = new System.Windows.Forms.Label();
            this.CellH12 = new System.Windows.Forms.Label();
            this.CellI12 = new System.Windows.Forms.Label();
            this.CellJ12 = new System.Windows.Forms.Label();
            this.CellK12 = new System.Windows.Forms.Label();
            this.CellL12 = new System.Windows.Forms.Label();
            this.CellM12 = new System.Windows.Forms.Label();
            this.CellA11 = new System.Windows.Forms.Label();
            this.CellB11 = new System.Windows.Forms.Label();
            this.CellC11 = new System.Windows.Forms.Label();
            this.CellD11 = new System.Windows.Forms.Label();
            this.CellE11 = new System.Windows.Forms.Label();
            this.CellF11 = new System.Windows.Forms.Label();
            this.CellG11 = new System.Windows.Forms.Label();
            this.CellH11 = new System.Windows.Forms.Label();
            this.CellI11 = new System.Windows.Forms.Label();
            this.CellJ11 = new System.Windows.Forms.Label();
            this.CellK11 = new System.Windows.Forms.Label();
            this.CellL11 = new System.Windows.Forms.Label();
            this.CellM11 = new System.Windows.Forms.Label();
            this.CellA10 = new System.Windows.Forms.Label();
            this.CellB10 = new System.Windows.Forms.Label();
            this.CellC10 = new System.Windows.Forms.Label();
            this.CellD10 = new System.Windows.Forms.Label();
            this.CellE10 = new System.Windows.Forms.Label();
            this.CellF10 = new System.Windows.Forms.Label();
            this.CellG10 = new System.Windows.Forms.Label();
            this.CellH10 = new System.Windows.Forms.Label();
            this.CellI10 = new System.Windows.Forms.Label();
            this.CellJ10 = new System.Windows.Forms.Label();
            this.CellK10 = new System.Windows.Forms.Label();
            this.CellL10 = new System.Windows.Forms.Label();
            this.CellM10 = new System.Windows.Forms.Label();
            this.CellA09 = new System.Windows.Forms.Label();
            this.CellB09 = new System.Windows.Forms.Label();
            this.CellC09 = new System.Windows.Forms.Label();
            this.CellD09 = new System.Windows.Forms.Label();
            this.CellE09 = new System.Windows.Forms.Label();
            this.CellF09 = new System.Windows.Forms.Label();
            this.CellG09 = new System.Windows.Forms.Label();
            this.CellH09 = new System.Windows.Forms.Label();
            this.CellI09 = new System.Windows.Forms.Label();
            this.CellJ09 = new System.Windows.Forms.Label();
            this.CellK09 = new System.Windows.Forms.Label();
            this.CellL09 = new System.Windows.Forms.Label();
            this.CellM09 = new System.Windows.Forms.Label();
            this.CellA08 = new System.Windows.Forms.Label();
            this.CellB08 = new System.Windows.Forms.Label();
            this.CellC08 = new System.Windows.Forms.Label();
            this.CellD08 = new System.Windows.Forms.Label();
            this.CellE08 = new System.Windows.Forms.Label();
            this.CellF08 = new System.Windows.Forms.Label();
            this.CellG08 = new System.Windows.Forms.Label();
            this.CellH08 = new System.Windows.Forms.Label();
            this.CellI08 = new System.Windows.Forms.Label();
            this.CellJ08 = new System.Windows.Forms.Label();
            this.CellK08 = new System.Windows.Forms.Label();
            this.CellL08 = new System.Windows.Forms.Label();
            this.CellM08 = new System.Windows.Forms.Label();
            this.CellA07 = new System.Windows.Forms.Label();
            this.CellB07 = new System.Windows.Forms.Label();
            this.CellC07 = new System.Windows.Forms.Label();
            this.CellD07 = new System.Windows.Forms.Label();
            this.CellE07 = new System.Windows.Forms.Label();
            this.CellF07 = new System.Windows.Forms.Label();
            this.CellG07 = new System.Windows.Forms.Label();
            this.CellH07 = new System.Windows.Forms.Label();
            this.CellI07 = new System.Windows.Forms.Label();
            this.CellJ07 = new System.Windows.Forms.Label();
            this.CellK07 = new System.Windows.Forms.Label();
            this.CellL07 = new System.Windows.Forms.Label();
            this.CellM07 = new System.Windows.Forms.Label();
            this.CellA06 = new System.Windows.Forms.Label();
            this.CellB06 = new System.Windows.Forms.Label();
            this.CellC06 = new System.Windows.Forms.Label();
            this.CellD06 = new System.Windows.Forms.Label();
            this.CellE06 = new System.Windows.Forms.Label();
            this.CellF06 = new System.Windows.Forms.Label();
            this.CellG06 = new System.Windows.Forms.Label();
            this.CellH06 = new System.Windows.Forms.Label();
            this.CellI06 = new System.Windows.Forms.Label();
            this.CellJ06 = new System.Windows.Forms.Label();
            this.CellK06 = new System.Windows.Forms.Label();
            this.CellL06 = new System.Windows.Forms.Label();
            this.CellM06 = new System.Windows.Forms.Label();
            this.CellA05 = new System.Windows.Forms.Label();
            this.CellB05 = new System.Windows.Forms.Label();
            this.CellC05 = new System.Windows.Forms.Label();
            this.CellD05 = new System.Windows.Forms.Label();
            this.CellE05 = new System.Windows.Forms.Label();
            this.CellF05 = new System.Windows.Forms.Label();
            this.CellG05 = new System.Windows.Forms.Label();
            this.CellH05 = new System.Windows.Forms.Label();
            this.CellI05 = new System.Windows.Forms.Label();
            this.CellJ05 = new System.Windows.Forms.Label();
            this.CellK05 = new System.Windows.Forms.Label();
            this.CellL05 = new System.Windows.Forms.Label();
            this.CellM05 = new System.Windows.Forms.Label();
            this.CellA04 = new System.Windows.Forms.Label();
            this.CellB04 = new System.Windows.Forms.Label();
            this.CellC04 = new System.Windows.Forms.Label();
            this.CellD04 = new System.Windows.Forms.Label();
            this.CellE04 = new System.Windows.Forms.Label();
            this.CellF04 = new System.Windows.Forms.Label();
            this.CellG04 = new System.Windows.Forms.Label();
            this.CellH04 = new System.Windows.Forms.Label();
            this.CellI04 = new System.Windows.Forms.Label();
            this.CellJ04 = new System.Windows.Forms.Label();
            this.CellK04 = new System.Windows.Forms.Label();
            this.CellL04 = new System.Windows.Forms.Label();
            this.CellM04 = new System.Windows.Forms.Label();
            this.CellA03 = new System.Windows.Forms.Label();
            this.CellB03 = new System.Windows.Forms.Label();
            this.CellC03 = new System.Windows.Forms.Label();
            this.CellD03 = new System.Windows.Forms.Label();
            this.CellE03 = new System.Windows.Forms.Label();
            this.CellF03 = new System.Windows.Forms.Label();
            this.CellG03 = new System.Windows.Forms.Label();
            this.CellH03 = new System.Windows.Forms.Label();
            this.CellI03 = new System.Windows.Forms.Label();
            this.CellJ03 = new System.Windows.Forms.Label();
            this.CellK03 = new System.Windows.Forms.Label();
            this.CellL03 = new System.Windows.Forms.Label();
            this.CellM03 = new System.Windows.Forms.Label();
            this.CellA02 = new System.Windows.Forms.Label();
            this.CellM02 = new System.Windows.Forms.Label();
            this.CellL02 = new System.Windows.Forms.Label();
            this.CellK02 = new System.Windows.Forms.Label();
            this.CellJ02 = new System.Windows.Forms.Label();
            this.CellI02 = new System.Windows.Forms.Label();
            this.CellH02 = new System.Windows.Forms.Label();
            this.CellG02 = new System.Windows.Forms.Label();
            this.CellF02 = new System.Windows.Forms.Label();
            this.CellE02 = new System.Windows.Forms.Label();
            this.CellD02 = new System.Windows.Forms.Label();
            this.CellC02 = new System.Windows.Forms.Label();
            this.CellB02 = new System.Windows.Forms.Label();
            this.CellA01 = new System.Windows.Forms.Label();
            this.CellB01 = new System.Windows.Forms.Label();
            this.CellC01 = new System.Windows.Forms.Label();
            this.CellD01 = new System.Windows.Forms.Label();
            this.CellE01 = new System.Windows.Forms.Label();
            this.CellF01 = new System.Windows.Forms.Label();
            this.CellG01 = new System.Windows.Forms.Label();
            this.CellH01 = new System.Windows.Forms.Label();
            this.CellI01 = new System.Windows.Forms.Label();
            this.CellJ01 = new System.Windows.Forms.Label();
            this.CellK01 = new System.Windows.Forms.Label();
            this.CellL01 = new System.Windows.Forms.Label();
            this.CellM01 = new System.Windows.Forms.Label();
            this.CellA00 = new System.Windows.Forms.Label();
            this.CellB00 = new System.Windows.Forms.Label();
            this.CellC00 = new System.Windows.Forms.Label();
            this.CellD00 = new System.Windows.Forms.Label();
            this.CellE00 = new System.Windows.Forms.Label();
            this.CellF00 = new System.Windows.Forms.Label();
            this.CellG00 = new System.Windows.Forms.Label();
            this.CellH00 = new System.Windows.Forms.Label();
            this.CellI00 = new System.Windows.Forms.Label();
            this.CellJ00 = new System.Windows.Forms.Label();
            this.CellK00 = new System.Windows.Forms.Label();
            this.CellL00 = new System.Windows.Forms.Label();
            this.CellM00 = new System.Windows.Forms.Label();
            this.resultsFormBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.resultsFormBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.resultsFormBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resultsFormBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 13;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.Controls.Add(this.CellA20, 0, 20);
            this.tableLayoutPanel1.Controls.Add(this.CellB20, 1, 20);
            this.tableLayoutPanel1.Controls.Add(this.CellC20, 2, 20);
            this.tableLayoutPanel1.Controls.Add(this.CellD20, 3, 20);
            this.tableLayoutPanel1.Controls.Add(this.CellE20, 4, 20);
            this.tableLayoutPanel1.Controls.Add(this.CellF20, 5, 20);
            this.tableLayoutPanel1.Controls.Add(this.CellG20, 6, 20);
            this.tableLayoutPanel1.Controls.Add(this.CellH20, 7, 20);
            this.tableLayoutPanel1.Controls.Add(this.CellI20, 8, 20);
            this.tableLayoutPanel1.Controls.Add(this.CellJ20, 9, 20);
            this.tableLayoutPanel1.Controls.Add(this.CellK20, 10, 20);
            this.tableLayoutPanel1.Controls.Add(this.CellL20, 11, 20);
            this.tableLayoutPanel1.Controls.Add(this.CellM20, 12, 20);
            this.tableLayoutPanel1.Controls.Add(this.CellA19, 0, 19);
            this.tableLayoutPanel1.Controls.Add(this.CellB19, 1, 19);
            this.tableLayoutPanel1.Controls.Add(this.CellC19, 2, 19);
            this.tableLayoutPanel1.Controls.Add(this.CellD19, 3, 19);
            this.tableLayoutPanel1.Controls.Add(this.CellE19, 4, 19);
            this.tableLayoutPanel1.Controls.Add(this.CellF19, 5, 19);
            this.tableLayoutPanel1.Controls.Add(this.CellG19, 6, 19);
            this.tableLayoutPanel1.Controls.Add(this.CellH19, 7, 19);
            this.tableLayoutPanel1.Controls.Add(this.CellI19, 8, 19);
            this.tableLayoutPanel1.Controls.Add(this.CellJ19, 9, 19);
            this.tableLayoutPanel1.Controls.Add(this.CellK19, 10, 19);
            this.tableLayoutPanel1.Controls.Add(this.CellL19, 11, 19);
            this.tableLayoutPanel1.Controls.Add(this.CellM19, 12, 19);
            this.tableLayoutPanel1.Controls.Add(this.CellA18, 0, 18);
            this.tableLayoutPanel1.Controls.Add(this.CellB18, 1, 18);
            this.tableLayoutPanel1.Controls.Add(this.CellC18, 2, 18);
            this.tableLayoutPanel1.Controls.Add(this.CellD18, 3, 18);
            this.tableLayoutPanel1.Controls.Add(this.CellE18, 4, 18);
            this.tableLayoutPanel1.Controls.Add(this.CellF18, 5, 18);
            this.tableLayoutPanel1.Controls.Add(this.CellG18, 6, 18);
            this.tableLayoutPanel1.Controls.Add(this.CellH18, 7, 18);
            this.tableLayoutPanel1.Controls.Add(this.CellI18, 8, 18);
            this.tableLayoutPanel1.Controls.Add(this.CellJ18, 9, 18);
            this.tableLayoutPanel1.Controls.Add(this.CellK18, 10, 18);
            this.tableLayoutPanel1.Controls.Add(this.CellL18, 11, 18);
            this.tableLayoutPanel1.Controls.Add(this.CellM18, 12, 18);
            this.tableLayoutPanel1.Controls.Add(this.CellA17, 0, 17);
            this.tableLayoutPanel1.Controls.Add(this.CellB17, 1, 17);
            this.tableLayoutPanel1.Controls.Add(this.CellC17, 2, 17);
            this.tableLayoutPanel1.Controls.Add(this.CellD17, 3, 17);
            this.tableLayoutPanel1.Controls.Add(this.CellE17, 4, 17);
            this.tableLayoutPanel1.Controls.Add(this.CellF17, 5, 17);
            this.tableLayoutPanel1.Controls.Add(this.CellG17, 6, 17);
            this.tableLayoutPanel1.Controls.Add(this.CellH17, 7, 17);
            this.tableLayoutPanel1.Controls.Add(this.CellI17, 8, 17);
            this.tableLayoutPanel1.Controls.Add(this.CellJ17, 9, 17);
            this.tableLayoutPanel1.Controls.Add(this.CellK17, 10, 17);
            this.tableLayoutPanel1.Controls.Add(this.CellL17, 11, 17);
            this.tableLayoutPanel1.Controls.Add(this.CellM17, 12, 17);
            this.tableLayoutPanel1.Controls.Add(this.CellA16, 0, 16);
            this.tableLayoutPanel1.Controls.Add(this.CellB16, 1, 16);
            this.tableLayoutPanel1.Controls.Add(this.CellC16, 2, 16);
            this.tableLayoutPanel1.Controls.Add(this.CellD16, 3, 16);
            this.tableLayoutPanel1.Controls.Add(this.CellE16, 4, 16);
            this.tableLayoutPanel1.Controls.Add(this.CellF16, 5, 16);
            this.tableLayoutPanel1.Controls.Add(this.CellG16, 6, 16);
            this.tableLayoutPanel1.Controls.Add(this.CellH16, 7, 16);
            this.tableLayoutPanel1.Controls.Add(this.CellI16, 8, 16);
            this.tableLayoutPanel1.Controls.Add(this.CellJ16, 9, 16);
            this.tableLayoutPanel1.Controls.Add(this.CellK16, 10, 16);
            this.tableLayoutPanel1.Controls.Add(this.CellL16, 11, 16);
            this.tableLayoutPanel1.Controls.Add(this.CellM16, 12, 16);
            this.tableLayoutPanel1.Controls.Add(this.CellA15, 0, 15);
            this.tableLayoutPanel1.Controls.Add(this.CellB15, 1, 15);
            this.tableLayoutPanel1.Controls.Add(this.CellC15, 2, 15);
            this.tableLayoutPanel1.Controls.Add(this.CellD15, 3, 15);
            this.tableLayoutPanel1.Controls.Add(this.CellE15, 4, 15);
            this.tableLayoutPanel1.Controls.Add(this.CellF15, 5, 15);
            this.tableLayoutPanel1.Controls.Add(this.CellG15, 6, 15);
            this.tableLayoutPanel1.Controls.Add(this.CellH15, 7, 15);
            this.tableLayoutPanel1.Controls.Add(this.CellI15, 8, 15);
            this.tableLayoutPanel1.Controls.Add(this.CellJ15, 9, 15);
            this.tableLayoutPanel1.Controls.Add(this.CellK15, 10, 15);
            this.tableLayoutPanel1.Controls.Add(this.CellL15, 11, 15);
            this.tableLayoutPanel1.Controls.Add(this.CellM15, 12, 15);
            this.tableLayoutPanel1.Controls.Add(this.CellA14, 0, 14);
            this.tableLayoutPanel1.Controls.Add(this.CellB14, 1, 14);
            this.tableLayoutPanel1.Controls.Add(this.CellC14, 2, 14);
            this.tableLayoutPanel1.Controls.Add(this.CellD14, 3, 14);
            this.tableLayoutPanel1.Controls.Add(this.CellE14, 4, 14);
            this.tableLayoutPanel1.Controls.Add(this.CellF14, 5, 14);
            this.tableLayoutPanel1.Controls.Add(this.CellG14, 6, 14);
            this.tableLayoutPanel1.Controls.Add(this.CellH14, 7, 14);
            this.tableLayoutPanel1.Controls.Add(this.CellI14, 8, 14);
            this.tableLayoutPanel1.Controls.Add(this.CellJ14, 9, 14);
            this.tableLayoutPanel1.Controls.Add(this.CellK14, 10, 14);
            this.tableLayoutPanel1.Controls.Add(this.CellL14, 11, 14);
            this.tableLayoutPanel1.Controls.Add(this.CellM14, 12, 14);
            this.tableLayoutPanel1.Controls.Add(this.CellA13, 0, 13);
            this.tableLayoutPanel1.Controls.Add(this.CellB13, 1, 13);
            this.tableLayoutPanel1.Controls.Add(this.CellC13, 2, 13);
            this.tableLayoutPanel1.Controls.Add(this.CellD13, 3, 13);
            this.tableLayoutPanel1.Controls.Add(this.CellE13, 4, 13);
            this.tableLayoutPanel1.Controls.Add(this.CellF13, 5, 13);
            this.tableLayoutPanel1.Controls.Add(this.CellG13, 6, 13);
            this.tableLayoutPanel1.Controls.Add(this.CellH13, 7, 13);
            this.tableLayoutPanel1.Controls.Add(this.CellI13, 8, 13);
            this.tableLayoutPanel1.Controls.Add(this.CellJ13, 9, 13);
            this.tableLayoutPanel1.Controls.Add(this.CellK13, 10, 13);
            this.tableLayoutPanel1.Controls.Add(this.CellL13, 11, 13);
            this.tableLayoutPanel1.Controls.Add(this.CellM13, 12, 13);
            this.tableLayoutPanel1.Controls.Add(this.CellA12, 0, 12);
            this.tableLayoutPanel1.Controls.Add(this.CellB12, 1, 12);
            this.tableLayoutPanel1.Controls.Add(this.CellC12, 2, 12);
            this.tableLayoutPanel1.Controls.Add(this.CellD12, 3, 12);
            this.tableLayoutPanel1.Controls.Add(this.CellE12, 4, 12);
            this.tableLayoutPanel1.Controls.Add(this.CellF12, 5, 12);
            this.tableLayoutPanel1.Controls.Add(this.CellG12, 6, 12);
            this.tableLayoutPanel1.Controls.Add(this.CellH12, 7, 12);
            this.tableLayoutPanel1.Controls.Add(this.CellI12, 8, 12);
            this.tableLayoutPanel1.Controls.Add(this.CellJ12, 9, 12);
            this.tableLayoutPanel1.Controls.Add(this.CellK12, 10, 12);
            this.tableLayoutPanel1.Controls.Add(this.CellL12, 11, 12);
            this.tableLayoutPanel1.Controls.Add(this.CellM12, 12, 12);
            this.tableLayoutPanel1.Controls.Add(this.CellA11, 0, 11);
            this.tableLayoutPanel1.Controls.Add(this.CellB11, 1, 11);
            this.tableLayoutPanel1.Controls.Add(this.CellC11, 2, 11);
            this.tableLayoutPanel1.Controls.Add(this.CellD11, 3, 11);
            this.tableLayoutPanel1.Controls.Add(this.CellE11, 4, 11);
            this.tableLayoutPanel1.Controls.Add(this.CellF11, 5, 11);
            this.tableLayoutPanel1.Controls.Add(this.CellG11, 6, 11);
            this.tableLayoutPanel1.Controls.Add(this.CellH11, 7, 11);
            this.tableLayoutPanel1.Controls.Add(this.CellI11, 8, 11);
            this.tableLayoutPanel1.Controls.Add(this.CellJ11, 9, 11);
            this.tableLayoutPanel1.Controls.Add(this.CellK11, 10, 11);
            this.tableLayoutPanel1.Controls.Add(this.CellL11, 11, 11);
            this.tableLayoutPanel1.Controls.Add(this.CellM11, 12, 11);
            this.tableLayoutPanel1.Controls.Add(this.CellA10, 0, 10);
            this.tableLayoutPanel1.Controls.Add(this.CellB10, 1, 10);
            this.tableLayoutPanel1.Controls.Add(this.CellC10, 2, 10);
            this.tableLayoutPanel1.Controls.Add(this.CellD10, 3, 10);
            this.tableLayoutPanel1.Controls.Add(this.CellE10, 4, 10);
            this.tableLayoutPanel1.Controls.Add(this.CellF10, 5, 10);
            this.tableLayoutPanel1.Controls.Add(this.CellG10, 6, 10);
            this.tableLayoutPanel1.Controls.Add(this.CellH10, 7, 10);
            this.tableLayoutPanel1.Controls.Add(this.CellI10, 8, 10);
            this.tableLayoutPanel1.Controls.Add(this.CellJ10, 9, 10);
            this.tableLayoutPanel1.Controls.Add(this.CellK10, 10, 10);
            this.tableLayoutPanel1.Controls.Add(this.CellL10, 11, 10);
            this.tableLayoutPanel1.Controls.Add(this.CellM10, 12, 10);
            this.tableLayoutPanel1.Controls.Add(this.CellA09, 0, 9);
            this.tableLayoutPanel1.Controls.Add(this.CellB09, 1, 9);
            this.tableLayoutPanel1.Controls.Add(this.CellC09, 2, 9);
            this.tableLayoutPanel1.Controls.Add(this.CellD09, 3, 9);
            this.tableLayoutPanel1.Controls.Add(this.CellE09, 4, 9);
            this.tableLayoutPanel1.Controls.Add(this.CellF09, 5, 9);
            this.tableLayoutPanel1.Controls.Add(this.CellG09, 6, 9);
            this.tableLayoutPanel1.Controls.Add(this.CellH09, 7, 9);
            this.tableLayoutPanel1.Controls.Add(this.CellI09, 8, 9);
            this.tableLayoutPanel1.Controls.Add(this.CellJ09, 9, 9);
            this.tableLayoutPanel1.Controls.Add(this.CellK09, 10, 9);
            this.tableLayoutPanel1.Controls.Add(this.CellL09, 11, 9);
            this.tableLayoutPanel1.Controls.Add(this.CellM09, 12, 9);
            this.tableLayoutPanel1.Controls.Add(this.CellA08, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.CellB08, 1, 8);
            this.tableLayoutPanel1.Controls.Add(this.CellC08, 2, 8);
            this.tableLayoutPanel1.Controls.Add(this.CellD08, 3, 8);
            this.tableLayoutPanel1.Controls.Add(this.CellE08, 4, 8);
            this.tableLayoutPanel1.Controls.Add(this.CellF08, 5, 8);
            this.tableLayoutPanel1.Controls.Add(this.CellG08, 6, 8);
            this.tableLayoutPanel1.Controls.Add(this.CellH08, 7, 8);
            this.tableLayoutPanel1.Controls.Add(this.CellI08, 8, 8);
            this.tableLayoutPanel1.Controls.Add(this.CellJ08, 9, 8);
            this.tableLayoutPanel1.Controls.Add(this.CellK08, 10, 8);
            this.tableLayoutPanel1.Controls.Add(this.CellL08, 11, 8);
            this.tableLayoutPanel1.Controls.Add(this.CellM08, 12, 8);
            this.tableLayoutPanel1.Controls.Add(this.CellA07, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.CellB07, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.CellC07, 2, 7);
            this.tableLayoutPanel1.Controls.Add(this.CellD07, 3, 7);
            this.tableLayoutPanel1.Controls.Add(this.CellE07, 4, 7);
            this.tableLayoutPanel1.Controls.Add(this.CellF07, 5, 7);
            this.tableLayoutPanel1.Controls.Add(this.CellG07, 6, 7);
            this.tableLayoutPanel1.Controls.Add(this.CellH07, 7, 7);
            this.tableLayoutPanel1.Controls.Add(this.CellI07, 8, 7);
            this.tableLayoutPanel1.Controls.Add(this.CellJ07, 9, 7);
            this.tableLayoutPanel1.Controls.Add(this.CellK07, 10, 7);
            this.tableLayoutPanel1.Controls.Add(this.CellL07, 11, 7);
            this.tableLayoutPanel1.Controls.Add(this.CellM07, 12, 7);
            this.tableLayoutPanel1.Controls.Add(this.CellA06, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.CellB06, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.CellC06, 2, 6);
            this.tableLayoutPanel1.Controls.Add(this.CellD06, 3, 6);
            this.tableLayoutPanel1.Controls.Add(this.CellE06, 4, 6);
            this.tableLayoutPanel1.Controls.Add(this.CellF06, 5, 6);
            this.tableLayoutPanel1.Controls.Add(this.CellG06, 6, 6);
            this.tableLayoutPanel1.Controls.Add(this.CellH06, 7, 6);
            this.tableLayoutPanel1.Controls.Add(this.CellI06, 8, 6);
            this.tableLayoutPanel1.Controls.Add(this.CellJ06, 9, 6);
            this.tableLayoutPanel1.Controls.Add(this.CellK06, 10, 6);
            this.tableLayoutPanel1.Controls.Add(this.CellL06, 11, 6);
            this.tableLayoutPanel1.Controls.Add(this.CellM06, 12, 6);
            this.tableLayoutPanel1.Controls.Add(this.CellA05, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.CellB05, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.CellC05, 2, 5);
            this.tableLayoutPanel1.Controls.Add(this.CellD05, 3, 5);
            this.tableLayoutPanel1.Controls.Add(this.CellE05, 4, 5);
            this.tableLayoutPanel1.Controls.Add(this.CellF05, 5, 5);
            this.tableLayoutPanel1.Controls.Add(this.CellG05, 6, 5);
            this.tableLayoutPanel1.Controls.Add(this.CellH05, 7, 5);
            this.tableLayoutPanel1.Controls.Add(this.CellI05, 8, 5);
            this.tableLayoutPanel1.Controls.Add(this.CellJ05, 9, 5);
            this.tableLayoutPanel1.Controls.Add(this.CellK05, 10, 5);
            this.tableLayoutPanel1.Controls.Add(this.CellL05, 11, 5);
            this.tableLayoutPanel1.Controls.Add(this.CellM05, 12, 5);
            this.tableLayoutPanel1.Controls.Add(this.CellA04, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.CellB04, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.CellC04, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.CellD04, 3, 4);
            this.tableLayoutPanel1.Controls.Add(this.CellE04, 4, 4);
            this.tableLayoutPanel1.Controls.Add(this.CellF04, 5, 4);
            this.tableLayoutPanel1.Controls.Add(this.CellG04, 6, 4);
            this.tableLayoutPanel1.Controls.Add(this.CellH04, 7, 4);
            this.tableLayoutPanel1.Controls.Add(this.CellI04, 8, 4);
            this.tableLayoutPanel1.Controls.Add(this.CellJ04, 9, 4);
            this.tableLayoutPanel1.Controls.Add(this.CellK04, 10, 4);
            this.tableLayoutPanel1.Controls.Add(this.CellL04, 11, 4);
            this.tableLayoutPanel1.Controls.Add(this.CellM04, 12, 4);
            this.tableLayoutPanel1.Controls.Add(this.CellA03, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.CellB03, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.CellC03, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.CellD03, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.CellE03, 4, 3);
            this.tableLayoutPanel1.Controls.Add(this.CellF03, 5, 3);
            this.tableLayoutPanel1.Controls.Add(this.CellG03, 6, 3);
            this.tableLayoutPanel1.Controls.Add(this.CellH03, 7, 3);
            this.tableLayoutPanel1.Controls.Add(this.CellI03, 8, 3);
            this.tableLayoutPanel1.Controls.Add(this.CellJ03, 9, 3);
            this.tableLayoutPanel1.Controls.Add(this.CellK03, 10, 3);
            this.tableLayoutPanel1.Controls.Add(this.CellL03, 11, 3);
            this.tableLayoutPanel1.Controls.Add(this.CellM03, 12, 3);
            this.tableLayoutPanel1.Controls.Add(this.CellA02, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.CellM02, 12, 2);
            this.tableLayoutPanel1.Controls.Add(this.CellL02, 11, 2);
            this.tableLayoutPanel1.Controls.Add(this.CellK02, 10, 2);
            this.tableLayoutPanel1.Controls.Add(this.CellJ02, 9, 2);
            this.tableLayoutPanel1.Controls.Add(this.CellI02, 8, 2);
            this.tableLayoutPanel1.Controls.Add(this.CellH02, 7, 2);
            this.tableLayoutPanel1.Controls.Add(this.CellG02, 6, 2);
            this.tableLayoutPanel1.Controls.Add(this.CellF02, 5, 2);
            this.tableLayoutPanel1.Controls.Add(this.CellE02, 4, 2);
            this.tableLayoutPanel1.Controls.Add(this.CellD02, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.CellC02, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.CellB02, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.CellA01, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.CellB01, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.CellC01, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.CellD01, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.CellE01, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.CellF01, 5, 1);
            this.tableLayoutPanel1.Controls.Add(this.CellG01, 6, 1);
            this.tableLayoutPanel1.Controls.Add(this.CellH01, 7, 1);
            this.tableLayoutPanel1.Controls.Add(this.CellI01, 8, 1);
            this.tableLayoutPanel1.Controls.Add(this.CellJ01, 9, 1);
            this.tableLayoutPanel1.Controls.Add(this.CellK01, 10, 1);
            this.tableLayoutPanel1.Controls.Add(this.CellL01, 11, 1);
            this.tableLayoutPanel1.Controls.Add(this.CellM01, 12, 1);
            this.tableLayoutPanel1.Controls.Add(this.CellA00, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.CellB00, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.CellC00, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.CellD00, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.CellE00, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.CellF00, 5, 0);
            this.tableLayoutPanel1.Controls.Add(this.CellG00, 6, 0);
            this.tableLayoutPanel1.Controls.Add(this.CellH00, 7, 0);
            this.tableLayoutPanel1.Controls.Add(this.CellI00, 8, 0);
            this.tableLayoutPanel1.Controls.Add(this.CellJ00, 9, 0);
            this.tableLayoutPanel1.Controls.Add(this.CellK00, 10, 0);
            this.tableLayoutPanel1.Controls.Add(this.CellL00, 11, 0);
            this.tableLayoutPanel1.Controls.Add(this.CellM00, 12, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(12, 2);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 21;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 33F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(505, 427);
            this.tableLayoutPanel1.TabIndex = 8;
            // 
            // CellA20
            // 
            this.CellA20.AutoSize = true;
            this.CellA20.Location = new System.Drawing.Point(3, 413);
            this.CellA20.Name = "CellA20";
            this.CellA20.Size = new System.Drawing.Size(34, 13);
            this.CellA20.TabIndex = 250;
            this.CellA20.Text = "0.000";
            // 
            // CellB20
            // 
            this.CellB20.AutoSize = true;
            this.CellB20.Location = new System.Drawing.Point(43, 413);
            this.CellB20.Name = "CellB20";
            this.CellB20.Size = new System.Drawing.Size(34, 13);
            this.CellB20.TabIndex = 251;
            this.CellB20.Text = "0.000";
            // 
            // CellC20
            // 
            this.CellC20.AutoSize = true;
            this.CellC20.Location = new System.Drawing.Point(83, 413);
            this.CellC20.Name = "CellC20";
            this.CellC20.Size = new System.Drawing.Size(34, 13);
            this.CellC20.TabIndex = 252;
            this.CellC20.Text = "0.000";
            // 
            // CellD20
            // 
            this.CellD20.AutoSize = true;
            this.CellD20.Location = new System.Drawing.Point(145, 413);
            this.CellD20.Name = "CellD20";
            this.CellD20.Size = new System.Drawing.Size(34, 13);
            this.CellD20.TabIndex = 253;
            this.CellD20.Text = "0.000";
            // 
            // CellE20
            // 
            this.CellE20.AutoSize = true;
            this.CellE20.Location = new System.Drawing.Point(185, 413);
            this.CellE20.Name = "CellE20";
            this.CellE20.Size = new System.Drawing.Size(34, 13);
            this.CellE20.TabIndex = 254;
            this.CellE20.Text = "0.000";
            // 
            // CellF20
            // 
            this.CellF20.AutoSize = true;
            this.CellF20.Location = new System.Drawing.Point(225, 413);
            this.CellF20.Name = "CellF20";
            this.CellF20.Size = new System.Drawing.Size(34, 13);
            this.CellF20.TabIndex = 255;
            this.CellF20.Text = "0.000";
            // 
            // CellG20
            // 
            this.CellG20.AutoSize = true;
            this.CellG20.Location = new System.Drawing.Point(265, 413);
            this.CellG20.Name = "CellG20";
            this.CellG20.Size = new System.Drawing.Size(34, 13);
            this.CellG20.TabIndex = 256;
            this.CellG20.Text = "0.000";
            // 
            // CellH20
            // 
            this.CellH20.AutoSize = true;
            this.CellH20.Location = new System.Drawing.Point(305, 413);
            this.CellH20.Name = "CellH20";
            this.CellH20.Size = new System.Drawing.Size(34, 13);
            this.CellH20.TabIndex = 257;
            this.CellH20.Text = "0.000";
            // 
            // CellI20
            // 
            this.CellI20.AutoSize = true;
            this.CellI20.Location = new System.Drawing.Point(345, 413);
            this.CellI20.Name = "CellI20";
            this.CellI20.Size = new System.Drawing.Size(34, 13);
            this.CellI20.TabIndex = 258;
            this.CellI20.Text = "0.000";
            // 
            // CellJ20
            // 
            this.CellJ20.AutoSize = true;
            this.CellJ20.Location = new System.Drawing.Point(385, 413);
            this.CellJ20.Name = "CellJ20";
            this.CellJ20.Size = new System.Drawing.Size(34, 13);
            this.CellJ20.TabIndex = 259;
            this.CellJ20.Text = "0.000";
            // 
            // CellK20
            // 
            this.CellK20.AutoSize = true;
            this.CellK20.Location = new System.Drawing.Point(425, 413);
            this.CellK20.Name = "CellK20";
            this.CellK20.Size = new System.Drawing.Size(34, 13);
            this.CellK20.TabIndex = 260;
            this.CellK20.Text = "0.000";
            // 
            // CellL20
            // 
            this.CellL20.AutoSize = true;
            this.CellL20.Location = new System.Drawing.Point(465, 413);
            this.CellL20.Name = "CellL20";
            this.CellL20.Size = new System.Drawing.Size(34, 13);
            this.CellL20.TabIndex = 261;
            this.CellL20.Text = "0.000";
            // 
            // CellM20
            // 
            this.CellM20.AutoSize = true;
            this.CellM20.Location = new System.Drawing.Point(514, 413);
            this.CellM20.Name = "CellM20";
            this.CellM20.Size = new System.Drawing.Size(34, 13);
            this.CellM20.TabIndex = 262;
            this.CellM20.Text = "0.000";
            // 
            // CellA19
            // 
            this.CellA19.AutoSize = true;
            this.CellA19.Location = new System.Drawing.Point(3, 393);
            this.CellA19.Name = "CellA19";
            this.CellA19.Size = new System.Drawing.Size(34, 13);
            this.CellA19.TabIndex = 237;
            this.CellA19.Text = "0.000";
            // 
            // CellB19
            // 
            this.CellB19.AutoSize = true;
            this.CellB19.Location = new System.Drawing.Point(43, 393);
            this.CellB19.Name = "CellB19";
            this.CellB19.Size = new System.Drawing.Size(34, 13);
            this.CellB19.TabIndex = 238;
            this.CellB19.Text = "0.000";
            // 
            // CellC19
            // 
            this.CellC19.AutoSize = true;
            this.CellC19.Location = new System.Drawing.Point(83, 393);
            this.CellC19.Name = "CellC19";
            this.CellC19.Size = new System.Drawing.Size(34, 13);
            this.CellC19.TabIndex = 239;
            this.CellC19.Text = "0.000";
            // 
            // CellD19
            // 
            this.CellD19.AutoSize = true;
            this.CellD19.Location = new System.Drawing.Point(145, 393);
            this.CellD19.Name = "CellD19";
            this.CellD19.Size = new System.Drawing.Size(34, 13);
            this.CellD19.TabIndex = 240;
            this.CellD19.Text = "0.000";
            // 
            // CellE19
            // 
            this.CellE19.AutoSize = true;
            this.CellE19.Location = new System.Drawing.Point(185, 393);
            this.CellE19.Name = "CellE19";
            this.CellE19.Size = new System.Drawing.Size(34, 13);
            this.CellE19.TabIndex = 241;
            this.CellE19.Text = "0.000";
            // 
            // CellF19
            // 
            this.CellF19.AutoSize = true;
            this.CellF19.Location = new System.Drawing.Point(225, 393);
            this.CellF19.Name = "CellF19";
            this.CellF19.Size = new System.Drawing.Size(34, 13);
            this.CellF19.TabIndex = 242;
            this.CellF19.Text = "0.000";
            // 
            // CellG19
            // 
            this.CellG19.AutoSize = true;
            this.CellG19.Location = new System.Drawing.Point(265, 393);
            this.CellG19.Name = "CellG19";
            this.CellG19.Size = new System.Drawing.Size(34, 13);
            this.CellG19.TabIndex = 243;
            this.CellG19.Text = "0.000";
            // 
            // CellH19
            // 
            this.CellH19.AutoSize = true;
            this.CellH19.Location = new System.Drawing.Point(305, 393);
            this.CellH19.Name = "CellH19";
            this.CellH19.Size = new System.Drawing.Size(34, 13);
            this.CellH19.TabIndex = 244;
            this.CellH19.Text = "0.000";
            // 
            // CellI19
            // 
            this.CellI19.AutoSize = true;
            this.CellI19.Location = new System.Drawing.Point(345, 393);
            this.CellI19.Name = "CellI19";
            this.CellI19.Size = new System.Drawing.Size(34, 13);
            this.CellI19.TabIndex = 245;
            this.CellI19.Text = "0.000";
            // 
            // CellJ19
            // 
            this.CellJ19.AutoSize = true;
            this.CellJ19.Location = new System.Drawing.Point(385, 393);
            this.CellJ19.Name = "CellJ19";
            this.CellJ19.Size = new System.Drawing.Size(34, 13);
            this.CellJ19.TabIndex = 246;
            this.CellJ19.Text = "0.000";
            // 
            // CellK19
            // 
            this.CellK19.AutoSize = true;
            this.CellK19.Location = new System.Drawing.Point(425, 393);
            this.CellK19.Name = "CellK19";
            this.CellK19.Size = new System.Drawing.Size(34, 13);
            this.CellK19.TabIndex = 247;
            this.CellK19.Text = "0.000";
            // 
            // CellL19
            // 
            this.CellL19.AutoSize = true;
            this.CellL19.Location = new System.Drawing.Point(465, 393);
            this.CellL19.Name = "CellL19";
            this.CellL19.Size = new System.Drawing.Size(34, 13);
            this.CellL19.TabIndex = 248;
            this.CellL19.Text = "0.000";
            // 
            // CellM19
            // 
            this.CellM19.AutoSize = true;
            this.CellM19.Location = new System.Drawing.Point(514, 393);
            this.CellM19.Name = "CellM19";
            this.CellM19.Size = new System.Drawing.Size(34, 13);
            this.CellM19.TabIndex = 249;
            this.CellM19.Text = "0.000";
            // 
            // CellA18
            // 
            this.CellA18.AutoSize = true;
            this.CellA18.Location = new System.Drawing.Point(3, 373);
            this.CellA18.Name = "CellA18";
            this.CellA18.Size = new System.Drawing.Size(34, 13);
            this.CellA18.TabIndex = 224;
            this.CellA18.Text = "0.000";
            // 
            // CellB18
            // 
            this.CellB18.AutoSize = true;
            this.CellB18.Location = new System.Drawing.Point(43, 373);
            this.CellB18.Name = "CellB18";
            this.CellB18.Size = new System.Drawing.Size(34, 13);
            this.CellB18.TabIndex = 225;
            this.CellB18.Text = "0.000";
            // 
            // CellC18
            // 
            this.CellC18.AutoSize = true;
            this.CellC18.Location = new System.Drawing.Point(83, 373);
            this.CellC18.Name = "CellC18";
            this.CellC18.Size = new System.Drawing.Size(34, 13);
            this.CellC18.TabIndex = 226;
            this.CellC18.Text = "0.000";
            // 
            // CellD18
            // 
            this.CellD18.AutoSize = true;
            this.CellD18.Location = new System.Drawing.Point(145, 373);
            this.CellD18.Name = "CellD18";
            this.CellD18.Size = new System.Drawing.Size(34, 13);
            this.CellD18.TabIndex = 227;
            this.CellD18.Text = "0.000";
            // 
            // CellE18
            // 
            this.CellE18.AutoSize = true;
            this.CellE18.Location = new System.Drawing.Point(185, 373);
            this.CellE18.Name = "CellE18";
            this.CellE18.Size = new System.Drawing.Size(34, 13);
            this.CellE18.TabIndex = 228;
            this.CellE18.Text = "0.000";
            // 
            // CellF18
            // 
            this.CellF18.AutoSize = true;
            this.CellF18.Location = new System.Drawing.Point(225, 373);
            this.CellF18.Name = "CellF18";
            this.CellF18.Size = new System.Drawing.Size(34, 13);
            this.CellF18.TabIndex = 229;
            this.CellF18.Text = "0.000";
            // 
            // CellG18
            // 
            this.CellG18.AutoSize = true;
            this.CellG18.Location = new System.Drawing.Point(265, 373);
            this.CellG18.Name = "CellG18";
            this.CellG18.Size = new System.Drawing.Size(34, 13);
            this.CellG18.TabIndex = 230;
            this.CellG18.Text = "0.000";
            // 
            // CellH18
            // 
            this.CellH18.AutoSize = true;
            this.CellH18.Location = new System.Drawing.Point(305, 373);
            this.CellH18.Name = "CellH18";
            this.CellH18.Size = new System.Drawing.Size(34, 13);
            this.CellH18.TabIndex = 231;
            this.CellH18.Text = "0.000";
            // 
            // CellI18
            // 
            this.CellI18.AutoSize = true;
            this.CellI18.Location = new System.Drawing.Point(345, 373);
            this.CellI18.Name = "CellI18";
            this.CellI18.Size = new System.Drawing.Size(34, 13);
            this.CellI18.TabIndex = 232;
            this.CellI18.Text = "0.000";
            // 
            // CellJ18
            // 
            this.CellJ18.AutoSize = true;
            this.CellJ18.Location = new System.Drawing.Point(385, 373);
            this.CellJ18.Name = "CellJ18";
            this.CellJ18.Size = new System.Drawing.Size(34, 13);
            this.CellJ18.TabIndex = 233;
            this.CellJ18.Text = "0.000";
            // 
            // CellK18
            // 
            this.CellK18.AutoSize = true;
            this.CellK18.Location = new System.Drawing.Point(425, 373);
            this.CellK18.Name = "CellK18";
            this.CellK18.Size = new System.Drawing.Size(34, 13);
            this.CellK18.TabIndex = 234;
            this.CellK18.Text = "0.000";
            // 
            // CellL18
            // 
            this.CellL18.AutoSize = true;
            this.CellL18.Location = new System.Drawing.Point(465, 373);
            this.CellL18.Name = "CellL18";
            this.CellL18.Size = new System.Drawing.Size(34, 13);
            this.CellL18.TabIndex = 235;
            this.CellL18.Text = "0.000";
            // 
            // CellM18
            // 
            this.CellM18.AutoSize = true;
            this.CellM18.Location = new System.Drawing.Point(514, 373);
            this.CellM18.Name = "CellM18";
            this.CellM18.Size = new System.Drawing.Size(34, 13);
            this.CellM18.TabIndex = 236;
            this.CellM18.Text = "0.000";
            // 
            // CellA17
            // 
            this.CellA17.AutoSize = true;
            this.CellA17.Location = new System.Drawing.Point(3, 353);
            this.CellA17.Name = "CellA17";
            this.CellA17.Size = new System.Drawing.Size(34, 13);
            this.CellA17.TabIndex = 211;
            this.CellA17.Text = "0.000";
            // 
            // CellB17
            // 
            this.CellB17.AutoSize = true;
            this.CellB17.Location = new System.Drawing.Point(43, 353);
            this.CellB17.Name = "CellB17";
            this.CellB17.Size = new System.Drawing.Size(34, 13);
            this.CellB17.TabIndex = 212;
            this.CellB17.Text = "0.000";
            // 
            // CellC17
            // 
            this.CellC17.AutoSize = true;
            this.CellC17.Location = new System.Drawing.Point(83, 353);
            this.CellC17.Name = "CellC17";
            this.CellC17.Size = new System.Drawing.Size(34, 13);
            this.CellC17.TabIndex = 213;
            this.CellC17.Text = "0.000";
            // 
            // CellD17
            // 
            this.CellD17.AutoSize = true;
            this.CellD17.Location = new System.Drawing.Point(145, 353);
            this.CellD17.Name = "CellD17";
            this.CellD17.Size = new System.Drawing.Size(34, 13);
            this.CellD17.TabIndex = 214;
            this.CellD17.Text = "0.000";
            // 
            // CellE17
            // 
            this.CellE17.AutoSize = true;
            this.CellE17.Location = new System.Drawing.Point(185, 353);
            this.CellE17.Name = "CellE17";
            this.CellE17.Size = new System.Drawing.Size(34, 13);
            this.CellE17.TabIndex = 215;
            this.CellE17.Text = "0.000";
            // 
            // CellF17
            // 
            this.CellF17.AutoSize = true;
            this.CellF17.Location = new System.Drawing.Point(225, 353);
            this.CellF17.Name = "CellF17";
            this.CellF17.Size = new System.Drawing.Size(34, 13);
            this.CellF17.TabIndex = 216;
            this.CellF17.Text = "0.000";
            // 
            // CellG17
            // 
            this.CellG17.AutoSize = true;
            this.CellG17.Location = new System.Drawing.Point(265, 353);
            this.CellG17.Name = "CellG17";
            this.CellG17.Size = new System.Drawing.Size(34, 13);
            this.CellG17.TabIndex = 217;
            this.CellG17.Text = "0.000";
            // 
            // CellH17
            // 
            this.CellH17.AutoSize = true;
            this.CellH17.Location = new System.Drawing.Point(305, 353);
            this.CellH17.Name = "CellH17";
            this.CellH17.Size = new System.Drawing.Size(34, 13);
            this.CellH17.TabIndex = 218;
            this.CellH17.Text = "0.000";
            // 
            // CellI17
            // 
            this.CellI17.AutoSize = true;
            this.CellI17.Location = new System.Drawing.Point(345, 353);
            this.CellI17.Name = "CellI17";
            this.CellI17.Size = new System.Drawing.Size(34, 13);
            this.CellI17.TabIndex = 219;
            this.CellI17.Text = "0.000";
            // 
            // CellJ17
            // 
            this.CellJ17.AutoSize = true;
            this.CellJ17.Location = new System.Drawing.Point(385, 353);
            this.CellJ17.Name = "CellJ17";
            this.CellJ17.Size = new System.Drawing.Size(34, 13);
            this.CellJ17.TabIndex = 220;
            this.CellJ17.Text = "0.000";
            // 
            // CellK17
            // 
            this.CellK17.AutoSize = true;
            this.CellK17.Location = new System.Drawing.Point(425, 353);
            this.CellK17.Name = "CellK17";
            this.CellK17.Size = new System.Drawing.Size(34, 13);
            this.CellK17.TabIndex = 221;
            this.CellK17.Text = "0.000";
            // 
            // CellL17
            // 
            this.CellL17.AutoSize = true;
            this.CellL17.Location = new System.Drawing.Point(465, 353);
            this.CellL17.Name = "CellL17";
            this.CellL17.Size = new System.Drawing.Size(34, 13);
            this.CellL17.TabIndex = 222;
            this.CellL17.Text = "0.000";
            // 
            // CellM17
            // 
            this.CellM17.AutoSize = true;
            this.CellM17.Location = new System.Drawing.Point(514, 353);
            this.CellM17.Name = "CellM17";
            this.CellM17.Size = new System.Drawing.Size(34, 13);
            this.CellM17.TabIndex = 223;
            this.CellM17.Text = "0.000";
            // 
            // CellA16
            // 
            this.CellA16.AutoSize = true;
            this.CellA16.Location = new System.Drawing.Point(3, 333);
            this.CellA16.Name = "CellA16";
            this.CellA16.Size = new System.Drawing.Size(34, 13);
            this.CellA16.TabIndex = 198;
            this.CellA16.Text = "0.000";
            // 
            // CellB16
            // 
            this.CellB16.AutoSize = true;
            this.CellB16.Location = new System.Drawing.Point(43, 333);
            this.CellB16.Name = "CellB16";
            this.CellB16.Size = new System.Drawing.Size(34, 13);
            this.CellB16.TabIndex = 199;
            this.CellB16.Text = "0.000";
            // 
            // CellC16
            // 
            this.CellC16.AutoSize = true;
            this.CellC16.Location = new System.Drawing.Point(83, 333);
            this.CellC16.Name = "CellC16";
            this.CellC16.Size = new System.Drawing.Size(34, 13);
            this.CellC16.TabIndex = 200;
            this.CellC16.Text = "0.000";
            // 
            // CellD16
            // 
            this.CellD16.AutoSize = true;
            this.CellD16.Location = new System.Drawing.Point(145, 333);
            this.CellD16.Name = "CellD16";
            this.CellD16.Size = new System.Drawing.Size(34, 13);
            this.CellD16.TabIndex = 201;
            this.CellD16.Text = "0.000";
            // 
            // CellE16
            // 
            this.CellE16.AutoSize = true;
            this.CellE16.Location = new System.Drawing.Point(185, 333);
            this.CellE16.Name = "CellE16";
            this.CellE16.Size = new System.Drawing.Size(34, 13);
            this.CellE16.TabIndex = 202;
            this.CellE16.Text = "0.000";
            // 
            // CellF16
            // 
            this.CellF16.AutoSize = true;
            this.CellF16.Location = new System.Drawing.Point(225, 333);
            this.CellF16.Name = "CellF16";
            this.CellF16.Size = new System.Drawing.Size(34, 13);
            this.CellF16.TabIndex = 203;
            this.CellF16.Text = "0.000";
            // 
            // CellG16
            // 
            this.CellG16.AutoSize = true;
            this.CellG16.Location = new System.Drawing.Point(265, 333);
            this.CellG16.Name = "CellG16";
            this.CellG16.Size = new System.Drawing.Size(34, 13);
            this.CellG16.TabIndex = 204;
            this.CellG16.Text = "0.000";
            // 
            // CellH16
            // 
            this.CellH16.AutoSize = true;
            this.CellH16.Location = new System.Drawing.Point(305, 333);
            this.CellH16.Name = "CellH16";
            this.CellH16.Size = new System.Drawing.Size(34, 13);
            this.CellH16.TabIndex = 205;
            this.CellH16.Text = "0.000";
            // 
            // CellI16
            // 
            this.CellI16.AutoSize = true;
            this.CellI16.Location = new System.Drawing.Point(345, 333);
            this.CellI16.Name = "CellI16";
            this.CellI16.Size = new System.Drawing.Size(34, 13);
            this.CellI16.TabIndex = 206;
            this.CellI16.Text = "0.000";
            // 
            // CellJ16
            // 
            this.CellJ16.AutoSize = true;
            this.CellJ16.Location = new System.Drawing.Point(385, 333);
            this.CellJ16.Name = "CellJ16";
            this.CellJ16.Size = new System.Drawing.Size(34, 13);
            this.CellJ16.TabIndex = 207;
            this.CellJ16.Text = "0.000";
            // 
            // CellK16
            // 
            this.CellK16.AutoSize = true;
            this.CellK16.Location = new System.Drawing.Point(425, 333);
            this.CellK16.Name = "CellK16";
            this.CellK16.Size = new System.Drawing.Size(34, 13);
            this.CellK16.TabIndex = 208;
            this.CellK16.Text = "0.000";
            // 
            // CellL16
            // 
            this.CellL16.AutoSize = true;
            this.CellL16.Location = new System.Drawing.Point(465, 333);
            this.CellL16.Name = "CellL16";
            this.CellL16.Size = new System.Drawing.Size(34, 13);
            this.CellL16.TabIndex = 209;
            this.CellL16.Text = "0.000";
            // 
            // CellM16
            // 
            this.CellM16.AutoSize = true;
            this.CellM16.Location = new System.Drawing.Point(514, 333);
            this.CellM16.Name = "CellM16";
            this.CellM16.Size = new System.Drawing.Size(34, 13);
            this.CellM16.TabIndex = 210;
            this.CellM16.Text = "0.000";
            // 
            // CellA15
            // 
            this.CellA15.AutoSize = true;
            this.CellA15.Location = new System.Drawing.Point(3, 313);
            this.CellA15.Name = "CellA15";
            this.CellA15.Size = new System.Drawing.Size(34, 13);
            this.CellA15.TabIndex = 185;
            this.CellA15.Text = "0.000";
            // 
            // CellB15
            // 
            this.CellB15.AutoSize = true;
            this.CellB15.Location = new System.Drawing.Point(43, 313);
            this.CellB15.Name = "CellB15";
            this.CellB15.Size = new System.Drawing.Size(34, 13);
            this.CellB15.TabIndex = 186;
            this.CellB15.Text = "0.000";
            // 
            // CellC15
            // 
            this.CellC15.AutoSize = true;
            this.CellC15.Location = new System.Drawing.Point(83, 313);
            this.CellC15.Name = "CellC15";
            this.CellC15.Size = new System.Drawing.Size(34, 13);
            this.CellC15.TabIndex = 187;
            this.CellC15.Text = "0.000";
            // 
            // CellD15
            // 
            this.CellD15.AutoSize = true;
            this.CellD15.Location = new System.Drawing.Point(145, 313);
            this.CellD15.Name = "CellD15";
            this.CellD15.Size = new System.Drawing.Size(34, 13);
            this.CellD15.TabIndex = 188;
            this.CellD15.Text = "0.000";
            // 
            // CellE15
            // 
            this.CellE15.AutoSize = true;
            this.CellE15.Location = new System.Drawing.Point(185, 313);
            this.CellE15.Name = "CellE15";
            this.CellE15.Size = new System.Drawing.Size(34, 13);
            this.CellE15.TabIndex = 189;
            this.CellE15.Text = "0.000";
            // 
            // CellF15
            // 
            this.CellF15.AutoSize = true;
            this.CellF15.Location = new System.Drawing.Point(225, 313);
            this.CellF15.Name = "CellF15";
            this.CellF15.Size = new System.Drawing.Size(34, 13);
            this.CellF15.TabIndex = 190;
            this.CellF15.Text = "0.000";
            // 
            // CellG15
            // 
            this.CellG15.AutoSize = true;
            this.CellG15.Location = new System.Drawing.Point(265, 313);
            this.CellG15.Name = "CellG15";
            this.CellG15.Size = new System.Drawing.Size(34, 13);
            this.CellG15.TabIndex = 191;
            this.CellG15.Text = "0.000";
            // 
            // CellH15
            // 
            this.CellH15.AutoSize = true;
            this.CellH15.Location = new System.Drawing.Point(305, 313);
            this.CellH15.Name = "CellH15";
            this.CellH15.Size = new System.Drawing.Size(34, 13);
            this.CellH15.TabIndex = 192;
            this.CellH15.Text = "0.000";
            // 
            // CellI15
            // 
            this.CellI15.AutoSize = true;
            this.CellI15.Location = new System.Drawing.Point(345, 313);
            this.CellI15.Name = "CellI15";
            this.CellI15.Size = new System.Drawing.Size(34, 13);
            this.CellI15.TabIndex = 193;
            this.CellI15.Text = "0.000";
            // 
            // CellJ15
            // 
            this.CellJ15.AutoSize = true;
            this.CellJ15.Location = new System.Drawing.Point(385, 313);
            this.CellJ15.Name = "CellJ15";
            this.CellJ15.Size = new System.Drawing.Size(34, 13);
            this.CellJ15.TabIndex = 194;
            this.CellJ15.Text = "0.000";
            // 
            // CellK15
            // 
            this.CellK15.AutoSize = true;
            this.CellK15.Location = new System.Drawing.Point(425, 313);
            this.CellK15.Name = "CellK15";
            this.CellK15.Size = new System.Drawing.Size(34, 13);
            this.CellK15.TabIndex = 195;
            this.CellK15.Text = "0.000";
            // 
            // CellL15
            // 
            this.CellL15.AutoSize = true;
            this.CellL15.Location = new System.Drawing.Point(465, 313);
            this.CellL15.Name = "CellL15";
            this.CellL15.Size = new System.Drawing.Size(34, 13);
            this.CellL15.TabIndex = 196;
            this.CellL15.Text = "0.000";
            // 
            // CellM15
            // 
            this.CellM15.AutoSize = true;
            this.CellM15.Location = new System.Drawing.Point(514, 313);
            this.CellM15.Name = "CellM15";
            this.CellM15.Size = new System.Drawing.Size(34, 13);
            this.CellM15.TabIndex = 197;
            this.CellM15.Text = "0.000";
            // 
            // CellA14
            // 
            this.CellA14.AutoSize = true;
            this.CellA14.Location = new System.Drawing.Point(3, 293);
            this.CellA14.Name = "CellA14";
            this.CellA14.Size = new System.Drawing.Size(34, 13);
            this.CellA14.TabIndex = 172;
            this.CellA14.Text = "0.000";
            // 
            // CellB14
            // 
            this.CellB14.AutoSize = true;
            this.CellB14.Location = new System.Drawing.Point(43, 293);
            this.CellB14.Name = "CellB14";
            this.CellB14.Size = new System.Drawing.Size(34, 13);
            this.CellB14.TabIndex = 173;
            this.CellB14.Text = "0.000";
            // 
            // CellC14
            // 
            this.CellC14.AutoSize = true;
            this.CellC14.Location = new System.Drawing.Point(83, 293);
            this.CellC14.Name = "CellC14";
            this.CellC14.Size = new System.Drawing.Size(34, 13);
            this.CellC14.TabIndex = 174;
            this.CellC14.Text = "0.000";
            // 
            // CellD14
            // 
            this.CellD14.AutoSize = true;
            this.CellD14.Location = new System.Drawing.Point(145, 293);
            this.CellD14.Name = "CellD14";
            this.CellD14.Size = new System.Drawing.Size(34, 13);
            this.CellD14.TabIndex = 175;
            this.CellD14.Text = "0.000";
            // 
            // CellE14
            // 
            this.CellE14.AutoSize = true;
            this.CellE14.Location = new System.Drawing.Point(185, 293);
            this.CellE14.Name = "CellE14";
            this.CellE14.Size = new System.Drawing.Size(34, 13);
            this.CellE14.TabIndex = 176;
            this.CellE14.Text = "0.000";
            // 
            // CellF14
            // 
            this.CellF14.AutoSize = true;
            this.CellF14.Location = new System.Drawing.Point(225, 293);
            this.CellF14.Name = "CellF14";
            this.CellF14.Size = new System.Drawing.Size(34, 13);
            this.CellF14.TabIndex = 177;
            this.CellF14.Text = "0.000";
            // 
            // CellG14
            // 
            this.CellG14.AutoSize = true;
            this.CellG14.Location = new System.Drawing.Point(265, 293);
            this.CellG14.Name = "CellG14";
            this.CellG14.Size = new System.Drawing.Size(34, 13);
            this.CellG14.TabIndex = 178;
            this.CellG14.Text = "0.000";
            // 
            // CellH14
            // 
            this.CellH14.AutoSize = true;
            this.CellH14.Location = new System.Drawing.Point(305, 293);
            this.CellH14.Name = "CellH14";
            this.CellH14.Size = new System.Drawing.Size(34, 13);
            this.CellH14.TabIndex = 179;
            this.CellH14.Text = "0.000";
            // 
            // CellI14
            // 
            this.CellI14.AutoSize = true;
            this.CellI14.Location = new System.Drawing.Point(345, 293);
            this.CellI14.Name = "CellI14";
            this.CellI14.Size = new System.Drawing.Size(34, 13);
            this.CellI14.TabIndex = 180;
            this.CellI14.Text = "0.000";
            // 
            // CellJ14
            // 
            this.CellJ14.AutoSize = true;
            this.CellJ14.Location = new System.Drawing.Point(385, 293);
            this.CellJ14.Name = "CellJ14";
            this.CellJ14.Size = new System.Drawing.Size(34, 13);
            this.CellJ14.TabIndex = 181;
            this.CellJ14.Text = "0.000";
            // 
            // CellK14
            // 
            this.CellK14.AutoSize = true;
            this.CellK14.Location = new System.Drawing.Point(425, 293);
            this.CellK14.Name = "CellK14";
            this.CellK14.Size = new System.Drawing.Size(34, 13);
            this.CellK14.TabIndex = 182;
            this.CellK14.Text = "0.000";
            // 
            // CellL14
            // 
            this.CellL14.AutoSize = true;
            this.CellL14.Location = new System.Drawing.Point(465, 293);
            this.CellL14.Name = "CellL14";
            this.CellL14.Size = new System.Drawing.Size(34, 13);
            this.CellL14.TabIndex = 183;
            this.CellL14.Text = "0.000";
            // 
            // CellM14
            // 
            this.CellM14.AutoSize = true;
            this.CellM14.Location = new System.Drawing.Point(514, 293);
            this.CellM14.Name = "CellM14";
            this.CellM14.Size = new System.Drawing.Size(34, 13);
            this.CellM14.TabIndex = 184;
            this.CellM14.Text = "0.000";
            // 
            // CellA13
            // 
            this.CellA13.AutoSize = true;
            this.CellA13.Location = new System.Drawing.Point(3, 273);
            this.CellA13.Name = "CellA13";
            this.CellA13.Size = new System.Drawing.Size(34, 13);
            this.CellA13.TabIndex = 159;
            this.CellA13.Text = "0.000";
            // 
            // CellB13
            // 
            this.CellB13.AutoSize = true;
            this.CellB13.Location = new System.Drawing.Point(43, 273);
            this.CellB13.Name = "CellB13";
            this.CellB13.Size = new System.Drawing.Size(34, 13);
            this.CellB13.TabIndex = 160;
            this.CellB13.Text = "0.000";
            // 
            // CellC13
            // 
            this.CellC13.AutoSize = true;
            this.CellC13.Location = new System.Drawing.Point(83, 273);
            this.CellC13.Name = "CellC13";
            this.CellC13.Size = new System.Drawing.Size(34, 13);
            this.CellC13.TabIndex = 161;
            this.CellC13.Text = "0.000";
            // 
            // CellD13
            // 
            this.CellD13.AutoSize = true;
            this.CellD13.Location = new System.Drawing.Point(145, 273);
            this.CellD13.Name = "CellD13";
            this.CellD13.Size = new System.Drawing.Size(34, 13);
            this.CellD13.TabIndex = 162;
            this.CellD13.Text = "0.000";
            // 
            // CellE13
            // 
            this.CellE13.AutoSize = true;
            this.CellE13.Location = new System.Drawing.Point(185, 273);
            this.CellE13.Name = "CellE13";
            this.CellE13.Size = new System.Drawing.Size(34, 13);
            this.CellE13.TabIndex = 163;
            this.CellE13.Text = "0.000";
            // 
            // CellF13
            // 
            this.CellF13.AutoSize = true;
            this.CellF13.Location = new System.Drawing.Point(225, 273);
            this.CellF13.Name = "CellF13";
            this.CellF13.Size = new System.Drawing.Size(34, 13);
            this.CellF13.TabIndex = 164;
            this.CellF13.Text = "0.000";
            // 
            // CellG13
            // 
            this.CellG13.AutoSize = true;
            this.CellG13.Location = new System.Drawing.Point(265, 273);
            this.CellG13.Name = "CellG13";
            this.CellG13.Size = new System.Drawing.Size(34, 13);
            this.CellG13.TabIndex = 165;
            this.CellG13.Text = "0.000";
            // 
            // CellH13
            // 
            this.CellH13.AutoSize = true;
            this.CellH13.Location = new System.Drawing.Point(305, 273);
            this.CellH13.Name = "CellH13";
            this.CellH13.Size = new System.Drawing.Size(34, 13);
            this.CellH13.TabIndex = 166;
            this.CellH13.Text = "0.000";
            // 
            // CellI13
            // 
            this.CellI13.AutoSize = true;
            this.CellI13.Location = new System.Drawing.Point(345, 273);
            this.CellI13.Name = "CellI13";
            this.CellI13.Size = new System.Drawing.Size(34, 13);
            this.CellI13.TabIndex = 167;
            this.CellI13.Text = "0.000";
            // 
            // CellJ13
            // 
            this.CellJ13.AutoSize = true;
            this.CellJ13.Location = new System.Drawing.Point(385, 273);
            this.CellJ13.Name = "CellJ13";
            this.CellJ13.Size = new System.Drawing.Size(34, 13);
            this.CellJ13.TabIndex = 168;
            this.CellJ13.Text = "0.000";
            // 
            // CellK13
            // 
            this.CellK13.AutoSize = true;
            this.CellK13.Location = new System.Drawing.Point(425, 273);
            this.CellK13.Name = "CellK13";
            this.CellK13.Size = new System.Drawing.Size(34, 13);
            this.CellK13.TabIndex = 169;
            this.CellK13.Text = "0.000";
            // 
            // CellL13
            // 
            this.CellL13.AutoSize = true;
            this.CellL13.Location = new System.Drawing.Point(465, 273);
            this.CellL13.Name = "CellL13";
            this.CellL13.Size = new System.Drawing.Size(34, 13);
            this.CellL13.TabIndex = 170;
            this.CellL13.Text = "0.000";
            // 
            // CellM13
            // 
            this.CellM13.AutoSize = true;
            this.CellM13.Location = new System.Drawing.Point(514, 273);
            this.CellM13.Name = "CellM13";
            this.CellM13.Size = new System.Drawing.Size(34, 13);
            this.CellM13.TabIndex = 171;
            this.CellM13.Text = "0.000";
            // 
            // CellA12
            // 
            this.CellA12.AutoSize = true;
            this.CellA12.Location = new System.Drawing.Point(3, 253);
            this.CellA12.Name = "CellA12";
            this.CellA12.Size = new System.Drawing.Size(34, 13);
            this.CellA12.TabIndex = 146;
            this.CellA12.Text = "0.000";
            // 
            // CellB12
            // 
            this.CellB12.AutoSize = true;
            this.CellB12.Location = new System.Drawing.Point(43, 253);
            this.CellB12.Name = "CellB12";
            this.CellB12.Size = new System.Drawing.Size(34, 13);
            this.CellB12.TabIndex = 147;
            this.CellB12.Text = "0.000";
            // 
            // CellC12
            // 
            this.CellC12.AutoSize = true;
            this.CellC12.Location = new System.Drawing.Point(83, 253);
            this.CellC12.Name = "CellC12";
            this.CellC12.Size = new System.Drawing.Size(34, 13);
            this.CellC12.TabIndex = 148;
            this.CellC12.Text = "0.000";
            // 
            // CellD12
            // 
            this.CellD12.AutoSize = true;
            this.CellD12.Location = new System.Drawing.Point(145, 253);
            this.CellD12.Name = "CellD12";
            this.CellD12.Size = new System.Drawing.Size(34, 13);
            this.CellD12.TabIndex = 149;
            this.CellD12.Text = "0.000";
            // 
            // CellE12
            // 
            this.CellE12.AutoSize = true;
            this.CellE12.Location = new System.Drawing.Point(185, 253);
            this.CellE12.Name = "CellE12";
            this.CellE12.Size = new System.Drawing.Size(34, 13);
            this.CellE12.TabIndex = 150;
            this.CellE12.Text = "0.000";
            // 
            // CellF12
            // 
            this.CellF12.AutoSize = true;
            this.CellF12.Location = new System.Drawing.Point(225, 253);
            this.CellF12.Name = "CellF12";
            this.CellF12.Size = new System.Drawing.Size(34, 13);
            this.CellF12.TabIndex = 151;
            this.CellF12.Text = "0.000";
            // 
            // CellG12
            // 
            this.CellG12.AutoSize = true;
            this.CellG12.Location = new System.Drawing.Point(265, 253);
            this.CellG12.Name = "CellG12";
            this.CellG12.Size = new System.Drawing.Size(34, 13);
            this.CellG12.TabIndex = 152;
            this.CellG12.Text = "0.000";
            // 
            // CellH12
            // 
            this.CellH12.AutoSize = true;
            this.CellH12.Location = new System.Drawing.Point(305, 253);
            this.CellH12.Name = "CellH12";
            this.CellH12.Size = new System.Drawing.Size(34, 13);
            this.CellH12.TabIndex = 153;
            this.CellH12.Text = "0.000";
            // 
            // CellI12
            // 
            this.CellI12.AutoSize = true;
            this.CellI12.Location = new System.Drawing.Point(345, 253);
            this.CellI12.Name = "CellI12";
            this.CellI12.Size = new System.Drawing.Size(34, 13);
            this.CellI12.TabIndex = 154;
            this.CellI12.Text = "0.000";
            // 
            // CellJ12
            // 
            this.CellJ12.AutoSize = true;
            this.CellJ12.Location = new System.Drawing.Point(385, 253);
            this.CellJ12.Name = "CellJ12";
            this.CellJ12.Size = new System.Drawing.Size(34, 13);
            this.CellJ12.TabIndex = 155;
            this.CellJ12.Text = "0.000";
            // 
            // CellK12
            // 
            this.CellK12.AutoSize = true;
            this.CellK12.Location = new System.Drawing.Point(425, 253);
            this.CellK12.Name = "CellK12";
            this.CellK12.Size = new System.Drawing.Size(34, 13);
            this.CellK12.TabIndex = 156;
            this.CellK12.Text = "0.000";
            // 
            // CellL12
            // 
            this.CellL12.AutoSize = true;
            this.CellL12.Location = new System.Drawing.Point(465, 253);
            this.CellL12.Name = "CellL12";
            this.CellL12.Size = new System.Drawing.Size(34, 13);
            this.CellL12.TabIndex = 157;
            this.CellL12.Text = "0.000";
            // 
            // CellM12
            // 
            this.CellM12.AutoSize = true;
            this.CellM12.Location = new System.Drawing.Point(514, 253);
            this.CellM12.Name = "CellM12";
            this.CellM12.Size = new System.Drawing.Size(34, 13);
            this.CellM12.TabIndex = 158;
            this.CellM12.Text = "0.000";
            // 
            // CellA11
            // 
            this.CellA11.AutoSize = true;
            this.CellA11.Location = new System.Drawing.Point(3, 233);
            this.CellA11.Name = "CellA11";
            this.CellA11.Size = new System.Drawing.Size(34, 13);
            this.CellA11.TabIndex = 133;
            this.CellA11.Text = "0.000";
            // 
            // CellB11
            // 
            this.CellB11.AutoSize = true;
            this.CellB11.Location = new System.Drawing.Point(43, 233);
            this.CellB11.Name = "CellB11";
            this.CellB11.Size = new System.Drawing.Size(34, 13);
            this.CellB11.TabIndex = 134;
            this.CellB11.Text = "0.000";
            // 
            // CellC11
            // 
            this.CellC11.AutoSize = true;
            this.CellC11.Location = new System.Drawing.Point(83, 233);
            this.CellC11.Name = "CellC11";
            this.CellC11.Size = new System.Drawing.Size(34, 13);
            this.CellC11.TabIndex = 135;
            this.CellC11.Text = "0.000";
            // 
            // CellD11
            // 
            this.CellD11.AutoSize = true;
            this.CellD11.Location = new System.Drawing.Point(145, 233);
            this.CellD11.Name = "CellD11";
            this.CellD11.Size = new System.Drawing.Size(34, 13);
            this.CellD11.TabIndex = 136;
            this.CellD11.Text = "0.000";
            // 
            // CellE11
            // 
            this.CellE11.AutoSize = true;
            this.CellE11.Location = new System.Drawing.Point(185, 233);
            this.CellE11.Name = "CellE11";
            this.CellE11.Size = new System.Drawing.Size(34, 13);
            this.CellE11.TabIndex = 137;
            this.CellE11.Text = "0.000";
            // 
            // CellF11
            // 
            this.CellF11.AutoSize = true;
            this.CellF11.Location = new System.Drawing.Point(225, 233);
            this.CellF11.Name = "CellF11";
            this.CellF11.Size = new System.Drawing.Size(34, 13);
            this.CellF11.TabIndex = 138;
            this.CellF11.Text = "0.000";
            // 
            // CellG11
            // 
            this.CellG11.AutoSize = true;
            this.CellG11.Location = new System.Drawing.Point(265, 233);
            this.CellG11.Name = "CellG11";
            this.CellG11.Size = new System.Drawing.Size(34, 13);
            this.CellG11.TabIndex = 139;
            this.CellG11.Text = "0.000";
            // 
            // CellH11
            // 
            this.CellH11.AutoSize = true;
            this.CellH11.Location = new System.Drawing.Point(305, 233);
            this.CellH11.Name = "CellH11";
            this.CellH11.Size = new System.Drawing.Size(34, 13);
            this.CellH11.TabIndex = 140;
            this.CellH11.Text = "0.000";
            // 
            // CellI11
            // 
            this.CellI11.AutoSize = true;
            this.CellI11.Location = new System.Drawing.Point(345, 233);
            this.CellI11.Name = "CellI11";
            this.CellI11.Size = new System.Drawing.Size(34, 13);
            this.CellI11.TabIndex = 141;
            this.CellI11.Text = "0.000";
            // 
            // CellJ11
            // 
            this.CellJ11.AutoSize = true;
            this.CellJ11.Location = new System.Drawing.Point(385, 233);
            this.CellJ11.Name = "CellJ11";
            this.CellJ11.Size = new System.Drawing.Size(34, 13);
            this.CellJ11.TabIndex = 142;
            this.CellJ11.Text = "0.000";
            // 
            // CellK11
            // 
            this.CellK11.AutoSize = true;
            this.CellK11.Location = new System.Drawing.Point(425, 233);
            this.CellK11.Name = "CellK11";
            this.CellK11.Size = new System.Drawing.Size(34, 13);
            this.CellK11.TabIndex = 143;
            this.CellK11.Text = "0.000";
            // 
            // CellL11
            // 
            this.CellL11.AutoSize = true;
            this.CellL11.Location = new System.Drawing.Point(465, 233);
            this.CellL11.Name = "CellL11";
            this.CellL11.Size = new System.Drawing.Size(34, 13);
            this.CellL11.TabIndex = 144;
            this.CellL11.Text = "0.000";
            // 
            // CellM11
            // 
            this.CellM11.AutoSize = true;
            this.CellM11.Location = new System.Drawing.Point(514, 233);
            this.CellM11.Name = "CellM11";
            this.CellM11.Size = new System.Drawing.Size(34, 13);
            this.CellM11.TabIndex = 145;
            this.CellM11.Text = "0.000";
            // 
            // CellA10
            // 
            this.CellA10.AutoSize = true;
            this.CellA10.Location = new System.Drawing.Point(3, 213);
            this.CellA10.Name = "CellA10";
            this.CellA10.Size = new System.Drawing.Size(34, 13);
            this.CellA10.TabIndex = 120;
            this.CellA10.Text = "0.000";
            // 
            // CellB10
            // 
            this.CellB10.AutoSize = true;
            this.CellB10.Location = new System.Drawing.Point(43, 213);
            this.CellB10.Name = "CellB10";
            this.CellB10.Size = new System.Drawing.Size(34, 13);
            this.CellB10.TabIndex = 121;
            this.CellB10.Text = "0.000";
            // 
            // CellC10
            // 
            this.CellC10.AutoSize = true;
            this.CellC10.Location = new System.Drawing.Point(83, 213);
            this.CellC10.Name = "CellC10";
            this.CellC10.Size = new System.Drawing.Size(34, 13);
            this.CellC10.TabIndex = 122;
            this.CellC10.Text = "0.000";
            // 
            // CellD10
            // 
            this.CellD10.AutoSize = true;
            this.CellD10.Location = new System.Drawing.Point(145, 213);
            this.CellD10.Name = "CellD10";
            this.CellD10.Size = new System.Drawing.Size(34, 13);
            this.CellD10.TabIndex = 123;
            this.CellD10.Text = "0.000";
            // 
            // CellE10
            // 
            this.CellE10.AutoSize = true;
            this.CellE10.Location = new System.Drawing.Point(185, 213);
            this.CellE10.Name = "CellE10";
            this.CellE10.Size = new System.Drawing.Size(34, 13);
            this.CellE10.TabIndex = 124;
            this.CellE10.Text = "0.000";
            // 
            // CellF10
            // 
            this.CellF10.AutoSize = true;
            this.CellF10.Location = new System.Drawing.Point(225, 213);
            this.CellF10.Name = "CellF10";
            this.CellF10.Size = new System.Drawing.Size(34, 13);
            this.CellF10.TabIndex = 125;
            this.CellF10.Text = "0.000";
            // 
            // CellG10
            // 
            this.CellG10.AutoSize = true;
            this.CellG10.Location = new System.Drawing.Point(265, 213);
            this.CellG10.Name = "CellG10";
            this.CellG10.Size = new System.Drawing.Size(34, 13);
            this.CellG10.TabIndex = 126;
            this.CellG10.Text = "0.000";
            // 
            // CellH10
            // 
            this.CellH10.AutoSize = true;
            this.CellH10.Location = new System.Drawing.Point(305, 213);
            this.CellH10.Name = "CellH10";
            this.CellH10.Size = new System.Drawing.Size(34, 13);
            this.CellH10.TabIndex = 127;
            this.CellH10.Text = "0.000";
            // 
            // CellI10
            // 
            this.CellI10.AutoSize = true;
            this.CellI10.Location = new System.Drawing.Point(345, 213);
            this.CellI10.Name = "CellI10";
            this.CellI10.Size = new System.Drawing.Size(34, 13);
            this.CellI10.TabIndex = 128;
            this.CellI10.Text = "0.000";
            // 
            // CellJ10
            // 
            this.CellJ10.AutoSize = true;
            this.CellJ10.Location = new System.Drawing.Point(385, 213);
            this.CellJ10.Name = "CellJ10";
            this.CellJ10.Size = new System.Drawing.Size(34, 13);
            this.CellJ10.TabIndex = 129;
            this.CellJ10.Text = "0.000";
            // 
            // CellK10
            // 
            this.CellK10.AutoSize = true;
            this.CellK10.Location = new System.Drawing.Point(425, 213);
            this.CellK10.Name = "CellK10";
            this.CellK10.Size = new System.Drawing.Size(34, 13);
            this.CellK10.TabIndex = 130;
            this.CellK10.Text = "0.000";
            // 
            // CellL10
            // 
            this.CellL10.AutoSize = true;
            this.CellL10.Location = new System.Drawing.Point(465, 213);
            this.CellL10.Name = "CellL10";
            this.CellL10.Size = new System.Drawing.Size(34, 13);
            this.CellL10.TabIndex = 131;
            this.CellL10.Text = "0.000";
            // 
            // CellM10
            // 
            this.CellM10.AutoSize = true;
            this.CellM10.Location = new System.Drawing.Point(514, 213);
            this.CellM10.Name = "CellM10";
            this.CellM10.Size = new System.Drawing.Size(34, 13);
            this.CellM10.TabIndex = 132;
            this.CellM10.Text = "0.000";
            // 
            // CellA09
            // 
            this.CellA09.AutoSize = true;
            this.CellA09.Location = new System.Drawing.Point(3, 193);
            this.CellA09.Name = "CellA09";
            this.CellA09.Size = new System.Drawing.Size(34, 13);
            this.CellA09.TabIndex = 107;
            this.CellA09.Text = "0.000";
            // 
            // CellB09
            // 
            this.CellB09.AutoSize = true;
            this.CellB09.Location = new System.Drawing.Point(43, 193);
            this.CellB09.Name = "CellB09";
            this.CellB09.Size = new System.Drawing.Size(34, 13);
            this.CellB09.TabIndex = 108;
            this.CellB09.Text = "0.000";
            // 
            // CellC09
            // 
            this.CellC09.AutoSize = true;
            this.CellC09.Location = new System.Drawing.Point(83, 193);
            this.CellC09.Name = "CellC09";
            this.CellC09.Size = new System.Drawing.Size(34, 13);
            this.CellC09.TabIndex = 109;
            this.CellC09.Text = "0.000";
            // 
            // CellD09
            // 
            this.CellD09.AutoSize = true;
            this.CellD09.Location = new System.Drawing.Point(145, 193);
            this.CellD09.Name = "CellD09";
            this.CellD09.Size = new System.Drawing.Size(34, 13);
            this.CellD09.TabIndex = 110;
            this.CellD09.Text = "0.000";
            // 
            // CellE09
            // 
            this.CellE09.AutoSize = true;
            this.CellE09.Location = new System.Drawing.Point(185, 193);
            this.CellE09.Name = "CellE09";
            this.CellE09.Size = new System.Drawing.Size(34, 13);
            this.CellE09.TabIndex = 111;
            this.CellE09.Text = "0.000";
            // 
            // CellF09
            // 
            this.CellF09.AutoSize = true;
            this.CellF09.Location = new System.Drawing.Point(225, 193);
            this.CellF09.Name = "CellF09";
            this.CellF09.Size = new System.Drawing.Size(34, 13);
            this.CellF09.TabIndex = 112;
            this.CellF09.Text = "0.000";
            // 
            // CellG09
            // 
            this.CellG09.AutoSize = true;
            this.CellG09.Location = new System.Drawing.Point(265, 193);
            this.CellG09.Name = "CellG09";
            this.CellG09.Size = new System.Drawing.Size(34, 13);
            this.CellG09.TabIndex = 113;
            this.CellG09.Text = "0.000";
            // 
            // CellH09
            // 
            this.CellH09.AutoSize = true;
            this.CellH09.Location = new System.Drawing.Point(305, 193);
            this.CellH09.Name = "CellH09";
            this.CellH09.Size = new System.Drawing.Size(34, 13);
            this.CellH09.TabIndex = 114;
            this.CellH09.Text = "0.000";
            // 
            // CellI09
            // 
            this.CellI09.AutoSize = true;
            this.CellI09.Location = new System.Drawing.Point(345, 193);
            this.CellI09.Name = "CellI09";
            this.CellI09.Size = new System.Drawing.Size(34, 13);
            this.CellI09.TabIndex = 115;
            this.CellI09.Text = "0.000";
            // 
            // CellJ09
            // 
            this.CellJ09.AutoSize = true;
            this.CellJ09.Location = new System.Drawing.Point(385, 193);
            this.CellJ09.Name = "CellJ09";
            this.CellJ09.Size = new System.Drawing.Size(34, 13);
            this.CellJ09.TabIndex = 116;
            this.CellJ09.Text = "0.000";
            // 
            // CellK09
            // 
            this.CellK09.AutoSize = true;
            this.CellK09.Location = new System.Drawing.Point(425, 193);
            this.CellK09.Name = "CellK09";
            this.CellK09.Size = new System.Drawing.Size(34, 13);
            this.CellK09.TabIndex = 117;
            this.CellK09.Text = "0.000";
            // 
            // CellL09
            // 
            this.CellL09.AutoSize = true;
            this.CellL09.Location = new System.Drawing.Point(465, 193);
            this.CellL09.Name = "CellL09";
            this.CellL09.Size = new System.Drawing.Size(34, 13);
            this.CellL09.TabIndex = 118;
            this.CellL09.Text = "0.000";
            // 
            // CellM09
            // 
            this.CellM09.AutoSize = true;
            this.CellM09.Location = new System.Drawing.Point(514, 193);
            this.CellM09.Name = "CellM09";
            this.CellM09.Size = new System.Drawing.Size(34, 13);
            this.CellM09.TabIndex = 119;
            this.CellM09.Text = "0.000";
            // 
            // CellA08
            // 
            this.CellA08.AutoSize = true;
            this.CellA08.Location = new System.Drawing.Point(3, 173);
            this.CellA08.Name = "CellA08";
            this.CellA08.Size = new System.Drawing.Size(34, 13);
            this.CellA08.TabIndex = 94;
            this.CellA08.Text = "0.000";
            // 
            // CellB08
            // 
            this.CellB08.AutoSize = true;
            this.CellB08.Location = new System.Drawing.Point(43, 173);
            this.CellB08.Name = "CellB08";
            this.CellB08.Size = new System.Drawing.Size(34, 13);
            this.CellB08.TabIndex = 95;
            this.CellB08.Text = "0.000";
            // 
            // CellC08
            // 
            this.CellC08.AutoSize = true;
            this.CellC08.Location = new System.Drawing.Point(83, 173);
            this.CellC08.Name = "CellC08";
            this.CellC08.Size = new System.Drawing.Size(34, 13);
            this.CellC08.TabIndex = 96;
            this.CellC08.Text = "0.000";
            // 
            // CellD08
            // 
            this.CellD08.AutoSize = true;
            this.CellD08.Location = new System.Drawing.Point(145, 173);
            this.CellD08.Name = "CellD08";
            this.CellD08.Size = new System.Drawing.Size(34, 13);
            this.CellD08.TabIndex = 97;
            this.CellD08.Text = "0.000";
            // 
            // CellE08
            // 
            this.CellE08.AutoSize = true;
            this.CellE08.Location = new System.Drawing.Point(185, 173);
            this.CellE08.Name = "CellE08";
            this.CellE08.Size = new System.Drawing.Size(34, 13);
            this.CellE08.TabIndex = 98;
            this.CellE08.Text = "0.000";
            // 
            // CellF08
            // 
            this.CellF08.AutoSize = true;
            this.CellF08.Location = new System.Drawing.Point(225, 173);
            this.CellF08.Name = "CellF08";
            this.CellF08.Size = new System.Drawing.Size(34, 13);
            this.CellF08.TabIndex = 99;
            this.CellF08.Text = "0.000";
            // 
            // CellG08
            // 
            this.CellG08.AutoSize = true;
            this.CellG08.Location = new System.Drawing.Point(265, 173);
            this.CellG08.Name = "CellG08";
            this.CellG08.Size = new System.Drawing.Size(34, 13);
            this.CellG08.TabIndex = 100;
            this.CellG08.Text = "0.000";
            // 
            // CellH08
            // 
            this.CellH08.AutoSize = true;
            this.CellH08.Location = new System.Drawing.Point(305, 173);
            this.CellH08.Name = "CellH08";
            this.CellH08.Size = new System.Drawing.Size(34, 13);
            this.CellH08.TabIndex = 101;
            this.CellH08.Text = "0.000";
            // 
            // CellI08
            // 
            this.CellI08.AutoSize = true;
            this.CellI08.Location = new System.Drawing.Point(345, 173);
            this.CellI08.Name = "CellI08";
            this.CellI08.Size = new System.Drawing.Size(34, 13);
            this.CellI08.TabIndex = 102;
            this.CellI08.Text = "0.000";
            // 
            // CellJ08
            // 
            this.CellJ08.AutoSize = true;
            this.CellJ08.Location = new System.Drawing.Point(385, 173);
            this.CellJ08.Name = "CellJ08";
            this.CellJ08.Size = new System.Drawing.Size(34, 13);
            this.CellJ08.TabIndex = 103;
            this.CellJ08.Text = "0.000";
            // 
            // CellK08
            // 
            this.CellK08.AutoSize = true;
            this.CellK08.Location = new System.Drawing.Point(425, 173);
            this.CellK08.Name = "CellK08";
            this.CellK08.Size = new System.Drawing.Size(34, 13);
            this.CellK08.TabIndex = 104;
            this.CellK08.Text = "0.000";
            // 
            // CellL08
            // 
            this.CellL08.AutoSize = true;
            this.CellL08.Location = new System.Drawing.Point(465, 173);
            this.CellL08.Name = "CellL08";
            this.CellL08.Size = new System.Drawing.Size(34, 13);
            this.CellL08.TabIndex = 105;
            this.CellL08.Text = "0.000";
            // 
            // CellM08
            // 
            this.CellM08.AutoSize = true;
            this.CellM08.Location = new System.Drawing.Point(514, 173);
            this.CellM08.Name = "CellM08";
            this.CellM08.Size = new System.Drawing.Size(34, 13);
            this.CellM08.TabIndex = 106;
            this.CellM08.Text = "0.000";
            // 
            // CellA07
            // 
            this.CellA07.AutoSize = true;
            this.CellA07.Location = new System.Drawing.Point(3, 153);
            this.CellA07.Name = "CellA07";
            this.CellA07.Size = new System.Drawing.Size(34, 13);
            this.CellA07.TabIndex = 81;
            this.CellA07.Text = "0.000";
            // 
            // CellB07
            // 
            this.CellB07.AutoSize = true;
            this.CellB07.Location = new System.Drawing.Point(43, 153);
            this.CellB07.Name = "CellB07";
            this.CellB07.Size = new System.Drawing.Size(34, 13);
            this.CellB07.TabIndex = 82;
            this.CellB07.Text = "0.000";
            // 
            // CellC07
            // 
            this.CellC07.AutoSize = true;
            this.CellC07.Location = new System.Drawing.Point(83, 153);
            this.CellC07.Name = "CellC07";
            this.CellC07.Size = new System.Drawing.Size(34, 13);
            this.CellC07.TabIndex = 83;
            this.CellC07.Text = "0.000";
            // 
            // CellD07
            // 
            this.CellD07.AutoSize = true;
            this.CellD07.Location = new System.Drawing.Point(145, 153);
            this.CellD07.Name = "CellD07";
            this.CellD07.Size = new System.Drawing.Size(34, 13);
            this.CellD07.TabIndex = 84;
            this.CellD07.Text = "0.000";
            // 
            // CellE07
            // 
            this.CellE07.AutoSize = true;
            this.CellE07.Location = new System.Drawing.Point(185, 153);
            this.CellE07.Name = "CellE07";
            this.CellE07.Size = new System.Drawing.Size(34, 13);
            this.CellE07.TabIndex = 85;
            this.CellE07.Text = "0.000";
            // 
            // CellF07
            // 
            this.CellF07.AutoSize = true;
            this.CellF07.Location = new System.Drawing.Point(225, 153);
            this.CellF07.Name = "CellF07";
            this.CellF07.Size = new System.Drawing.Size(34, 13);
            this.CellF07.TabIndex = 86;
            this.CellF07.Text = "0.000";
            // 
            // CellG07
            // 
            this.CellG07.AutoSize = true;
            this.CellG07.Location = new System.Drawing.Point(265, 153);
            this.CellG07.Name = "CellG07";
            this.CellG07.Size = new System.Drawing.Size(34, 13);
            this.CellG07.TabIndex = 87;
            this.CellG07.Text = "0.000";
            // 
            // CellH07
            // 
            this.CellH07.AutoSize = true;
            this.CellH07.Location = new System.Drawing.Point(305, 153);
            this.CellH07.Name = "CellH07";
            this.CellH07.Size = new System.Drawing.Size(34, 13);
            this.CellH07.TabIndex = 88;
            this.CellH07.Text = "0.000";
            // 
            // CellI07
            // 
            this.CellI07.AutoSize = true;
            this.CellI07.Location = new System.Drawing.Point(345, 153);
            this.CellI07.Name = "CellI07";
            this.CellI07.Size = new System.Drawing.Size(34, 13);
            this.CellI07.TabIndex = 89;
            this.CellI07.Text = "0.000";
            // 
            // CellJ07
            // 
            this.CellJ07.AutoSize = true;
            this.CellJ07.Location = new System.Drawing.Point(385, 153);
            this.CellJ07.Name = "CellJ07";
            this.CellJ07.Size = new System.Drawing.Size(34, 13);
            this.CellJ07.TabIndex = 90;
            this.CellJ07.Text = "0.000";
            // 
            // CellK07
            // 
            this.CellK07.AutoSize = true;
            this.CellK07.Location = new System.Drawing.Point(425, 153);
            this.CellK07.Name = "CellK07";
            this.CellK07.Size = new System.Drawing.Size(34, 13);
            this.CellK07.TabIndex = 91;
            this.CellK07.Text = "0.000";
            // 
            // CellL07
            // 
            this.CellL07.AutoSize = true;
            this.CellL07.Location = new System.Drawing.Point(465, 153);
            this.CellL07.Name = "CellL07";
            this.CellL07.Size = new System.Drawing.Size(34, 13);
            this.CellL07.TabIndex = 92;
            this.CellL07.Text = "0.000";
            // 
            // CellM07
            // 
            this.CellM07.AutoSize = true;
            this.CellM07.Location = new System.Drawing.Point(514, 153);
            this.CellM07.Name = "CellM07";
            this.CellM07.Size = new System.Drawing.Size(34, 13);
            this.CellM07.TabIndex = 93;
            this.CellM07.Text = "0.000";
            // 
            // CellA06
            // 
            this.CellA06.AutoSize = true;
            this.CellA06.Location = new System.Drawing.Point(3, 133);
            this.CellA06.Name = "CellA06";
            this.CellA06.Size = new System.Drawing.Size(34, 13);
            this.CellA06.TabIndex = 68;
            this.CellA06.Text = "0.000";
            // 
            // CellB06
            // 
            this.CellB06.AutoSize = true;
            this.CellB06.Location = new System.Drawing.Point(43, 133);
            this.CellB06.Name = "CellB06";
            this.CellB06.Size = new System.Drawing.Size(34, 13);
            this.CellB06.TabIndex = 69;
            this.CellB06.Text = "0.000";
            // 
            // CellC06
            // 
            this.CellC06.AutoSize = true;
            this.CellC06.Location = new System.Drawing.Point(83, 133);
            this.CellC06.Name = "CellC06";
            this.CellC06.Size = new System.Drawing.Size(34, 13);
            this.CellC06.TabIndex = 70;
            this.CellC06.Text = "0.000";
            // 
            // CellD06
            // 
            this.CellD06.AutoSize = true;
            this.CellD06.Location = new System.Drawing.Point(145, 133);
            this.CellD06.Name = "CellD06";
            this.CellD06.Size = new System.Drawing.Size(34, 13);
            this.CellD06.TabIndex = 71;
            this.CellD06.Text = "0.000";
            // 
            // CellE06
            // 
            this.CellE06.AutoSize = true;
            this.CellE06.Location = new System.Drawing.Point(185, 133);
            this.CellE06.Name = "CellE06";
            this.CellE06.Size = new System.Drawing.Size(34, 13);
            this.CellE06.TabIndex = 72;
            this.CellE06.Text = "0.000";
            // 
            // CellF06
            // 
            this.CellF06.AutoSize = true;
            this.CellF06.Location = new System.Drawing.Point(225, 133);
            this.CellF06.Name = "CellF06";
            this.CellF06.Size = new System.Drawing.Size(34, 13);
            this.CellF06.TabIndex = 73;
            this.CellF06.Text = "0.000";
            // 
            // CellG06
            // 
            this.CellG06.AutoSize = true;
            this.CellG06.Location = new System.Drawing.Point(265, 133);
            this.CellG06.Name = "CellG06";
            this.CellG06.Size = new System.Drawing.Size(34, 13);
            this.CellG06.TabIndex = 74;
            this.CellG06.Text = "0.000";
            // 
            // CellH06
            // 
            this.CellH06.AutoSize = true;
            this.CellH06.Location = new System.Drawing.Point(305, 133);
            this.CellH06.Name = "CellH06";
            this.CellH06.Size = new System.Drawing.Size(34, 13);
            this.CellH06.TabIndex = 75;
            this.CellH06.Text = "0.000";
            // 
            // CellI06
            // 
            this.CellI06.AutoSize = true;
            this.CellI06.Location = new System.Drawing.Point(345, 133);
            this.CellI06.Name = "CellI06";
            this.CellI06.Size = new System.Drawing.Size(34, 13);
            this.CellI06.TabIndex = 76;
            this.CellI06.Text = "0.000";
            // 
            // CellJ06
            // 
            this.CellJ06.AutoSize = true;
            this.CellJ06.Location = new System.Drawing.Point(385, 133);
            this.CellJ06.Name = "CellJ06";
            this.CellJ06.Size = new System.Drawing.Size(34, 13);
            this.CellJ06.TabIndex = 77;
            this.CellJ06.Text = "0.000";
            // 
            // CellK06
            // 
            this.CellK06.AutoSize = true;
            this.CellK06.Location = new System.Drawing.Point(425, 133);
            this.CellK06.Name = "CellK06";
            this.CellK06.Size = new System.Drawing.Size(34, 13);
            this.CellK06.TabIndex = 78;
            this.CellK06.Text = "0.000";
            // 
            // CellL06
            // 
            this.CellL06.AutoSize = true;
            this.CellL06.Location = new System.Drawing.Point(465, 133);
            this.CellL06.Name = "CellL06";
            this.CellL06.Size = new System.Drawing.Size(34, 13);
            this.CellL06.TabIndex = 79;
            this.CellL06.Text = "0.000";
            // 
            // CellM06
            // 
            this.CellM06.AutoSize = true;
            this.CellM06.Location = new System.Drawing.Point(514, 133);
            this.CellM06.Name = "CellM06";
            this.CellM06.Size = new System.Drawing.Size(34, 13);
            this.CellM06.TabIndex = 80;
            this.CellM06.Text = "0.000";
            // 
            // CellA05
            // 
            this.CellA05.AutoSize = true;
            this.CellA05.Location = new System.Drawing.Point(3, 113);
            this.CellA05.Name = "CellA05";
            this.CellA05.Size = new System.Drawing.Size(34, 13);
            this.CellA05.TabIndex = 55;
            this.CellA05.Text = "0.000";
            // 
            // CellB05
            // 
            this.CellB05.AutoSize = true;
            this.CellB05.Location = new System.Drawing.Point(43, 113);
            this.CellB05.Name = "CellB05";
            this.CellB05.Size = new System.Drawing.Size(34, 13);
            this.CellB05.TabIndex = 56;
            this.CellB05.Text = "0.000";
            // 
            // CellC05
            // 
            this.CellC05.AutoSize = true;
            this.CellC05.Location = new System.Drawing.Point(83, 113);
            this.CellC05.Name = "CellC05";
            this.CellC05.Size = new System.Drawing.Size(34, 13);
            this.CellC05.TabIndex = 57;
            this.CellC05.Text = "0.000";
            // 
            // CellD05
            // 
            this.CellD05.AutoSize = true;
            this.CellD05.Location = new System.Drawing.Point(145, 113);
            this.CellD05.Name = "CellD05";
            this.CellD05.Size = new System.Drawing.Size(34, 13);
            this.CellD05.TabIndex = 58;
            this.CellD05.Text = "0.000";
            // 
            // CellE05
            // 
            this.CellE05.AutoSize = true;
            this.CellE05.Location = new System.Drawing.Point(185, 113);
            this.CellE05.Name = "CellE05";
            this.CellE05.Size = new System.Drawing.Size(34, 13);
            this.CellE05.TabIndex = 59;
            this.CellE05.Text = "0.000";
            // 
            // CellF05
            // 
            this.CellF05.AutoSize = true;
            this.CellF05.Location = new System.Drawing.Point(225, 113);
            this.CellF05.Name = "CellF05";
            this.CellF05.Size = new System.Drawing.Size(34, 13);
            this.CellF05.TabIndex = 60;
            this.CellF05.Text = "0.000";
            // 
            // CellG05
            // 
            this.CellG05.AutoSize = true;
            this.CellG05.Location = new System.Drawing.Point(265, 113);
            this.CellG05.Name = "CellG05";
            this.CellG05.Size = new System.Drawing.Size(34, 13);
            this.CellG05.TabIndex = 61;
            this.CellG05.Text = "0.000";
            // 
            // CellH05
            // 
            this.CellH05.AutoSize = true;
            this.CellH05.Location = new System.Drawing.Point(305, 113);
            this.CellH05.Name = "CellH05";
            this.CellH05.Size = new System.Drawing.Size(34, 13);
            this.CellH05.TabIndex = 62;
            this.CellH05.Text = "0.000";
            // 
            // CellI05
            // 
            this.CellI05.AutoSize = true;
            this.CellI05.Location = new System.Drawing.Point(345, 113);
            this.CellI05.Name = "CellI05";
            this.CellI05.Size = new System.Drawing.Size(34, 13);
            this.CellI05.TabIndex = 63;
            this.CellI05.Text = "0.000";
            // 
            // CellJ05
            // 
            this.CellJ05.AutoSize = true;
            this.CellJ05.Location = new System.Drawing.Point(385, 113);
            this.CellJ05.Name = "CellJ05";
            this.CellJ05.Size = new System.Drawing.Size(34, 13);
            this.CellJ05.TabIndex = 64;
            this.CellJ05.Text = "0.000";
            // 
            // CellK05
            // 
            this.CellK05.AutoSize = true;
            this.CellK05.Location = new System.Drawing.Point(425, 113);
            this.CellK05.Name = "CellK05";
            this.CellK05.Size = new System.Drawing.Size(34, 13);
            this.CellK05.TabIndex = 65;
            this.CellK05.Text = "0.000";
            // 
            // CellL05
            // 
            this.CellL05.AutoSize = true;
            this.CellL05.Location = new System.Drawing.Point(465, 113);
            this.CellL05.Name = "CellL05";
            this.CellL05.Size = new System.Drawing.Size(34, 13);
            this.CellL05.TabIndex = 66;
            this.CellL05.Text = "0.000";
            // 
            // CellM05
            // 
            this.CellM05.AutoSize = true;
            this.CellM05.Location = new System.Drawing.Point(514, 113);
            this.CellM05.Name = "CellM05";
            this.CellM05.Size = new System.Drawing.Size(34, 13);
            this.CellM05.TabIndex = 67;
            this.CellM05.Text = "0.000";
            // 
            // CellA04
            // 
            this.CellA04.AutoSize = true;
            this.CellA04.Location = new System.Drawing.Point(3, 93);
            this.CellA04.Name = "CellA04";
            this.CellA04.Size = new System.Drawing.Size(34, 13);
            this.CellA04.TabIndex = 42;
            this.CellA04.Text = "0.000";
            // 
            // CellB04
            // 
            this.CellB04.AutoSize = true;
            this.CellB04.Location = new System.Drawing.Point(43, 93);
            this.CellB04.Name = "CellB04";
            this.CellB04.Size = new System.Drawing.Size(34, 13);
            this.CellB04.TabIndex = 43;
            this.CellB04.Text = "0.000";
            // 
            // CellC04
            // 
            this.CellC04.AutoSize = true;
            this.CellC04.Location = new System.Drawing.Point(83, 93);
            this.CellC04.Name = "CellC04";
            this.CellC04.Size = new System.Drawing.Size(34, 13);
            this.CellC04.TabIndex = 44;
            this.CellC04.Text = "0.000";
            // 
            // CellD04
            // 
            this.CellD04.AutoSize = true;
            this.CellD04.Location = new System.Drawing.Point(145, 93);
            this.CellD04.Name = "CellD04";
            this.CellD04.Size = new System.Drawing.Size(34, 13);
            this.CellD04.TabIndex = 45;
            this.CellD04.Text = "0.000";
            // 
            // CellE04
            // 
            this.CellE04.AutoSize = true;
            this.CellE04.Location = new System.Drawing.Point(185, 93);
            this.CellE04.Name = "CellE04";
            this.CellE04.Size = new System.Drawing.Size(34, 13);
            this.CellE04.TabIndex = 46;
            this.CellE04.Text = "0.000";
            // 
            // CellF04
            // 
            this.CellF04.AutoSize = true;
            this.CellF04.Location = new System.Drawing.Point(225, 93);
            this.CellF04.Name = "CellF04";
            this.CellF04.Size = new System.Drawing.Size(34, 13);
            this.CellF04.TabIndex = 47;
            this.CellF04.Text = "0.000";
            // 
            // CellG04
            // 
            this.CellG04.AutoSize = true;
            this.CellG04.Location = new System.Drawing.Point(265, 93);
            this.CellG04.Name = "CellG04";
            this.CellG04.Size = new System.Drawing.Size(34, 13);
            this.CellG04.TabIndex = 48;
            this.CellG04.Text = "0.000";
            // 
            // CellH04
            // 
            this.CellH04.AutoSize = true;
            this.CellH04.Location = new System.Drawing.Point(305, 93);
            this.CellH04.Name = "CellH04";
            this.CellH04.Size = new System.Drawing.Size(34, 13);
            this.CellH04.TabIndex = 49;
            this.CellH04.Text = "0.000";
            // 
            // CellI04
            // 
            this.CellI04.AutoSize = true;
            this.CellI04.Location = new System.Drawing.Point(345, 93);
            this.CellI04.Name = "CellI04";
            this.CellI04.Size = new System.Drawing.Size(34, 13);
            this.CellI04.TabIndex = 50;
            this.CellI04.Text = "0.000";
            // 
            // CellJ04
            // 
            this.CellJ04.AutoSize = true;
            this.CellJ04.Location = new System.Drawing.Point(385, 93);
            this.CellJ04.Name = "CellJ04";
            this.CellJ04.Size = new System.Drawing.Size(34, 13);
            this.CellJ04.TabIndex = 51;
            this.CellJ04.Text = "0.000";
            // 
            // CellK04
            // 
            this.CellK04.AutoSize = true;
            this.CellK04.Location = new System.Drawing.Point(425, 93);
            this.CellK04.Name = "CellK04";
            this.CellK04.Size = new System.Drawing.Size(34, 13);
            this.CellK04.TabIndex = 52;
            this.CellK04.Text = "0.000";
            // 
            // CellL04
            // 
            this.CellL04.AutoSize = true;
            this.CellL04.Location = new System.Drawing.Point(465, 93);
            this.CellL04.Name = "CellL04";
            this.CellL04.Size = new System.Drawing.Size(34, 13);
            this.CellL04.TabIndex = 53;
            this.CellL04.Text = "0.000";
            // 
            // CellM04
            // 
            this.CellM04.AutoSize = true;
            this.CellM04.Location = new System.Drawing.Point(514, 93);
            this.CellM04.Name = "CellM04";
            this.CellM04.Size = new System.Drawing.Size(34, 13);
            this.CellM04.TabIndex = 54;
            this.CellM04.Text = "0.000";
            // 
            // CellA03
            // 
            this.CellA03.AutoSize = true;
            this.CellA03.Location = new System.Drawing.Point(3, 73);
            this.CellA03.Name = "CellA03";
            this.CellA03.Size = new System.Drawing.Size(34, 13);
            this.CellA03.TabIndex = 29;
            this.CellA03.Text = "0.000";
            // 
            // CellB03
            // 
            this.CellB03.AutoSize = true;
            this.CellB03.Location = new System.Drawing.Point(43, 73);
            this.CellB03.Name = "CellB03";
            this.CellB03.Size = new System.Drawing.Size(34, 13);
            this.CellB03.TabIndex = 30;
            this.CellB03.Text = "0.000";
            // 
            // CellC03
            // 
            this.CellC03.AutoSize = true;
            this.CellC03.Location = new System.Drawing.Point(83, 73);
            this.CellC03.Name = "CellC03";
            this.CellC03.Size = new System.Drawing.Size(34, 13);
            this.CellC03.TabIndex = 31;
            this.CellC03.Text = "0.000";
            // 
            // CellD03
            // 
            this.CellD03.AutoSize = true;
            this.CellD03.Location = new System.Drawing.Point(145, 73);
            this.CellD03.Name = "CellD03";
            this.CellD03.Size = new System.Drawing.Size(34, 13);
            this.CellD03.TabIndex = 32;
            this.CellD03.Text = "0.000";
            // 
            // CellE03
            // 
            this.CellE03.AutoSize = true;
            this.CellE03.Location = new System.Drawing.Point(185, 73);
            this.CellE03.Name = "CellE03";
            this.CellE03.Size = new System.Drawing.Size(34, 13);
            this.CellE03.TabIndex = 33;
            this.CellE03.Text = "0.000";
            // 
            // CellF03
            // 
            this.CellF03.AutoSize = true;
            this.CellF03.Location = new System.Drawing.Point(225, 73);
            this.CellF03.Name = "CellF03";
            this.CellF03.Size = new System.Drawing.Size(34, 13);
            this.CellF03.TabIndex = 34;
            this.CellF03.Text = "0.000";
            // 
            // CellG03
            // 
            this.CellG03.AutoSize = true;
            this.CellG03.Location = new System.Drawing.Point(265, 73);
            this.CellG03.Name = "CellG03";
            this.CellG03.Size = new System.Drawing.Size(34, 13);
            this.CellG03.TabIndex = 35;
            this.CellG03.Text = "0.000";
            // 
            // CellH03
            // 
            this.CellH03.AutoSize = true;
            this.CellH03.Location = new System.Drawing.Point(305, 73);
            this.CellH03.Name = "CellH03";
            this.CellH03.Size = new System.Drawing.Size(34, 13);
            this.CellH03.TabIndex = 36;
            this.CellH03.Text = "0.000";
            // 
            // CellI03
            // 
            this.CellI03.AutoSize = true;
            this.CellI03.Location = new System.Drawing.Point(345, 73);
            this.CellI03.Name = "CellI03";
            this.CellI03.Size = new System.Drawing.Size(34, 13);
            this.CellI03.TabIndex = 37;
            this.CellI03.Text = "0.000";
            // 
            // CellJ03
            // 
            this.CellJ03.AutoSize = true;
            this.CellJ03.Location = new System.Drawing.Point(385, 73);
            this.CellJ03.Name = "CellJ03";
            this.CellJ03.Size = new System.Drawing.Size(34, 13);
            this.CellJ03.TabIndex = 38;
            this.CellJ03.Text = "0.000";
            // 
            // CellK03
            // 
            this.CellK03.AutoSize = true;
            this.CellK03.Location = new System.Drawing.Point(425, 73);
            this.CellK03.Name = "CellK03";
            this.CellK03.Size = new System.Drawing.Size(34, 13);
            this.CellK03.TabIndex = 39;
            this.CellK03.Text = "0.000";
            // 
            // CellL03
            // 
            this.CellL03.AutoSize = true;
            this.CellL03.Location = new System.Drawing.Point(465, 73);
            this.CellL03.Name = "CellL03";
            this.CellL03.Size = new System.Drawing.Size(34, 13);
            this.CellL03.TabIndex = 40;
            this.CellL03.Text = "0.000";
            // 
            // CellM03
            // 
            this.CellM03.AutoSize = true;
            this.CellM03.Location = new System.Drawing.Point(514, 73);
            this.CellM03.Name = "CellM03";
            this.CellM03.Size = new System.Drawing.Size(34, 13);
            this.CellM03.TabIndex = 41;
            this.CellM03.Text = "0.000";
            // 
            // CellA02
            // 
            this.CellA02.AutoSize = true;
            this.CellA02.Location = new System.Drawing.Point(3, 53);
            this.CellA02.Name = "CellA02";
            this.CellA02.Size = new System.Drawing.Size(34, 13);
            this.CellA02.TabIndex = 16;
            this.CellA02.Text = "0.000";
            // 
            // CellM02
            // 
            this.CellM02.AutoSize = true;
            this.CellM02.Location = new System.Drawing.Point(514, 53);
            this.CellM02.Name = "CellM02";
            this.CellM02.Size = new System.Drawing.Size(34, 13);
            this.CellM02.TabIndex = 17;
            this.CellM02.Text = "0.000";
            // 
            // CellL02
            // 
            this.CellL02.AutoSize = true;
            this.CellL02.Location = new System.Drawing.Point(465, 53);
            this.CellL02.Name = "CellL02";
            this.CellL02.Size = new System.Drawing.Size(34, 13);
            this.CellL02.TabIndex = 18;
            this.CellL02.Text = "0.000";
            // 
            // CellK02
            // 
            this.CellK02.AutoSize = true;
            this.CellK02.Location = new System.Drawing.Point(425, 53);
            this.CellK02.Name = "CellK02";
            this.CellK02.Size = new System.Drawing.Size(34, 13);
            this.CellK02.TabIndex = 19;
            this.CellK02.Text = "0.000";
            // 
            // CellJ02
            // 
            this.CellJ02.AutoSize = true;
            this.CellJ02.Location = new System.Drawing.Point(385, 53);
            this.CellJ02.Name = "CellJ02";
            this.CellJ02.Size = new System.Drawing.Size(34, 13);
            this.CellJ02.TabIndex = 20;
            this.CellJ02.Text = "0.000";
            // 
            // CellI02
            // 
            this.CellI02.AutoSize = true;
            this.CellI02.Location = new System.Drawing.Point(345, 53);
            this.CellI02.Name = "CellI02";
            this.CellI02.Size = new System.Drawing.Size(34, 13);
            this.CellI02.TabIndex = 21;
            this.CellI02.Text = "0.000";
            // 
            // CellH02
            // 
            this.CellH02.AutoSize = true;
            this.CellH02.Location = new System.Drawing.Point(305, 53);
            this.CellH02.Name = "CellH02";
            this.CellH02.Size = new System.Drawing.Size(34, 13);
            this.CellH02.TabIndex = 22;
            this.CellH02.Text = "0.000";
            // 
            // CellG02
            // 
            this.CellG02.AutoSize = true;
            this.CellG02.Location = new System.Drawing.Point(265, 53);
            this.CellG02.Name = "CellG02";
            this.CellG02.Size = new System.Drawing.Size(34, 13);
            this.CellG02.TabIndex = 23;
            this.CellG02.Text = "0.000";
            // 
            // CellF02
            // 
            this.CellF02.AutoSize = true;
            this.CellF02.Location = new System.Drawing.Point(225, 53);
            this.CellF02.Name = "CellF02";
            this.CellF02.Size = new System.Drawing.Size(34, 13);
            this.CellF02.TabIndex = 24;
            this.CellF02.Text = "0.000";
            // 
            // CellE02
            // 
            this.CellE02.AutoSize = true;
            this.CellE02.Location = new System.Drawing.Point(185, 53);
            this.CellE02.Name = "CellE02";
            this.CellE02.Size = new System.Drawing.Size(34, 13);
            this.CellE02.TabIndex = 25;
            this.CellE02.Text = "0.000";
            // 
            // CellD02
            // 
            this.CellD02.AutoSize = true;
            this.CellD02.Location = new System.Drawing.Point(145, 53);
            this.CellD02.Name = "CellD02";
            this.CellD02.Size = new System.Drawing.Size(34, 13);
            this.CellD02.TabIndex = 26;
            this.CellD02.Text = "0.000";
            // 
            // CellC02
            // 
            this.CellC02.AutoSize = true;
            this.CellC02.Location = new System.Drawing.Point(83, 53);
            this.CellC02.Name = "CellC02";
            this.CellC02.Size = new System.Drawing.Size(34, 13);
            this.CellC02.TabIndex = 27;
            this.CellC02.Text = "0.000";
            // 
            // CellB02
            // 
            this.CellB02.AutoSize = true;
            this.CellB02.Location = new System.Drawing.Point(43, 53);
            this.CellB02.Name = "CellB02";
            this.CellB02.Size = new System.Drawing.Size(34, 13);
            this.CellB02.TabIndex = 28;
            this.CellB02.Text = "0.000";
            // 
            // CellA01
            // 
            this.CellA01.AutoSize = true;
            this.CellA01.Location = new System.Drawing.Point(3, 33);
            this.CellA01.Name = "CellA01";
            this.CellA01.Size = new System.Drawing.Size(34, 13);
            this.CellA01.TabIndex = 13;
            this.CellA01.Text = "0.000";
            // 
            // CellB01
            // 
            this.CellB01.AutoSize = true;
            this.CellB01.Location = new System.Drawing.Point(43, 33);
            this.CellB01.Name = "CellB01";
            this.CellB01.Size = new System.Drawing.Size(34, 13);
            this.CellB01.TabIndex = 13;
            this.CellB01.Text = "0.000";
            // 
            // CellC01
            // 
            this.CellC01.AutoSize = true;
            this.CellC01.Location = new System.Drawing.Point(83, 33);
            this.CellC01.Name = "CellC01";
            this.CellC01.Size = new System.Drawing.Size(34, 13);
            this.CellC01.TabIndex = 13;
            this.CellC01.Text = "0.000";
            // 
            // CellD01
            // 
            this.CellD01.AutoSize = true;
            this.CellD01.Location = new System.Drawing.Point(145, 33);
            this.CellD01.Name = "CellD01";
            this.CellD01.Size = new System.Drawing.Size(34, 13);
            this.CellD01.TabIndex = 13;
            this.CellD01.Text = "0.000";
            // 
            // CellE01
            // 
            this.CellE01.AutoSize = true;
            this.CellE01.Location = new System.Drawing.Point(185, 33);
            this.CellE01.Name = "CellE01";
            this.CellE01.Size = new System.Drawing.Size(34, 13);
            this.CellE01.TabIndex = 13;
            this.CellE01.Text = "0.000";
            // 
            // CellF01
            // 
            this.CellF01.AutoSize = true;
            this.CellF01.Location = new System.Drawing.Point(225, 33);
            this.CellF01.Name = "CellF01";
            this.CellF01.Size = new System.Drawing.Size(34, 13);
            this.CellF01.TabIndex = 13;
            this.CellF01.Text = "0.000";
            // 
            // CellG01
            // 
            this.CellG01.AutoSize = true;
            this.CellG01.Location = new System.Drawing.Point(265, 33);
            this.CellG01.Name = "CellG01";
            this.CellG01.Size = new System.Drawing.Size(34, 13);
            this.CellG01.TabIndex = 13;
            this.CellG01.Text = "0.000";
            // 
            // CellH01
            // 
            this.CellH01.AutoSize = true;
            this.CellH01.Location = new System.Drawing.Point(305, 33);
            this.CellH01.Name = "CellH01";
            this.CellH01.Size = new System.Drawing.Size(34, 13);
            this.CellH01.TabIndex = 13;
            this.CellH01.Text = "0.000";
            // 
            // CellI01
            // 
            this.CellI01.AutoSize = true;
            this.CellI01.Location = new System.Drawing.Point(345, 33);
            this.CellI01.Name = "CellI01";
            this.CellI01.Size = new System.Drawing.Size(34, 13);
            this.CellI01.TabIndex = 13;
            this.CellI01.Text = "0.000";
            // 
            // CellJ01
            // 
            this.CellJ01.AutoSize = true;
            this.CellJ01.Location = new System.Drawing.Point(385, 33);
            this.CellJ01.Name = "CellJ01";
            this.CellJ01.Size = new System.Drawing.Size(34, 13);
            this.CellJ01.TabIndex = 13;
            this.CellJ01.Text = "0.000";
            // 
            // CellK01
            // 
            this.CellK01.AutoSize = true;
            this.CellK01.Location = new System.Drawing.Point(425, 33);
            this.CellK01.Name = "CellK01";
            this.CellK01.Size = new System.Drawing.Size(34, 13);
            this.CellK01.TabIndex = 13;
            this.CellK01.Text = "0.000";
            // 
            // CellL01
            // 
            this.CellL01.AutoSize = true;
            this.CellL01.Location = new System.Drawing.Point(465, 33);
            this.CellL01.Name = "CellL01";
            this.CellL01.Size = new System.Drawing.Size(34, 13);
            this.CellL01.TabIndex = 13;
            this.CellL01.Text = "0.000";
            // 
            // CellM01
            // 
            this.CellM01.AutoSize = true;
            this.CellM01.Location = new System.Drawing.Point(514, 33);
            this.CellM01.Name = "CellM01";
            this.CellM01.Size = new System.Drawing.Size(34, 13);
            this.CellM01.TabIndex = 15;
            this.CellM01.Text = "0.000";
            // 
            // CellA00
            // 
            this.CellA00.AutoSize = true;
            this.CellA00.Location = new System.Drawing.Point(3, 0);
            this.CellA00.Name = "CellA00";
            this.CellA00.Size = new System.Drawing.Size(16, 13);
            this.CellA00.TabIndex = 0;
            this.CellA00.Text = "Xi";
            // 
            // CellB00
            // 
            this.CellB00.AutoSize = true;
            this.CellB00.Location = new System.Drawing.Point(43, 0);
            this.CellB00.Name = "CellB00";
            this.CellB00.Size = new System.Drawing.Size(21, 26);
            this.CellB00.TabIndex = 10;
            this.CellB00.Text = "R\r\n[m]";
            // 
            // CellC00
            // 
            this.CellC00.AutoSize = true;
            this.CellC00.Location = new System.Drawing.Point(83, 0);
            this.CellC00.Name = "CellC00";
            this.CellC00.Size = new System.Drawing.Size(56, 26);
            this.CellC00.TabIndex = 13;
            this.CellC00.Text = "Spenn-\r\nlengde [m]";
            // 
            // CellD00
            // 
            this.CellD00.AutoSize = true;
            this.CellD00.Location = new System.Drawing.Point(145, 0);
            this.CellD00.Name = "CellD00";
            this.CellD00.Size = new System.Drawing.Size(27, 26);
            this.CellD00.TabIndex = 11;
            this.CellD00.Text = "b1\r\n[cm]";
            // 
            // CellE00
            // 
            this.CellE00.AutoSize = true;
            this.CellE00.Location = new System.Drawing.Point(185, 0);
            this.CellE00.Name = "CellE00";
            this.CellE00.Size = new System.Drawing.Size(27, 26);
            this.CellE00.TabIndex = 12;
            this.CellE00.Text = "b2\r\n[cm]";
            // 
            // CellF00
            // 
            this.CellF00.AutoSize = true;
            this.CellF00.Location = new System.Drawing.Point(225, 0);
            this.CellF00.Name = "CellF00";
            this.CellF00.Size = new System.Drawing.Size(25, 26);
            this.CellF00.TabIndex = 12;
            this.CellF00.Text = "Fd1\r\n[N]";
            // 
            // CellG00
            // 
            this.CellG00.AutoSize = true;
            this.CellG00.Location = new System.Drawing.Point(265, 0);
            this.CellG00.Name = "CellG00";
            this.CellG00.Size = new System.Drawing.Size(25, 26);
            this.CellG00.TabIndex = 14;
            this.CellG00.Text = "Fd2\r\n[N]";
            // 
            // CellH00
            // 
            this.CellH00.AutoSize = true;
            this.CellH00.Location = new System.Drawing.Point(305, 0);
            this.CellH00.Name = "CellH00";
            this.CellH00.Size = new System.Drawing.Size(27, 26);
            this.CellH00.TabIndex = 13;
            this.CellH00.Text = "c\r\n[cm]";
            // 
            // CellI00
            // 
            this.CellI00.AutoSize = true;
            this.CellI00.Location = new System.Drawing.Point(345, 0);
            this.CellI00.Name = "CellI00";
            this.CellI00.Size = new System.Drawing.Size(27, 26);
            this.CellI00.TabIndex = 11;
            this.CellI00.Text = "  E\r\n[cm]";
            // 
            // CellJ00
            // 
            this.CellJ00.AutoSize = true;
            this.CellJ00.Location = new System.Drawing.Point(385, 0);
            this.CellJ00.Name = "CellJ00";
            this.CellJ00.Size = new System.Drawing.Size(27, 26);
            this.CellJ00.TabIndex = 12;
            this.CellJ00.Text = "  e_l\r\n[cm]";
            // 
            // CellK00
            // 
            this.CellK00.AutoSize = true;
            this.CellK00.Location = new System.Drawing.Point(425, 0);
            this.CellK00.Name = "CellK00";
            this.CellK00.Size = new System.Drawing.Size(30, 26);
            this.CellK00.TabIndex = 11;
            this.CellK00.Text = "  e_r\r\n [cm]";
            // 
            // CellL00
            // 
            this.CellL00.AutoSize = true;
            this.CellL00.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CellL00.Location = new System.Drawing.Point(465, 0);
            this.CellL00.Name = "CellL00";
            this.CellL00.Size = new System.Drawing.Size(43, 30);
            this.CellL00.TabIndex = 13;
            this.CellL00.Text = "Spenn\r\nType";
            // 
            // CellM00
            // 
            this.CellM00.AutoSize = true;
            this.CellM00.Location = new System.Drawing.Point(514, 0);
            this.CellM00.Name = "CellM00";
            this.CellM00.Size = new System.Drawing.Size(23, 13);
            this.CellM00.TabIndex = 263;
            this.CellM00.Text = "NN";
            // 
            // resultsFormBindingSource1
            // 
            this.resultsFormBindingSource1.DataSource = typeof(KLAppGlobal.ResultsForm);
            // 
            // resultsFormBindingSource
            // 
            this.resultsFormBindingSource.DataSource = typeof(KLAppGlobal.ResultsForm);
            // 
            // ResultsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(521, 356);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "ResultsForm";
            this.Text = "KL Mast";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.resultsFormBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resultsFormBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        public System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        public System.Windows.Forms.Label CellF00;
        public System.Windows.Forms.Label CellI00;
        public System.Windows.Forms.Label CellJ00;
        public System.Windows.Forms.Label CellK00;
        public System.Windows.Forms.Label CellL00;
        public System.Windows.Forms.Label CellE00;
        public System.Windows.Forms.Label CellD00;
        public System.Windows.Forms.Label CellC00;
        public System.Windows.Forms.Label CellB00;
        public System.Windows.Forms.Label CellA00;
        public System.Windows.Forms.Label CellH00;
        public System.Windows.Forms.Label CellA01;
        public System.Windows.Forms.Label CellB01;
        public System.Windows.Forms.Label CellC01;
        public System.Windows.Forms.Label CellD01;
        public System.Windows.Forms.Label CellE01;
        public System.Windows.Forms.Label CellF01;
        public System.Windows.Forms.Label CellG01;
        public System.Windows.Forms.Label CellH01;
        public System.Windows.Forms.Label CellI01;
        public System.Windows.Forms.Label CellJ01;
        public System.Windows.Forms.Label CellK01;
        public System.Windows.Forms.Label CellL01;
        public System.Windows.Forms.BindingSource resultsFormBindingSource;
        public System.Windows.Forms.BindingSource resultsFormBindingSource1;
        public System.Windows.Forms.Label CellG00;
        public System.Windows.Forms.Label CellM01;
        public System.Windows.Forms.Label CellA20;
        public System.Windows.Forms.Label CellB20;
        public System.Windows.Forms.Label CellC20;
        public System.Windows.Forms.Label CellD20;
        public System.Windows.Forms.Label CellE20;
        public System.Windows.Forms.Label CellF20;
        public System.Windows.Forms.Label CellG20;
        public System.Windows.Forms.Label CellH20;
        public System.Windows.Forms.Label CellI20;
        public System.Windows.Forms.Label CellJ20;
        public System.Windows.Forms.Label CellK20;
        public System.Windows.Forms.Label CellL20;
        public System.Windows.Forms.Label CellM20;
        public System.Windows.Forms.Label CellA19;
        public System.Windows.Forms.Label CellB19;
        public System.Windows.Forms.Label CellC19;
        public System.Windows.Forms.Label CellD19;
        public System.Windows.Forms.Label CellE19;
        public System.Windows.Forms.Label CellF19;
        public System.Windows.Forms.Label CellG19;
        public System.Windows.Forms.Label CellH19;
        public System.Windows.Forms.Label CellI19;
        public System.Windows.Forms.Label CellJ19;
        public System.Windows.Forms.Label CellK19;
        public System.Windows.Forms.Label CellL19;
        public System.Windows.Forms.Label CellM19;
        public System.Windows.Forms.Label CellA18;
        public System.Windows.Forms.Label CellB18;
        public System.Windows.Forms.Label CellC18;
        public System.Windows.Forms.Label CellD18;
        public System.Windows.Forms.Label CellE18;
        public System.Windows.Forms.Label CellF18;
        public System.Windows.Forms.Label CellG18;
        public System.Windows.Forms.Label CellH18;
        public System.Windows.Forms.Label CellI18;
        public System.Windows.Forms.Label CellJ18;
        public System.Windows.Forms.Label CellK18;
        public System.Windows.Forms.Label CellL18;
        public System.Windows.Forms.Label CellM18;
        public System.Windows.Forms.Label CellA17;
        public System.Windows.Forms.Label CellB17;
        public System.Windows.Forms.Label CellC17;
        public System.Windows.Forms.Label CellD17;
        public System.Windows.Forms.Label CellE17;
        public System.Windows.Forms.Label CellF17;
        public System.Windows.Forms.Label CellG17;
        public System.Windows.Forms.Label CellH17;
        public System.Windows.Forms.Label CellI17;
        public System.Windows.Forms.Label CellJ17;
        public System.Windows.Forms.Label CellK17;
        public System.Windows.Forms.Label CellL17;
        public System.Windows.Forms.Label CellM17;
        public System.Windows.Forms.Label CellA16;
        public System.Windows.Forms.Label CellB16;
        public System.Windows.Forms.Label CellC16;
        public System.Windows.Forms.Label CellD16;
        public System.Windows.Forms.Label CellE16;
        public System.Windows.Forms.Label CellF16;
        public System.Windows.Forms.Label CellG16;
        public System.Windows.Forms.Label CellH16;
        public System.Windows.Forms.Label CellI16;
        public System.Windows.Forms.Label CellJ16;
        public System.Windows.Forms.Label CellK16;
        public System.Windows.Forms.Label CellL16;
        public System.Windows.Forms.Label CellM16;
        public System.Windows.Forms.Label CellA15;
        public System.Windows.Forms.Label CellB15;
        public System.Windows.Forms.Label CellC15;
        public System.Windows.Forms.Label CellD15;
        public System.Windows.Forms.Label CellE15;
        public System.Windows.Forms.Label CellF15;
        public System.Windows.Forms.Label CellG15;
        public System.Windows.Forms.Label CellH15;
        public System.Windows.Forms.Label CellI15;
        public System.Windows.Forms.Label CellJ15;
        public System.Windows.Forms.Label CellK15;
        public System.Windows.Forms.Label CellL15;
        public System.Windows.Forms.Label CellM15;
        public System.Windows.Forms.Label CellA14;
        public System.Windows.Forms.Label CellB14;
        public System.Windows.Forms.Label CellC14;
        public System.Windows.Forms.Label CellD14;
        public System.Windows.Forms.Label CellE14;
        public System.Windows.Forms.Label CellF14;
        public System.Windows.Forms.Label CellG14;
        public System.Windows.Forms.Label CellH14;
        public System.Windows.Forms.Label CellI14;
        public System.Windows.Forms.Label CellJ14;
        public System.Windows.Forms.Label CellK14;
        public System.Windows.Forms.Label CellL14;
        public System.Windows.Forms.Label CellM14;
        public System.Windows.Forms.Label CellA13;
        public System.Windows.Forms.Label CellB13;
        public System.Windows.Forms.Label CellC13;
        public System.Windows.Forms.Label CellD13;
        public System.Windows.Forms.Label CellE13;
        public System.Windows.Forms.Label CellF13;
        public System.Windows.Forms.Label CellG13;
        public System.Windows.Forms.Label CellH13;
        public System.Windows.Forms.Label CellI13;
        public System.Windows.Forms.Label CellJ13;
        public System.Windows.Forms.Label CellK13;
        public System.Windows.Forms.Label CellL13;
        public System.Windows.Forms.Label CellM13;
        public System.Windows.Forms.Label CellA12;
        public System.Windows.Forms.Label CellB12;
        public System.Windows.Forms.Label CellC12;
        public System.Windows.Forms.Label CellD12;
        public System.Windows.Forms.Label CellE12;
        public System.Windows.Forms.Label CellF12;
        public System.Windows.Forms.Label CellG12;
        public System.Windows.Forms.Label CellH12;
        public System.Windows.Forms.Label CellI12;
        public System.Windows.Forms.Label CellJ12;
        public System.Windows.Forms.Label CellK12;
        public System.Windows.Forms.Label CellL12;
        public System.Windows.Forms.Label CellM12;
        public System.Windows.Forms.Label CellA11;
        public System.Windows.Forms.Label CellB11;
        public System.Windows.Forms.Label CellC11;
        public System.Windows.Forms.Label CellD11;
        public System.Windows.Forms.Label CellE11;
        public System.Windows.Forms.Label CellF11;
        public System.Windows.Forms.Label CellG11;
        public System.Windows.Forms.Label CellH11;
        public System.Windows.Forms.Label CellI11;
        public System.Windows.Forms.Label CellJ11;
        public System.Windows.Forms.Label CellK11;
        public System.Windows.Forms.Label CellL11;
        public System.Windows.Forms.Label CellM11;
        public System.Windows.Forms.Label CellA10;
        public System.Windows.Forms.Label CellB10;
        public System.Windows.Forms.Label CellC10;
        public System.Windows.Forms.Label CellD10;
        public System.Windows.Forms.Label CellE10;
        public System.Windows.Forms.Label CellF10;
        public System.Windows.Forms.Label CellG10;
        public System.Windows.Forms.Label CellH10;
        public System.Windows.Forms.Label CellI10;
        public System.Windows.Forms.Label CellJ10;
        public System.Windows.Forms.Label CellK10;
        public System.Windows.Forms.Label CellL10;
        public System.Windows.Forms.Label CellM10;
        public System.Windows.Forms.Label CellA09;
        public System.Windows.Forms.Label CellB09;
        public System.Windows.Forms.Label CellC09;
        public System.Windows.Forms.Label CellD09;
        public System.Windows.Forms.Label CellE09;
        public System.Windows.Forms.Label CellF09;
        public System.Windows.Forms.Label CellG09;
        public System.Windows.Forms.Label CellH09;
        public System.Windows.Forms.Label CellI09;
        public System.Windows.Forms.Label CellJ09;
        public System.Windows.Forms.Label CellK09;
        public System.Windows.Forms.Label CellL09;
        public System.Windows.Forms.Label CellM09;
        public System.Windows.Forms.Label CellA08;
        public System.Windows.Forms.Label CellB08;
        public System.Windows.Forms.Label CellC08;
        public System.Windows.Forms.Label CellD08;
        public System.Windows.Forms.Label CellE08;
        public System.Windows.Forms.Label CellF08;
        public System.Windows.Forms.Label CellG08;
        public System.Windows.Forms.Label CellH08;
        public System.Windows.Forms.Label CellI08;
        public System.Windows.Forms.Label CellJ08;
        public System.Windows.Forms.Label CellK08;
        public System.Windows.Forms.Label CellL08;
        public System.Windows.Forms.Label CellM08;
        public System.Windows.Forms.Label CellA07;
        public System.Windows.Forms.Label CellB07;
        public System.Windows.Forms.Label CellC07;
        public System.Windows.Forms.Label CellD07;
        public System.Windows.Forms.Label CellE07;
        public System.Windows.Forms.Label CellF07;
        public System.Windows.Forms.Label CellG07;
        public System.Windows.Forms.Label CellH07;
        public System.Windows.Forms.Label CellI07;
        public System.Windows.Forms.Label CellJ07;
        public System.Windows.Forms.Label CellK07;
        public System.Windows.Forms.Label CellL07;
        public System.Windows.Forms.Label CellM07;
        public System.Windows.Forms.Label CellA06;
        public System.Windows.Forms.Label CellB06;
        public System.Windows.Forms.Label CellC06;
        public System.Windows.Forms.Label CellD06;
        public System.Windows.Forms.Label CellE06;
        public System.Windows.Forms.Label CellF06;
        public System.Windows.Forms.Label CellG06;
        public System.Windows.Forms.Label CellH06;
        public System.Windows.Forms.Label CellI06;
        public System.Windows.Forms.Label CellJ06;
        public System.Windows.Forms.Label CellK06;
        public System.Windows.Forms.Label CellL06;
        public System.Windows.Forms.Label CellM06;
        public System.Windows.Forms.Label CellA05;
        public System.Windows.Forms.Label CellB05;
        public System.Windows.Forms.Label CellC05;
        public System.Windows.Forms.Label CellD05;
        public System.Windows.Forms.Label CellE05;
        public System.Windows.Forms.Label CellF05;
        public System.Windows.Forms.Label CellG05;
        public System.Windows.Forms.Label CellH05;
        public System.Windows.Forms.Label CellI05;
        public System.Windows.Forms.Label CellJ05;
        public System.Windows.Forms.Label CellK05;
        public System.Windows.Forms.Label CellL05;
        public System.Windows.Forms.Label CellM05;
        public System.Windows.Forms.Label CellA04;
        public System.Windows.Forms.Label CellB04;
        public System.Windows.Forms.Label CellC04;
        public System.Windows.Forms.Label CellD04;
        public System.Windows.Forms.Label CellE04;
        public System.Windows.Forms.Label CellF04;
        public System.Windows.Forms.Label CellG04;
        public System.Windows.Forms.Label CellH04;
        public System.Windows.Forms.Label CellI04;
        public System.Windows.Forms.Label CellJ04;
        public System.Windows.Forms.Label CellK04;
        public System.Windows.Forms.Label CellL04;
        public System.Windows.Forms.Label CellM04;
        public System.Windows.Forms.Label CellA03;
        public System.Windows.Forms.Label CellB03;
        public System.Windows.Forms.Label CellC03;
        public System.Windows.Forms.Label CellD03;
        public System.Windows.Forms.Label CellE03;
        public System.Windows.Forms.Label CellF03;
        public System.Windows.Forms.Label CellG03;
        public System.Windows.Forms.Label CellH03;
        public System.Windows.Forms.Label CellI03;
        public System.Windows.Forms.Label CellJ03;
        public System.Windows.Forms.Label CellK03;
        public System.Windows.Forms.Label CellL03;
        public System.Windows.Forms.Label CellM03;
        public System.Windows.Forms.Label CellA02;
        public System.Windows.Forms.Label CellM02;
        public System.Windows.Forms.Label CellL02;
        public System.Windows.Forms.Label CellK02;
        public System.Windows.Forms.Label CellJ02;
        public System.Windows.Forms.Label CellI02;
        public System.Windows.Forms.Label CellH02;
        public System.Windows.Forms.Label CellG02;
        public System.Windows.Forms.Label CellF02;
        public System.Windows.Forms.Label CellE02;
        public System.Windows.Forms.Label CellD02;
        public System.Windows.Forms.Label CellC02;
        public System.Windows.Forms.Label CellB02;
        public System.Windows.Forms.Label CellM00;
    }
}

