﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Threading.Tasks;
using System.Windows.Forms;
using OxyPlot;
using OxyPlot.Series;
using OxyPlot.WindowsForms;
using System.Security.Cryptography;

namespace KLAppGlobal
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        //
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            FrontForm MainPage = new FrontForm();
            Application.Run(MainPage);
        }
    }
    public class KL_span
    {
        //public double b;          //Zig-zag offset/utslag i rett line
        public double lo;         //KL_felt maks avstand i rett line
        public double Vw;         //Vind hastighet for prosjektering
        public double Fw;         //Maksimal vindlast på KL per lengde
        public double Fdmin;       //Minst tillat strekkkraft i lettdireksjonsstag
        public double H;          //Strekkkraft i kontakttrådet 
        public double R;          //Sporfelt radius (kurvatur)
        public double E;          //Utslag fra spormidt i vind utblåsning
        public double Kt_avst_v;    //Avstand mellom parallel KL i vekslingsfelt
        public double Kt_avst_s;  //Avstand mellom parallel KL i seksjosfelt
        public double Kt_avst;
        public double B1;         //Zig-zag offset på start punktet til normal spenningsfeltet (i normal felt).
        public double x1;         //Start posisjon til spenn
        public double x2;         //Slutt posisjon til spenn
        public double b1;         //Zig-zag offset på start punktet etter beregning (skal være en av B1...B5)
        public double b2;         //Zig-zag offset på ende punktet etter beregning (skal være en av B1...B5)
        public double c;
        public double Mast_zpos;  //(+/-) Mastens posisjon i forhold til sportrase
        public double Lu;         //Avstand fra avspennings lodd til midtspor (Ca utligger lengde)
        public string SpennType;
        //Output variables
        public double a;          //Maks mast avstand i normal felt (basert på vindutblåsning).
        public double Fd_B1;      //Strekkkraft i lettdireksjonsstag @B1
        public double Fd_B2;      //Strekkkraft i lettdireksjonsstag @B2
        //Variabler til x-y beregning
        public double Px1; public double Py1;
        public double Px2; public double Py2;

        public DataRow Results;
        //Variables for calculations
        double Ra; double Ql;
        double Qr; public double sgn;
        public double b1_temp; public double b2_temp;
        double b2max; double b2min;
        //intermediate variables, to be used in functions
        public double B2of_Fd2min_l;
        public double B2of_Fd2min_r;
        public double B2of_emax_l;
        public double B2of_emax_r;
        public double e_l; public double e_r;
        public KL_span() // Initialize parameters with their default values
        {
            R = 1e6; lo = 65;
            Fw = 15; Fdmin = 80;
            H = 20000; sgn = 1;
            Kt_avst_v = 0.2; Kt_avst_s = 0.45; Kt_avst = 0;
            B1 = -0.3; b1 = B1; b2 = -B1;
            Mast_zpos = -1; Lu = 3.5;
            //Output variables
            a = lo;     SpennType = "Normal";
            Fd_B1 = Fd_B2 = 0;
        }
        public void LK_SysLoad(OCLSystem sys)
        {
            H = sys.H; Fw = sys.Fw; Fdmin = sys.Fdmin; lo = sys.lo;
        }
        public void CalcSpan(string SpennType)
        {
            b2max = 0.3; b2min = -0.3;
            Ra = Math.Abs(R); sgn = Math.Sign(R);
            Ql = 1 / Ra - Fw / H; Qr = 1 / Ra + Fw / H;
            b1_temp = b1 * sgn;
            B2of_Fd2min_r = b1_temp + lo * lo / (2 * Ra) + lo * (2 * Fdmin) / (2 * H);
            B2of_Fd2min_l = b1_temp + lo * lo / (2 * Ra) - lo * (2 * Fdmin) / (2 * H);
            B2of_emax_r = Math.Max(b1_temp - lo * lo * Qr / 2 + lo * Math.Sqrt(2 * Qr * (E - b1_temp)), b2min);
            if (Ql >= 0) { B2of_emax_l = Math.Min(Math.Max(B2of_Fd2min_l, b2min), b2max); }
            else { B2of_emax_l = Math.Min(b1_temp - lo * lo * Ql / 2 - lo * Math.Sqrt(-2 * Ql * (E + b1_temp)), b2max); }

            if (SpennType == "Normal")
            {
                if (b1_temp > 0) { b2_temp = B1; }
                else { b2_temp = Optimal_b2(); }
                b2 = b2_temp * sgn;
                Calc_a_FdB1_FdB2_c(b1_temp, b2_temp);
            }
            else if (SpennType == "Veksling" || SpennType == "Seksjonering")
            {
                if (SpennType == "Veksling") { Kt_avst = Kt_avst_v; } else { Kt_avst = Kt_avst_s; }
                b1_temp = b1 * sgn;
                bool Finished = false;
                //if (b1_temp > B1 + Kt_avst) { b2_temp = B1; } //Commented on 21.11.02
                //else { b2_temp = Math.Max(b2min, B1 - Kt_avst - H * (2 * E - Kt_avst) / (Fw * Ra)); }
                //b2 = (b2_temp - Kt_avst) * sgn;
                //if (b1_temp == b2_temp + Kt_avst) { a = Math.Min(lo, MaxSpan_emax_r(b1_temp, b2_temp)); }
                //else { a = Math.Min(lo, 2 * Math.Sqrt(H * (2 * E - Kt_avst) / Fw)); }
                //if (b1_temp == B1)//Commented on 11.08.21
                //{
                //    a = lo; b2_temp = (2 * E - Kt_avst) * H / Ra - (b1_temp + Kt_avst);
                //    if (b2_temp <= b2max - Kt_avst && (Ql * a * a / 8 + (b2_temp + b1_temp) / 2 + (b2_temp - b1_temp) * (b2_temp - b1_temp) / (2 * a * a * Ql)) >= -E) { Finished = true; }
                //}
                //else
                if (b1_temp != B1)
                {
                    a = lo; b2_temp = b1_temp - a * a * Ql / 2 - a * Math.Sqrt(-2 * Ql * (E + b1_temp));
                    if (b2_temp >= b2min - Kt_avst && (Qr * a * a / 8 + (b2_temp + b1_temp + 2*Kt_avst) / 2 + (b2_temp - b1_temp) * (b2_temp - b1_temp) / (2 * a * a * Qr)) <= E) { Finished = true; }
                }
                //if (Finished == false)
                //{
                //    a = Math.Min(Math.Sqrt(4 * (2 * E - Kt_avst) * H / Fw), lo);
                //    b2_temp = -b1_temp - Kt_avst - H * (2 * E - Kt_avst) / (Ra * Fw);
                //    if(b2min - Kt_avst <= b2_temp &&  0 <= (b2_temp - b1_temp)*Ql) { Finished = true; }
                //    else if (b2_temp < b2min - Kt_avst && 0 >= (b2_temp - b1_temp) * Ql) { b2_temp = b2min - Kt_avst; a = Math.Sqrt(2*(Math.Sqrt((2*b1_temp+Kt_avst-E)*(2 * b2_temp + Kt_avst - E))-(b1_temp+b2_temp+2*(Kt_avst-E)))); }
                //    if ((b2_temp - b1_temp) * Ql <0) { Finished = true; }
                //}
                if (Finished == false)
                {
                    double c1; double c2; double c3; double c4; double c5; double c6; double A; double B; double C; double m; double n;
                    c1 = Ql * Ql; c2 = 4 * Ql; c3 = 8 * Ql * (b1_temp + E); c4 = Qr * Qr; c5 = 4 * Qr; c6 = 8 * Qr * (b1_temp + Kt_avst - E);
                    A = c1 * (c5 - c2) * (c5 - c2) - c2 * (c4 - c1) * (c5 - c2) + (c4 - c1) * (c4 - c1); B = -c2 * (c6 - c3) * (c5 - c2) + c3 * (c5 - c2) * (c5 - c2) + 2 * (c6 - c3) * (c4 - c1); C = (c6 - c3) * (c6 - c3);
                    m = -(c4 - c1) / (c5 - c2); n = -(c6 - c3) / (c5 - c2);
                    //A = (Qr - Ql) * (Qr - Ql) / 16; B = (Qr + 4 * Ql) * b1_temp + 2 * Qr * E / (Qr - Ql) -Kt_avst; C = 4 * Math.Pow((Ql * (b1_temp + E) - Qr * (b1_temp + Kt_avst - E)) / (Qr - Ql), 2);
                    try { a = Math.Sqrt((-B + Math.Sqrt(B * B - 4 * A * C)) / (2 * A)); 
                    //b2_temp = b1_temp + ((c4 - c1) * a + c6 - c3) / (c2 - c5);
                    b2_temp = b1_temp + Math.Sqrt(-(m*c2+c1)*a*a*a*a+(c3-n*c2)*a*a);
                        if (0<=(b2_temp - b1_temp) / (Ql * a) && (b2_temp - b1_temp) / (Ql * a) <= a/2 &&
                            0 <= (b2_temp - b1_temp) / (Qr * a) && (b2_temp - b1_temp) / (Qr * a) <= a / 2) { Finished = true; }
                    }
                    catch { }
                    //if (b1_temp == B1) { b2_temp = b2max - Kt_avst; } else { b2_temp = b2min; }
                    //a = Math.Sqrt(((2 * E - Kt_avst) - Math.Sqrt((2 * E - Kt_avst) * (2 * E - Kt_avst) - Math.Pow(2 * Fw * (b2_temp - b1_temp / H), 2) / ((Fw / H) * (Fw / H) - 1 / (Ra * Ra)))) / (Fw / (2 * H)));
                    //b2_temp = b1_temp + lo * Math.Sqrt((H / Fw) * ((Fw / H) * (Fw / H) - 1 / (Ra * Ra)) * (2 * E - Kt_avst - lo * lo * Fw / (4 * H))); a = lo;
                    //if ((b1_temp+b2_temp)/2+a*a/(8*Qr)<=E) { Finished = true; }
                    //if (b2_temp <= b1_temp) { Finished = true; }
                }
                //if (Finished == false)
                //{
                //    double A; double B; double C;
                //    A = Ql * Ql / 4; B = Ql * (b1_temp + E - Kt_avst); C = (E - Kt_avst - b1_temp) * (E - Kt_avst - b1_temp);
                //    try
                //    {
                //        a = Math.Min(Math.Sqrt((-B + Math.Sqrt(B * B - 4 * A * C)) / (2 * A)), lo);
                //        b2_temp = E-Kt_avst;
                //        if (0 <= (b2_temp - b1_temp) / (Ql * a) && (b2_temp - b1_temp) / (Ql * a) <= a / 2 &&
                //            (b2_temp - b1_temp) / (Qr * a) >= a / 2) { Finished = true; }
                //    } catch { }
                //}
                //if (Finished == false)
                //{
                //    double A; double B; double C;
                //    A = Qr * Qr / 4; B = Qr * (2 * b1_temp - 3 * E + 2 * Kt_avst); C = (b2_temp - b1_temp) * (b2_temp - b1_temp);
                //    try
                //    {
                //        a = Math.Sqrt((-B + Math.Sqrt(B * B - 4 * A * C)) / (2 * A));
                //        b2_temp = -E;
                //        if ((b2_temp - b1_temp) / (Ql * a) >= a / 2 &&
                //            (b2_temp - b1_temp) / (Qr * a) <= a / 2) { Finished = true; }
                //    }
                //    catch { }
                //}
                b2 = b2_temp * sgn;
                //a = 2 * Math.Sqrt((H/Fw)*(2*E-Kt_avst));
                Calc_FdB1_FdB2_c(a, b1, b2);
                //if (B1 < b2 * sgn - Kt_avst && b2 * sgn - Kt_avst < -B1) { Kt_avst = -Kt_avst; }  // Rearrange the parallel wire with the gap distance 
            }
            else if (SpennType == "Veksl_avspenning" || SpennType == "Seksj_avspenning")
            {
                if (SpennType == "Veksl_avspenning") { Kt_avst = Kt_avst_v; } else { Kt_avst = Kt_avst_s; }
                //if (B1 < b1 - Kt_avst && b1 - Kt_avst < -B1) { Kt_avst = - Kt_avst; }
                if(b1 >= 0.4) { b1_temp = (b1 - Kt_avst) * sgn; b2_temp = Optimal_b2(); }
                else if(b1 <= -0.4) { b1_temp = (b1 + Kt_avst) * sgn ; b2_temp = Optimal_b2(); }
                //else if(0 < b1 && b1 <= 0.3) { b1_temp = b1 * sgn + Kt_avst; b2_temp = B1; }
                else { b1_temp = b1 * sgn;  b2_temp = Optimal_b2(); }
                b2 = Lu * Math.Sign(Mast_zpos);
                Calc_a_FdB1_FdB2_c(b1_temp, b2_temp);
                Calc_FdB1_FdB2_c(a, b1, b2);
            }
            else if (SpennType == "Veksl_5Spn_2nd")
            {
                Kt_avst = Kt_avst_v; b2 = -0.3 * sgn; b1_temp = B1; b2_temp = B1;
                Calc_a_FdB1_FdB2_c(b1_temp, b2_temp);
            }
            else if (SpennType == "Veksl_5Spn_3rd")
            {
                Kt_avst = Kt_avst_v; b2 = -0.3 * sgn; b1_temp = B1; b2_temp = B1;
                a = 2 * Math.Sqrt((2 / (Fw / H + 1 / Ra)) * (E - b2_temp - Kt_avst));
            }
            else if (SpennType == "Veksl_5Spn_4th")
            {
                Kt_avst = Kt_avst_v; b2 = -0.5 * sgn; b1_temp = b1 * sgn + Kt_avst; b2_temp = B1;
                Calc_a_FdB1_FdB2_c(b1_temp, b2_temp);
            }
            else if (SpennType == "Veksl_5Spn_avsp")
            {
                Kt_avst = Kt_avst_v; b2 = Lu * Math.Sign(Mast_zpos); b1_temp = B1; b2_temp = Optimal_b2();
                Calc_a_FdB1_FdB2_c(b1_temp, b2_temp);
            }
            else if (SpennType == "Seksj_5Spn_2nd")
            {
                Kt_avst = Kt_avst_s; b2 = -0.4 * sgn; b1_temp = b1 * sgn; b2_temp = -0.4;
                Calc_a_FdB1_FdB2_c(b1_temp, b2_temp);
            }
            else if (SpennType == "Seksj_5Spn_3rd")
            {
                Kt_avst = Kt_avst_s; b2 = -0.4 * sgn; b1_temp = b1 * sgn; b2_temp = -0.4;
                a = 2 * Math.Sqrt((2 * H / (Fw + H / Ra)) * (E - b2_temp - Kt_avst));
            }
            else if (SpennType == "Seksj_5Spn_4th")
            {
                Kt_avst = Kt_avst_s; b2 = -0.75 * sgn; b1_temp = b1 * sgn + Kt_avst; b2_temp = B1;
                Calc_a_FdB1_FdB2_c(b1_temp, b2_temp);
            }
            else if (SpennType == "Seksj_5Spn_avsp")
            {
                Kt_avst = Kt_avst_s; b2 = Lu * Math.Sign(Mast_zpos); b1_temp = B1; b2_temp = Optimal_b2();
                Calc_a_FdB1_FdB2_c(b1_temp, b2_temp);
            }
        }
        public double Optimal_b2() // Function to determine b2 and a while b1=B1.
        {
            //Algorithm for determining b2
            if (Math.Min(b2max, B2of_emax_r) >= B2of_Fd2min_r) { b2_temp = Math.Min(b2max, B2of_emax_r); }
            else if (Math.Max(b2min, B2of_emax_l) <= Math.Min(B2of_emax_r, B2of_Fd2min_l)) { b2_temp = Math.Min(B2of_emax_r, B2of_Fd2min_l); }
            else { if (Ra > 5000) { b2_temp = B2of_Fd2min_r; /*b2_temp = Math.Max(b2min, B2of_Fd2min_l);*/ } else { b2_temp = b2min; } }
            return b2_temp;
        }
        public void Calc_a_FdB1_FdB2_c(double bx1, double bx2)
        {
            a = Math.Min(lo, Math.Min(MaxSpan_emax_l(b1_temp, b2_temp), MaxSpan_emax_r(b1_temp, b2_temp)));
            Fd_B1 = H * (a / R + 2 * (bx1 - bx2) / a) / 2;
            Fd_B2 = H * (a / R - 2 * (bx1 - bx2) / a) / 2;
            // c: Kontakttrådens plassering midt i spennet, målt fra spormidt uten vindblåsning
            c = (bx1 + bx2) / 2 + a * a / (8 * Ra);
            e_l = Ql * a * a / 8 + (bx1 + bx2) / 2;
            e_r = Qr * a * a / 8 + (bx1 + bx2) / 2;
            return;
        }
        public void Calc_FdB1_FdB2_c(double a_l, double bx1, double bx2)
        {
            // Strekkkraft på lettdireksjonsstag (@ B1 og @ B2). Del med 2 til å finne kreften på letdireksjonsstag
            Fd_B1 = H * (a_l / R + 2 * (bx1 - bx2) / a_l) / 2;
            Fd_B2 = H * (a_l / R - 2 * (bx1 - bx2) / a_l) / 2;
            // c: Kontakttrådens plassering midt i spennet, målt fra spormidt uten vindblåsning
            c = (bx1 + bx2) / 2 + a_l * a_l / (8 * Ra);
            e_l = Ql * a_l * a_l / 8 + (bx1 + bx2) / 2;
            e_r = Qr * a_l * a_l / 8 + (bx1 + bx2) / 2;
            return;
        }
        double MaxSpan_emax_l(double bx1, double bx2)
        {
            if (Ql >= 0) { return lo; }
            else { return Math.Sqrt((4 * Math.Sqrt((E + bx1) * (E + bx2)) + 2 * (2 * E + bx1 + bx2)) / -Ql); }
        }
        double MaxSpan_emax_r(double bx1, double bx2)
        { return Math.Sqrt((4 * Math.Sqrt((E - bx1) * (E - bx2)) + 2 * (2 * E - bx1 - bx2)) / Qr); }
        double MaxSpan_Fd2min_l(double bx1, double bx2)
        { return Ra / 2 * (2 * Fdmin / H + Math.Sqrt((2 * Fdmin / H) * (2 * Fdmin / H) - 8 * (bx1 - bx2) / Ra)); }
        public object Clone() { return this.MemberwiseClone(); }
        
    }
    public class Wire       // Defines the type and attributes of a wire
    {
        public string ID;   // ID, name or type of the wire
        public int n;       //No. of wire strands
        public double A_nom;// Cross sectional area (nominal)
        public double A_act;// Cross sectional area (actual)
        public double D;    // Diameter
        public double r;    // Resistance per meter length
        public double m;    // Mass per meter length
        public double w;    // Weight per meter length
        public double sigma_min;    // Minimum stress the conductor must be able to manage without failure or permanet deformation
        public double sigma_per;    // Permissible stress the conductor must be able to manage without failure or permanet deformation
        public double F_per;   // Permissible tensile force
        public double E_mod;    // Modulus of elasticity for the conductor
        public double C_drag;    //Drag factor of the conductor wire
        public Wire(DataRow row) // Creates wire object from data table 
        {
            ID = (string)(row[0]); n = (int)(row[1]);
            A_nom = (double)(row[2]); A_act = (double)(row[3]);
            r = (double)(row[4]); m = (double)(row[5]);
            w = (double)(row[6]); sigma_min = (double)(row[7]);
            sigma_per = (double)(row[8]); F_per = (double)(row[9]);
            E_mod = (double)(row[10]); C_drag = (double)(row[11]); D = 2 * Math.Sqrt(A_act / 3.1415927) * 1e-3;
        }
    }
    public class Create_OCL_wire_Table
    {
        public DataTable DT = new DataTable();
        public Create_OCL_wire_Table()
        {   // Use an Object array to insert all the rows .
            // Values in the array are matched sequentially to the columns, based on the order in which they appear in the table
            DT.Columns.Add(new DataColumn("Wire ID", typeof(string)));
            DT.Columns.Add(new DataColumn("No. of Strands", typeof(int)));
            DT.Columns.Add(new DataColumn("A_nom", typeof(double)));
            DT.Columns.Add(new DataColumn("A_act", typeof(double)));
            DT.Columns.Add(new DataColumn("r", typeof(double)));
            DT.Columns.Add(new DataColumn("m", typeof(double)));
            DT.Columns.Add(new DataColumn("w", typeof(double)));
            DT.Columns.Add(new DataColumn("σ_min", typeof(double)));
            DT.Columns.Add(new DataColumn("σ_per", typeof(double)));
            DT.Columns.Add(new DataColumn("F_per", typeof(double)));
            DT.Columns.Add(new DataColumn("E_mod", typeof(double)));
            DT.Columns.Add(new DataColumn("C_drag", typeof(double)));
            DT.PrimaryKey = new DataColumn[] { DT.Columns["Wire ID"] };
            //Keissling pp.262 Table 5.3: Material properties of conductors in accordance with DIN 48 201,
            //EN 50 182 and of contact of wires in accordance with EN 50 149.
            //Keissling pp.664 Table 10.1: Resistances per unit length of conductors at 20 °C and 40 °C, values in mΩ / km.
            //Keissling pp.665 Table 10.2: Resistance per unit length R of overhead contact lines at 20 °C and 40°C, data in mΩ / km.
            //pp. 672 Table 10.6: Example to calculate line impedance, self-impedance for 50Hz.
            Object[] rows = {// Wire ID       No. of      A_nom    A_act     r        m       w       σ_min   σ_per   F_per E_mod   C_drag
                              //(name)      strands(n)  [mm2]   [mm2]    [Ohm/m]   [kg/m]  [N/m]    [N/mm2] [N/mm2] [kN]  [kN/mm2]    
               new Object[]{ "AC_80_Cu_ETP",        1,  80,     80,     1.99e-4,    0.717,  7.034,  355,    170.1,  13.6,   100,    1},
               new Object[]{ "AC_100_Cu_ETP",       1,  100,    100,    1.59e-4,    0.896,  8.790,  355,    170.1,  13.6,   100,    1},
               new Object[]{ "AC_107_Cu_ETP",       1,  107,    107,    1.49e-4,    0.959,  9.408,  355,    170.1,  13.6,   100,    1},
               new Object[]{ "AC_120_Cu_ETP",       1,  120,    120,    1.33e-4,    1.075,  10.55,  355,    170.1,  13.6,   100,    1},
               new Object[]{ "AC_150_Cu_ETP",       1,  150,    150,    1.06e-4,    1.344,  13.18,  355,    170.1,  13.6,   100,    1},
               new Object[]{ "AC_80_CuAg",          1,  80,     80,     1.99e-4,    0.717,  7.034,  355,    170.1,  13.6,   100,    1},
               new Object[]{ "AC_100_CuAg",         1,  100,    100,    1.59e-4,    0.896,  8.790,  355,    170.1,  13.6,   100,    1},
               new Object[]{ "AC_107_CuAg",         1,  107,    107,    1.49e-4,    0.959,  9.408,  355,    170.1,  13.6,   100,    1},
               new Object[]{ "AC_120_CuAg",         1,  120,    120,    1.33e-4,    1.075,  10.55,  355,    170.1,  13.6,   100,    1},
               new Object[]{ "AC_150_CuAg",         1,  150,    150,    1.06e-4,    1.344,  13.18,  355,    170.1,  13.6,   100,    1},
               new Object[]{ "AC_80_CuMg",          1,  80,     80,     1.99e-4,    0.717,  7.034,  355,    170.1,  13.6,   100,    1},
               new Object[]{ "AC_100_CuMg",         1,  100,    100,    1.59e-4,    0.896,  8.790,  355,    170.1,  13.6,   100,    1},
               new Object[]{ "AC_107_CuMg",         1,  107,    107,    1.49e-4,    0.959,  9.408,  355,    170.1,  13.6,   100,    1},
               new Object[]{ "AC_120_CuMg",         1,  120,    120,    1.33e-4,    1.075,  10.55,  355,    170.1,  13.6,   100,    1},
               new Object[]{ "AC_150_CuMg",         1,  150,    150,    1.06e-4,    1.344,  13.18,  355,    170.1,  13.6,   100,    1},
               new Object[]{ "AC_80_CuSn",          1,  80,     80,     1.99e-4,    0.717,  7.034,  355,    170.1,  13.6,   100,    1},
               new Object[]{ "AC_100_CuSn",         1,  100,    100,    1.59e-4,    0.896,  8.790,  355,    170.1,  13.6,   100,    1},
               new Object[]{ "AC_107_CuSn",         1,  107,    107,    1.49e-4,    0.959,  9.408,  355,    170.1,  13.6,   100,    1},
               new Object[]{ "AC_120_CuSn",         1,  120,    120,    1.33e-4,    1.075,  10.55,  355,    170.1,  13.6,   100,    1},
               new Object[]{ "AC_150_CuSn",         1,  150,    150,    1.06e-4,    1.344,  13.18,  355,    170.1,  13.6,   100,    1},
               new Object[]{ "DIN_48_201_50_E_Cu",  19, 50,     48.35,  3.60e-4,    0.433,  4.247,  401,    170.1,  13.6,   100,    1},
               new Object[]{ "DIN_48_201_70_E_Cu",  19, 70,     65.81,  2.71e-4,    0.590,  5.788,  401,    170.1,  13.6,   100,    1},
               new Object[]{ "DIN_48_201_95_E_Cu",  19, 95,     93.27,  1.91e-4,    0.836,  8.201,  401,    170.1,  13.6,   100,    1},
               new Object[]{ "DIN_48_201_120_E_Cu", 19, 120,    116.99, 1.53e-4,    1.048,  10.28,  401,    170.1,  13.6,   100,    1},
               new Object[]{ "DIN_48_201_150_E_Cu", 19, 150,    150,    1.21e-4,    1.344,  13.18,  401,    170.1,  13.6,   100,    1},
               new Object[]{ "DIN_48_201_240_E_Cu", 61, 240,    242.54, 0.69e-4,    2.173,  21.32,  401,    170.1,  13.6,   100,    1},
               new Object[]{ "DIN_48_201_50_BzII",  19, 50,     48.35,  5.61e-4,    0.433,  4.248,  587,    170.1,  13.6,   100,    1},
               new Object[]{ "DIN_48_201_70_BzII",  19, 70,     65.81,  4.22e-4,    0.590,  5.788,  587,    170.1,  13.6,   100,    1},
               new Object[]{ "DIN_48_201_95_BzII",  19, 95,     93.27,  2.98e-4,    0.836,  8.201,  587,    170.1,  13.6,   100,    1},
               new Object[]{ "DIN_48_201_120_BzII", 19, 120,    116.99, 2.37e-4,    1.048,  10.28,  587,    170.1,  13.6,   100,    1},
               new Object[]{ "DIN_48_201_150_BzII", 19, 150,    150,    1.89e-4,    1.344,  13.18,  587,    170.1,  13.6,   100,    1},
               new Object[]{ "DIN_48_201_240_BzII", 61, 240,    242.54, 0.69e-4,    2.173,  21.32,  587,    170.1,  13.6,   100,    1},
                    };
            foreach (Object[] row in rows) { DT.Rows.Add(row); }
        }
    }
    public class ProjectInfo
    {
        public string ProjectName; public string ProjectNo;
        public string Mast1; public string Mast2;
        public string spanDesigner; public string spanDesignDate;
        public ProjectInfo()
        {
            ProjectName = "Bane NOR New Project"; ProjectNo = "BN 0000";
            Mast1 = "M001"; Mast2 = "M002";
            spanDesigner = "Designer's Name"; spanDesignDate = "01.01.2020";
        }
        public void Update(string ProjectName, string ProjectNo, string Mast1, string Mast2, string spanDesigner, string spanDesignDate)
        {
            this.ProjectName = ProjectName; this.ProjectNo = ProjectNo;
            this.Mast1 = Mast1; this.Mast2 = Mast2;
            this.spanDesignDate = spanDesigner; this.spanDesignDate = spanDesignDate;
        }
    }
    public class OCLSystem
    {
        public double H;        //Strekkkraft i OCL
        public double Vw;       //Vind hastighet
        public double Vw_kast;  //Vind kast hastighet
        public double Fw;       //Sidevindkraft på KL
        public double Fdmin;     //Minste strekkraft på lettdireksjonsstag
        public double lo;       //Maks spennlengde
        public double y1;       //Kontakttrådenshøyde fra horizontaltline på avspenningfelt midtpunktet
        public double y2;       //Kontakttrådenshøyde fra horizontaltline på siste utligger før avspenning
        public double ym;
        public double amin_3spenn;//Minstspenn lengde på 3-spenn avspenning
        public double amin_5spenn;//Minstspenn lengde på 5-spenn avspenning
        public Wire Ktwire;
        public Wire Blwire;
        public OCLSystem()
        {
            H = 20000; Vw = 22;
            Fw = 15; Fdmin = 80;
            y1 = 0.06;      //Kontakttrådenshøyde fra horizontaltline på avspenningfelt midtpunktet
            y2 = 0.5;       //Kontakttrådenshøyde fra horizontaltline på siste utligger før avspenning i 3-spenn avspenning
            ym = 0.15;      //Kontakttrådenshøyde fra horizontaltline på siste utligger før avspenning i 5-spenn avspenning
        }
        public void CalcParams()
        {
            Vw_kast = Vw * Math.Sqrt(2.06);
            Fw = 1.2 * 1.07 * 0.625 * Vw_kast * Vw_kast * (Ktwire.C_drag * Ktwire.D + Blwire.C_drag * Blwire.D);
            amin_3spenn = 2 * (Math.Sqrt(H * y2 / Fw) - Math.Sqrt(H * y1 / Fw));
            amin_5spenn = 2 * (Math.Sqrt(H * ym / Fw) - Math.Sqrt(H * y1 / Fw));
        }
    }
    public class VindUtblTabel
    {
        public DataTable DT = new DataTable();
        public VindUtblTabel(int Type)
        {
            // Use an Object array to insert all the rows .
            // Values in the array are matched sequentially to the columns, based on the order in which they appear in the table.
            DT.Columns.Add(new DataColumn("Radius(m)", typeof(double)));
            DT.Columns.Add(new DataColumn("E(cm)", typeof(double)));
            if(Type == 2) 
            { Object[] rows = {//Radius    Vindutblåsning (E)
                            //   [m]        [cm]
                   new Object[]{250,        0.319},
                   new Object[]{400,        0.323},
                   new Object[]{700,        0.326},
                   new Object[]{1000,       0.326},
                   new Object[]{2000,       0.328},
                   new Object[]{10000,      0.40},
                   new Object[]{1e8,        0.40},
                    };
                foreach (Object[] row in rows) { DT.Rows.Add(row); }
            }
            else if (Type == 1)
            {
                Object[] rows = {//Radius    Vindutblåsning (E)
                            //   [m]        [cm]
                   new Object[]{180,        0.40},
                   new Object[]{300,        0.43},
                   new Object[]{600,        0.43},
                   new Object[]{700,        0.44},
                   new Object[]{900,        0.44},
                   new Object[]{1000,       0.45},
                   new Object[]{2000,       0.45},
                   new Object[]{3000,       0.50},
                   new Object[]{1e8,        0.50},
                    };
                foreach (Object[] row in rows) { DT.Rows.Add(row); }
            }
            else  {
                Object[] rows = {//Radius    Vindutblåsning (E)
                            //   [m]        [cm]
                   new Object[]{180,        0.42},
                   new Object[]{1000,       0.42},
                   new Object[]{2000,       0.50},
                   new Object[]{4000,       0.55},
                   new Object[]{1e8,        0.55},
                    };
                foreach (Object[] row in rows) { DT.Rows.Add(row); }
            }
        }
        public static double Find_E(double R, VindUtblTabel tempDT)
        {
            //VindUtblTabel tempDT = new VindUtblTabel();
            double temp = 0;
            double Ra = Math.Abs(R);
            for (int i = 0; i < (tempDT.DT.Rows.Count); i++)
            {
                if (Ra <= (double)tempDT.DT.Rows[0][0]) { temp = (double)tempDT.DT.Rows[0][1]; }
                else if (Ra == (double)tempDT.DT.Rows[i][0]) { temp = (double)tempDT.DT.Rows[i][1]; }
                else if (Ra >= (double)tempDT.DT.Rows[tempDT.DT.Rows.Count-1][0]) { temp = (double)tempDT.DT.Rows[3][1]; }
                else
                {
                    if ((Ra > (double)tempDT.DT.Rows[i][0]) && (Ra < (double)tempDT.DT.Rows[i + 1][0]))
                    { temp = (double)tempDT.DT.Rows[i][1] + ((double)tempDT.DT.Rows[i + 1][1] - (double)tempDT.DT.Rows[i][1]) * (Ra - (double)tempDT.DT.Rows[i][0]) / ((double)tempDT.DT.Rows[i + 1][0] - (double)tempDT.DT.Rows[i][0]); }
                }
            }
            return temp;
        }
    }
    public class TraseLedd
    {
        // Start punkt patameterer
        public double R1;           public double ϴ1;
        public double x1;           public double x2;
        public double c;            public double L;
        public string TypeKurve;    public string KurveRetning;
        public KL_span KL = new KL_span();
        // Intermediate variables
        public double Ri;           public double Rj;
        public double Li;           public double ϴi;
        public double Pxo;          public double Pyo;
        // Slut punkt parameterer
        public double Δϴ;           public double ΔL;
        public double R2;           public double ϴ2;
        public double Px1;          public double Py1;
        public double Px2;          public double Py2;
        public double Pxi;          public double Pyi;
        public double ΔPx;          public double ΔPy;
        public TraseLedd()
        {
            R1 = 1e6;               ϴ1 = 0;
            x1 = 0;                 x2 = 0;
            c = 0;                  L = 0;
            TypeKurve = "Rett linje"; KurveRetning = "+";
            Ri = R1;                Rj = R2;
            Li = 0;                 ϴi = 0;
            Pxo = 0;                Pyo = 0;
            Δϴ = 0;                 ΔL = 0;
            R2 = 1e6;               ϴ2 = 0;
            Px1 = 0;                Py1 = 0;
            Px2 = 0;                Py2 = 0;
            Pxi = 0;                Pyi = 0;
            ΔPx = 0;                ΔPy = 0;
        }
        public TraseLedd Clone()
        {
            TraseLedd copy = new TraseLedd();
            copy.R1 = this.R1; copy.ϴ1 = this.ϴ1;
            copy.x1 = this.x1; copy.x2 = this.x2;
            copy.c = this.c; copy.L = this.L;
            copy.TypeKurve = this.TypeKurve; copy.KurveRetning = this.KurveRetning;
            copy.Ri = this.Ri; copy.Rj = this.Rj;
            copy.Li = this.Li; copy.ϴi = this.ϴi;
            copy.Pxo = this.Pxo; copy.Pyo = this.Pyo;
            copy.Δϴ = this.Δϴ; copy.ΔL = this.ΔL;
            copy.R2 = this.R2; copy.ϴ2 = this.ϴ2;
            copy.Px1 = this.Px1; copy.Py1 = this.Py1;
            copy.Px2 = this.Px2; copy.Py2 = this.Py2;
            copy.Pxi = this.Pxi; copy.Pyi = this.Pyi;
            copy.ΔPx = this.ΔPx; copy.ΔPy = this.ΔPy;
            copy.KL = (KL_span)this.KL.Clone();
            return copy;
        }
        public void Segment_calc()
        {
            /*if(Math.Abs(R1) < 1e6 && Math.Abs(R2) < 1e6) { c = (1 / R2 - 1 / R1) / L; }
            else if (Math.Abs(R1) >= 1e6 && Math.Abs(R2) < 1e6) { c = 1 / (L* R2); }
            else if (Math.Abs(R1) < 1e6 && Math.Abs(R2) >= 1e6) { c = - 1 / (L * R1); }
            else { c = 0; }
            */c = (1 / R2 - 1 / R1) / L;
            KL.R = 2 * R1 * R2 / (R1 + R2);
            if (TypeKurve == "Kurve" || TypeKurve == "Overgang") { if (Math.Abs(R1) < 1e6) { Δϴ = (L / R1 + L * L * c / 2); } else { Δϴ = L / R1 + L * L * c / 2;} } else { Δϴ = 0; }
            KL.sgn = Math.Abs(KL.R);
        }
        public double Calc_Pxi(double Xi)
        {
            Ri = 1 / (1 / R1 + c * Xi);
            ϴi = Xi / R1 + Xi * Xi * c / 2;
            if (TypeKurve == "Kurve" && Math.Abs(R1) <= 1e6) { Pxi = Pxo - Ri * Math.Sin(ϴ1 - ϴi); }
            else if (TypeKurve == "Overgang") 
            {
                double x_temp = Xi; double y_temp = -(c * Xi * Xi * Xi / 6 + Xi *Xi /(2 * R1));
                Pxi = Px1 + x_temp * Math.Cos(ϴ1) - y_temp * Math.Sin(ϴ1);
            }
            else if(TypeKurve == "Rett linje") { Pxi = Px1 + Math.Cos(ϴ1) * Xi; ϴi = ϴ1; }
            return Pxi;
        }
        public double Calc_Pyi(double Xi)
        {
            Ri = 1 / (1 / R1 + c * Xi);
            ϴi = Xi / R1 + Xi * Xi * c / 2;
            if (TypeKurve == "Kurve" && Math.Abs(Ri) <= 1e6) { Pyi = Pyo + Ri * Math.Cos(ϴ1 - ϴi); }
            else if (TypeKurve == "Overgang") 
            {
                double x_temp = Xi; double y_temp = -(c * Xi * Xi * Xi / 6 + Xi * Xi / (2 * R1));
                Pyi = Py1 + x_temp * Math.Sin(ϴ1) + y_temp * Math.Cos(ϴ1);
            }
            else if (TypeKurve == "Rett linje") { Pyi = Py1 + Math.Sin(ϴ1) * Xi; ϴi = ϴ1; }
            return Pyi;
        }
        public double Calc_Elxi(double Xi, double E)
        {
            Ri = 1 / (1 / R1 + c * Xi);
            ϴi = Xi / R1 + Xi * Xi * c / 2;
            if (TypeKurve == "Kurve" && Math.Abs(R1) <= 1e6) { Pxi = Pxo - (Ri + E) * Math.Sin(ϴ1 - ϴi); }
            else if (TypeKurve == "Overgang")
            {
                double x_temp = Xi; double y_temp = E - (c * Xi * Xi * Xi / 6 + Xi * Xi / (2 * (R1 + E)));
                Pxi = Px1 + x_temp * Math.Cos(ϴ1) - y_temp * Math.Sin(ϴ1);
            }
            else if (TypeKurve == "Rett linje") { Pxi = Px1 + Math.Cos(ϴ1) * Xi - E * Math.Sin(ϴ1); }
            return Pxi;
        }
        public double Calc_Elyi(double Xi, double E)
        {
            Ri = 1 / (1 / R1 + c * Xi);
            ϴi = Xi / R1 + Xi * Xi * c / 2;
            if (TypeKurve == "Kurve" && Math.Abs(Ri) <= 1e6) { Pyi = Pyo + (Ri + E) * Math.Cos(ϴ1 - ϴi); }
            else if (TypeKurve == "Overgang")
            {
                double x_temp = Xi; double y_temp = E - (c * Xi * Xi * Xi / 6 + Xi * Xi / (2 * (R1 + E)));
                Pyi = Py1 + x_temp * Math.Sin(ϴ1) + y_temp * Math.Cos(ϴ1);
            }
            else if (TypeKurve == "Rett linje") { Pyi = Py1 + Math.Sin(ϴ1) * Xi + E * Math.Cos(ϴ1); }
            return Pyi;
        }
        public double Calc_Erxi(double Xi, double E)
        {
            Ri = 1 / (1 / R1 + c * Xi);
            ϴi = Xi / R1 + Xi * Xi * c / 2;
            if (TypeKurve == "Kurve" && Math.Abs(R1) <= 1e6) { Pxi = Pxo - (Ri - E) * Math.Sin(ϴ1 - ϴi); }
            else if (TypeKurve == "Overgang")
            {
                double x_temp = Xi; double y_temp = -E - (c * Xi * Xi * Xi / 6 + Xi * Xi / (2 * (R1 - E)));
                Pxi = Px1 + x_temp * Math.Cos(ϴ1) - y_temp * Math.Sin(ϴ1);
            }
            else if (TypeKurve == "Rett linje") { Pxi = Px1 + Math.Cos(ϴ1) * Xi + E * Math.Sin(ϴ1); }
            return Pxi;
        }
        public double Calc_Eryi(double Xi, double E)
        {
            Ri = 1 / (1 / R1 + c * Xi);
            ϴi = Xi / R1 + Xi * Xi * c / 2;
            if (TypeKurve == "Kurve" && Math.Abs(R1) <= 1e6) { Pyi = Pyo + (Ri - E) * Math.Cos(ϴ1 - ϴi); }
            else if (TypeKurve == "Overgang")
            {
                double x_temp = Xi; double y_temp = -E - (c * Xi * Xi * Xi / 6 + Xi * Xi / (2 * (R1 - E)));
                Pyi = Py1 + x_temp * Math.Sin(ϴ1) + y_temp * Math.Cos(ϴ1);
            }
            else if (TypeKurve == "Rett linje") { Pyi = Py1 + Math.Sin(ϴ1) * Xi - E * Math.Cos(ϴ1); }
            return Pyi;
        }

        public double Calc_Δϴ(double Xi)
        {   double temp;
            if (TypeKurve == "Rett linje" || (Math.Abs(R1) >= 1e6 && Math.Abs(R2) >= 1e6)) { temp = 0; } else { temp =  (L - Xi) / R1 + (L * L - Xi * Xi) * c / 2;}
            return temp;
        }
        public double Calc_R(double Xi)
        { return 1 / (1 / R1 + c * Xi); }
    }
    public class LedPart
    {
        public int antall_spenn; public double max_lengde;
        public int max_antall_spenn; public double lengde;
        public double kortest_avstand; public KL_span[] Spenner;
        public Utligger[] utligger;
        public string løp; public double start;
        public double end; public double Δϴ;
        public double Δx; public double Δy;
        public int nr;
        public LedPart()
        {
            antall_spenn = 0; max_lengde = 750;
            max_antall_spenn = 12; lengde = 0;
            kortest_avstand = 0; Spenner = new KL_span[20]; utligger = new Utligger[21];
            for (int i = 0; i < 21; i++) 
            { 
                if (i < 20) { Spenner[i] = new KL_span(); }
                utligger[i] = new Utligger();
            }
            løp = "Fiks pkt. til lodd avs.";
            start = 0; end = 0;
            Δϴ = 0; Δx = 0; Δy = 0; nr = 0;
        }
        public object Clone() { return this.MemberwiseClone(); }
    }
    public class Plotter
    {
        double step;                 public int N;                       public double x;
        double[] spor_midt_x_all;    double[] spor_midt_y_all;
        double[] El_x_all;           double[] El_y_all;
        double[] Er_x_all;           double[] Er_y_all;
        double[] ec_x_all;           double[] ec_y_all;
        double[] el_x_all;           double[] el_y_all;
        double[] er_x_all;           double[] er_y_all;
        double[] ec2_x_all;          double[] ec2_y_all;
        double[] el2_x_all;          double[] el2_y_all;
        double[] er2_x_all;          double[] er2_y_all;    // Bare for avspennings felt
        public double[] temp;
        public double ϴ_eff;                public double L_eff;
        public double Δx_tot ;              public double Δy_tot;
        public double Delta_x; public double Delta_y;
        public Plotter()
        {
            step = 0.1; N = 0; x = 0;
            ϴ_eff = 0; Δx_tot = 0; Δy_tot = 0;
        }
        public void Orient(TraseLedd[] trase, int n, LedPart ledPart)
        {
            int i = 0; int q = 0; trase[0].ϴ1 = 0; Δx_tot = 0; Δy_tot = 0; N = 0; x = 0;  ϴ_eff = 0;

            for ( i = 0; ;)
            {
                if (i >= n ) { break; }
                trase[i].Δϴ = trase[i].Calc_Δϴ(0);
                trase[i].Px1 = Δx_tot;   trase[i].Py1 = Δy_tot;
                if (i > 0) { trase[i].ϴ1 = trase[i - 1].ϴ2; }
                trase[i].ϴ2 = trase[i].ϴ1 - trase[i].Δϴ;
                if (trase[i].TypeKurve == "Kurve")
                {
                    trase[i].ΔPx = ( trase[i].R1 * Math.Sin(trase[i].ϴ1) - trase[i].R2 * Math.Sin(trase[i].ϴ1 - trase[i].Δϴ));
                    trase[i].ΔPy = (-trase[i].R1 * Math.Cos(trase[i].ϴ1) + trase[i].R2 * Math.Cos(trase[i].ϴ1 - trase[i].Δϴ));
                    trase[i].Pxo = trase[i].Px1 + trase[i].R1 * Math.Sin(trase[i].ϴ1);
                    trase[i].Pyo = trase[i].Py1 - trase[i].R1 * Math.Cos(trase[i].ϴ1);
                }
                else if(trase[i].TypeKurve == "Overgang")
                {
                    double y_temp = -(2 / trase[i].R1 + 1 / trase[i].R2) * trase[i].L * trase[i].L / 6; 
                    trase[i].ΔPx = trase[i].L * Math.Cos(trase[i].ϴ1) - y_temp * Math.Sin(trase[i].ϴ1);
                    trase[i].ΔPy = trase[i].L * Math.Sin(trase[i].ϴ1) + y_temp * Math.Cos(trase[i].ϴ1);
                }
                else if (trase[i].TypeKurve == "Rett linje" || Math.Abs(trase[i].R1) > 1e6)
                {
                    trase[i].ΔPx = trase[i].L * Math.Cos(trase[i].ϴ1);
                    trase[i].ΔPy = trase[i].L * Math.Sin(trase[i].ϴ1);
                }
                Δx_tot = Δx_tot + trase[i].ΔPx;
                Δy_tot = Δy_tot + trase[i].ΔPy;
                trase[i].Px2 = Δx_tot; trase[i].Py2 = Δy_tot;
                i++;
            }
            for (q = 0; ; )
            {
                if (q >= ledPart.antall_spenn) { break; }
                for (i = 0; ;) { if (ledPart.Spenner[q].x1 >= trase[i].x2 || i >= n-1) { break; } i++; }
                ledPart.Spenner[q].Px1 = trase[i].Calc_Pxi(ledPart.Spenner[q].x1 - trase[i].x1); 
                ledPart.Spenner[q].Py1 = trase[i].Calc_Pyi(ledPart.Spenner[q].x1 - trase[i].x1); 
                for (i = 0; ;) { if (ledPart.Spenner[q].x2 >= trase[i].x2 || i >= n-1) { break; } i++; }
                ledPart.Spenner[q].Px2 = trase[i].Calc_Pxi(ledPart.Spenner[q].x2 - trase[i].x1); 
                ledPart.Spenner[q].Py2 = trase[i].Calc_Pyi(ledPart.Spenner[q].x2 - trase[i].x1); 
                q++;
            }

            Delta_x = trase[n - 1].Px2;
            Delta_y = trase[n - 1].Py2;
            ϴ_eff = Math.Atan2(Delta_y, Delta_x); 
            L_eff = Math.Sqrt(Delta_x * Delta_x + Delta_y * Delta_y);
            trase[0].ϴ1 = - ϴ_eff;  Δx_tot = 0; Δy_tot = 0; 
            for (i = 0; ; )
            {
                if (i >= n ) { break; }
                trase[i].Δϴ = trase[i].Calc_Δϴ(0);
                trase[i].Px1 = Δx_tot; trase[i].Py1 = Δy_tot;
                if (i > 0) { trase[i].ϴ1 = trase[i - 1].ϴ2; }
                trase[i].ϴ2 = trase[i].ϴ1 - trase[i].Δϴ;
                if (trase[i].TypeKurve == "Kurve")
                {
                    trase[i].ΔPx = (trase[i].R1 * Math.Sin(trase[i].ϴ1) - trase[i].R2 * Math.Sin(trase[i].ϴ1 - trase[i].Δϴ));
                    trase[i].ΔPy = (-trase[i].R1 * Math.Cos(trase[i].ϴ1) + trase[i].R2 * Math.Cos(trase[i].ϴ1 - trase[i].Δϴ));
                    trase[i].Pxo = trase[i].Px1 + trase[i].R1 * Math.Sin(trase[i].ϴ1);
                    trase[i].Pyo = trase[i].Py1 - trase[i].R1 * Math.Cos(trase[i].ϴ1);
                }
                else if (trase[i].TypeKurve == "Overgang")
                {
                    double y_temp = -(2 / trase[i].R1 + 1 / trase[i].R2) * trase[i].L * trase[i].L / 6;
                    trase[i].ΔPx = trase[i].L * Math.Cos(trase[i].ϴ1) - y_temp * Math.Sin(trase[i].ϴ1);
                    trase[i].ΔPy = trase[i].L * Math.Sin(trase[i].ϴ1) + y_temp * Math.Cos(trase[i].ϴ1);
                }
                else if (trase[i].TypeKurve == "Rett linje" ||  Math.Abs(trase[i].R1) > 1e6)
                {
                    trase[i].ΔPx = trase[i].L * Math.Cos(trase[i].ϴ1);
                    trase[i].ΔPy = trase[i].L * Math.Sin(trase[i].ϴ1);
                }
                Δx_tot = Δx_tot + trase[i].ΔPx;
                Δy_tot = Δy_tot + trase[i].ΔPy;
                trase[i].Px2 = Δx_tot; trase[i].Py2 = Δy_tot;
                i++;
            }
            for (q = 0; ; )
            {
                if (q >= ledPart.antall_spenn) { break; }
                for (i = 0; ;) { if (ledPart.Spenner[q].x1 <= trase[i].x2 || i >= n-1) { break; } i++; }
                ledPart.Spenner[q].Px1 = trase[i].Calc_Pxi(ledPart.Spenner[q].x1 - trase[i].x1); 
                ledPart.Spenner[q].Py1 = trase[i].Calc_Pyi(ledPart.Spenner[q].x1 - trase[i].x1); 
                for (i = 0; ;) { if (ledPart.Spenner[q].x2 <= trase[i].x2 || i >= n-1) { break; } i++; }
                ledPart.Spenner[q].Px2 = trase[i].Calc_Pxi(ledPart.Spenner[q].x2 - trase[i].x1); 
                ledPart.Spenner[q].Py2 = trase[i].Calc_Pyi(ledPart.Spenner[q].x2 - trase[i].x1);
                q++;
            }
        }
        public double[] Point_functions_ledpart(TraseLedd[] trase, LedPart ledPart, double x, double Xr, double Yr, double ϴr, VindUtblTabel VindUtb)
        {
            //Trase datapunkter (spormidt)
            int i = 0;                      int q = 0;
            double spor_midt_x;             double spor_midt_y;
            double El_x;                    double El_y;
            double Er_x;                    double Er_y;
            double ec_x;                    double ec_y;
            double el_x;                    double el_y;
            double er_x;                    double er_y;
            double ec2_y;                   double el2_y;           double er2_y;    // Bare for veksling/seksjonering
            KL_span KL;                     double x_loc;
            double ϴ_temp;
            double[] temp = new double[18];
            for ( i = 0; ;) { if (trase[i].x2 - trase[0].x1 >= x || i == trase.Length - 1) { break; } i++; }
            for (q = 0; ;) { if (ledPart.Spenner[q].x2 - trase[0].x1 >= x || q >= ledPart.antall_spenn - 1) { break; } q++; }
            KL = ledPart.Spenner[q];
            //Vundutblåsning datapunkter
            spor_midt_x = trase[i].Calc_Pxi(x - (trase[i].x1 - trase[0].x1));
            spor_midt_y = trase[i].Calc_Pyi(x - (trase[i].x1 - trase[0].x1));
            El_x = trase[i].Calc_Elxi(x - (trase[i].x1 - trase[0].x1), VindUtblTabel.Find_E(trase[i].Calc_R(x - (trase[i].x1 - trase[0].x1)), VindUtb));
            El_y = trase[i].Calc_Elyi(x - (trase[i].x1 - trase[0].x1), VindUtblTabel.Find_E(trase[i].Calc_R(x - (trase[i].x1 - trase[0].x1)), VindUtb));
            Er_x = trase[i].Calc_Erxi(x - (trase[i].x1 - trase[0].x1), VindUtblTabel.Find_E(trase[i].Calc_R(x - (trase[i].x1 - trase[0].x1)), VindUtb));
            Er_y = trase[i].Calc_Eryi(x - (trase[i].x1 - trase[0].x1), VindUtblTabel.Find_E(trase[i].Calc_R(x - (trase[i].x1 - trase[0].x1)), VindUtb));
            
            x_loc = x - (KL.x1 - trase[0].x1);
            ϴ_temp = Math.Atan2((KL.Py2 - KL.Py1), (KL.Px2 - KL.Px1));
            ec_x = x_loc; ec_y = -KL.b1 - x_loc * (KL.b2 - KL.b1) / KL.a;
            el_x = x_loc; el_y = -KL.b1 - x_loc * (KL.b2 - KL.b1) / KL.a + x_loc * (KL.a - x_loc) * (KL.Fw / KL.H) / 2;
            er_x = x_loc; er_y = -KL.b1 - x_loc * (KL.b2 - KL.b1) / KL.a - x_loc * (KL.a - x_loc) * (KL.Fw / KL.H) / 2;
            //double h; if(q < 4) { h = -1; } else { h = 1; }//Precedence of KL corrector
            //ec2_y = ec_y - KL.Kt_avst * h;         el2_y = el_y - KL.Kt_avst * h;         er2_y = er_y - KL.Kt_avst * h;
            //double h; if (q < 4) { h = -1; } else { h = 1; }//Precedence of KL corrector //&& (KL.SpennType == "Veksling" || KL.SpennType == "Seksjonering")
            if (ledPart.løp == "Lodd avs. til fiks pkt." && ledPart.nr > 0 ) 
            { ec2_y = ec_y + KL.Kt_avst * Math.Sign(KL.R); el2_y = el_y + KL.Kt_avst * Math.Sign(KL.R); er2_y = er_y + KL.Kt_avst * Math.Sign(KL.R); }
            else {ec2_y = ec_y - KL.Kt_avst * Math.Sign(KL.R); el2_y = el_y - KL.Kt_avst * Math.Sign(KL.R); er2_y = er_y - KL.Kt_avst * Math.Sign(KL.R); }
            

            //Rotere axen med KL.(Rotation about the start of KL)
            double ec_new_x = x_loc * Math.Cos(ϴ_temp) - ec_y * Math.Sin(ϴ_temp);
            double ec_new_y = x_loc * Math.Sin(ϴ_temp) + ec_y * Math.Cos(ϴ_temp);
            double el_new_x = x_loc * Math.Cos(ϴ_temp) - el_y * Math.Sin(ϴ_temp);
            double el_new_y = x_loc * Math.Sin(ϴ_temp) + el_y * Math.Cos(ϴ_temp);
            double er_new_x = x_loc * Math.Cos(ϴ_temp) - er_y * Math.Sin(ϴ_temp);
            double er_new_y = x_loc * Math.Sin(ϴ_temp) + er_y * Math.Cos(ϴ_temp);
            double ec2_new_x = x_loc * Math.Cos(ϴ_temp) - ec2_y * Math.Sin(ϴ_temp);
            double ec2_new_y = x_loc * Math.Sin(ϴ_temp) + ec2_y * Math.Cos(ϴ_temp);
            double el2_new_x = x_loc * Math.Cos(ϴ_temp) - el2_y * Math.Sin(ϴ_temp);
            double el2_new_y = x_loc * Math.Sin(ϴ_temp) + el2_y * Math.Cos(ϴ_temp);
            double er2_new_x = x_loc * Math.Cos(ϴ_temp) - er2_y * Math.Sin(ϴ_temp);
            double er2_new_y = x_loc * Math.Sin(ϴ_temp) + er2_y * Math.Cos(ϴ_temp);
            //Translation wrt the start of KL.
            ec_new_x = ec_new_x + KL.Px1;       ec_new_y = ec_new_y + KL.Py1;
            el_new_x = el_new_x + KL.Px1;       el_new_y = el_new_y + KL.Py1;
            er_new_x = er_new_x + KL.Px1;       er_new_y = er_new_y + KL.Py1;
            ec2_new_x = ec2_new_x + KL.Px1;     ec2_new_y = ec2_new_y + KL.Py1;
            el2_new_x = el2_new_x + KL.Px1;     el2_new_y = el2_new_y + KL.Py1;
            er2_new_x = er2_new_x + KL.Px1;     er2_new_y = er2_new_y + KL.Py1;
            //Assemble the point data coordinates
            temp[0] = spor_midt_x;          temp[1] = spor_midt_y;
            TransRotat(ref temp[0],ref temp[1], Xr, Yr, ϴr);
            temp[2] = El_x;                 temp[3] = El_y;
            TransRotat(ref temp[2], ref temp[3], Xr, Yr, ϴr);
            temp[4] = Er_x;                 temp[5] = Er_y;
            TransRotat(ref temp[4], ref temp[5], Xr, Yr, ϴr);
            temp[6] = ec_new_x;             temp[7] = ec_new_y;
            TransRotat(ref temp[6], ref temp[7], Xr, Yr, ϴr);
            temp[8] = el_new_x;             temp[9] = el_new_y;
            TransRotat(ref temp[8], ref temp[9], Xr, Yr, ϴr);
            temp[10] = er_new_x;            temp[11] = er_new_y;
            TransRotat(ref temp[10], ref temp[11], Xr, Yr, ϴr);

            if (ledPart.Spenner[q].SpennType != "Normal" && ledPart.Spenner[q].SpennType != "Fiks linje")
            {
                temp[12] = ec2_new_x;   temp[13] = ec2_new_y;
                TransRotat(ref temp[12], ref temp[13], Xr, Yr, ϴr);
                temp[14] = el2_new_x;   temp[15] = el2_new_y;
                TransRotat(ref temp[14], ref temp[15], Xr, Yr, ϴr);
                temp[16] = er2_new_x;   temp[17] = er2_new_y;
                TransRotat(ref temp[16], ref temp[17], Xr, Yr, ϴr);
            }
            return temp;
        }
        public void TransRotat(ref double Xi, ref double Yi, double Xr, double Yr, double ϴr)
        {
            double[] XY_temp = new double[2];
            XY_temp[0] = (Xi - Xr) * Math.Cos(ϴr) - (Yi - Yr) * Math.Sin(ϴr) + Xr;
            XY_temp[1] = (Xi - Xr) * Math.Sin(ϴr) + (Yi - Yr) * Math.Cos(ϴr) + Yr;
            Xi = XY_temp[0];            Yi = XY_temp[1];
        }
        public double[] Point_functions_trase(TraseLedd[] trase, int n, double x, double Xr, double Yr, double ϴr)
        {
            //Trase datapunkter (spormidt)
            int i = 0;
            double spor_midt_x;             double spor_midt_y;
            double[] temp = new double[2]; temp[0] = 0; temp[1] = 0;
            
            for ( i = 0; ;) { if (i >= n-1) { break; } else if (trase[i].x1 - trase[0].x1 <= x && x <= trase[i].x2 - trase[0].x1) { break; } i++; }
            if (i == n) { return temp; }
            //Vindutblåsning datapunkter
            spor_midt_x = trase[i].Calc_Pxi(x - (trase[i].x1 - trase[0].x1));
            spor_midt_y = trase[i].Calc_Pyi(x - (trase[i].x1 - trase[0].x1));
            //Assemble the point data coordinates
            temp[0] = spor_midt_x;          temp[1] = spor_midt_y;
            TransRotat(ref temp[0], ref temp[1], Xr, Yr, ϴr);
            return temp;
        }
        public void PlotCurves_ledpart(PlotView D, TraseLedd[] trase, LedPart ledPart, int j, int spenn_nr, VindUtblTabel VindUtb)
        {
            D.Model = new PlotModel { Title = String.Concat("Vind Utblåsnings Plot: ½Led.part fra ", Convert.ToString((int)ledPart.start)," til ", Convert.ToString((int)ledPart.end)) };
            //if (spenn_nr == 1 && ledPart.løp == "Lodd avs. til fiks pkt.") { D.Model.Title = String.Concat(D.Model.Title, "; Spenn ", Convert.ToString(spenn_nr + 1)); }
            //else if (spenn_nr == ledPart.antall_spenn - 1 && ledPart.løp == "Fiks pkt. til lodd avs.") { D.Model.Title = String.Concat(D.Model.Title, "; Spenn ", Convert.ToString(spenn_nr)); }
            if (spenn_nr == -1) { D.Model.Title = String.Concat(D.Model.Title, ", alle spenner "); }
            else { D.Model.Title = String.Concat(D.Model.Title, ", spenn nr. ", Convert.ToString(spenn_nr), " & ", Convert.ToString(spenn_nr+1)); }
            FunctionSeries spor_midt_series = new FunctionSeries();     spor_midt_series.Color = OxyColors.LightBlue;
            FunctionSeries El_series = new FunctionSeries();            El_series.Color = OxyColors.PaleVioletRed;
            FunctionSeries Er_series = new FunctionSeries();            Er_series.Color = OxyColors.PaleVioletRed;
            FunctionSeries ec_series = new FunctionSeries();            ec_series.Color = OxyColors.Black;
            FunctionSeries el_series = new FunctionSeries();            el_series.Color = OxyColors.LawnGreen;
            FunctionSeries er_series = new FunctionSeries();            er_series.Color = OxyColors.LawnGreen;
            FunctionSeries ec2_series = new FunctionSeries();           ec2_series.Color = OxyColors.Gray;
            FunctionSeries el2_series = new FunctionSeries();           el2_series.Color = OxyColors.LightGreen;
            FunctionSeries er2_series = new FunctionSeries();           er2_series.Color = OxyColors.LightGreen;
            step = 0.1;
            N = Convert.ToInt32((ledPart.Spenner[Math.Max(ledPart.antall_spenn - 1, 0)].x2 - trase[0].x1) / step);
            spor_midt_x_all = new double[N]; spor_midt_y_all = new double[N];
            El_x_all = new double[N];       El_y_all = new double[N];
            Er_x_all = new double[N];       Er_y_all = new double[N];
            ec_x_all = new double[N];       ec_y_all = new double[N];
            el_x_all = new double[N];       el_y_all = new double[N];
            er_x_all = new double[N];       er_y_all = new double[N];
            ec2_y_all = new double[N];      el2_y_all = new double[N];      er2_y_all = new double[N];// Bare for avspennings felt
            ec2_x_all = new double[N];      el2_x_all = new double[N];      er2_x_all = new double[N];
            temp = new double[18]; int g=0;
            double Xr; double Yr; double ϴr; 
            if (spenn_nr == -1) // Vis alle spenner i 1/2 ledpart
            {
                Xr = ledPart.Spenner[0].Px1; Yr = ledPart.Spenner[0].Py1;
                ϴr = Math.Atan2(ledPart.Spenner[ledPart.antall_spenn - 1].Py2 - ledPart.Spenner[0].Py1, ledPart.Spenner[ledPart.antall_spenn - 1].Px2 - ledPart.Spenner[0].Px1);
                x = 0;
                if (ledPart.løp == "Lodd avs. til fiks pkt.") { x = ledPart.Spenner[1].x1 - trase[0].x1; }
                else { x = ledPart.Spenner[01].x1 - trase[0].x1; }
            }
            else
            {
                Xr = ledPart.Spenner[spenn_nr - 1].Px1; Yr = ledPart.Spenner[spenn_nr - 1].Py1;
                ϴr = Math.Atan2(ledPart.Spenner[spenn_nr].Py2 - ledPart.Spenner[spenn_nr - 1].Py1, ledPart.Spenner[spenn_nr].Px2 - ledPart.Spenner[spenn_nr - 1].Px1);
                x = ledPart.Spenner[spenn_nr - 1].x1 - trase[0].x1;
            }
            for (int i = 1; x < ledPart.end - trase[0].x1; i++)
            {
                x = x + step;
                temp = Point_functions_ledpart(trase, ledPart, x, Xr, Yr, -ϴr, VindUtb);
                for (g = 0; ;) { if (ledPart.Spenner[g].x2 - trase[0].x1 >= x || g >= ledPart.antall_spenn - 1) { break; } g++; } //Locate the relevant span
                if (ledPart.Spenner[g].SpennType != "Avspenning" && ledPart.Spenner[g].SpennType != "Veksl_avspenning" && ledPart.Spenner[g].SpennType != "Seksj_avspenning" && 
                    ledPart.Spenner[g].SpennType != "Veksl_5Spn_avsp" && ledPart.Spenner[g].SpennType != "Seksj_5Spn_avsp")
                {
                    if (spenn_nr >= 1) { if (x >= ledPart.Spenner[spenn_nr].x2 - trase[0].x1) { break; } }//spenn_nr - 1
                    spor_midt_x_all[i] = temp[0] + trase[0].x1;   spor_midt_y_all[i] = temp[1] - Yr;
                    El_x_all[i] = temp[2] + trase[0].x1;          El_y_all[i] = temp[3] - Yr;
                    Er_x_all[i] = temp[4] + trase[0].x1;          Er_y_all[i] = temp[5] - Yr;
                    ec_x_all[i] = temp[6] + trase[0].x1;          ec_y_all[i] = temp[7] - Yr;
                    el_x_all[i] = temp[8] + trase[0].x1;          el_y_all[i] = temp[9] - Yr;
                    er_x_all[i] = temp[10] + trase[0].x1;         er_y_all[i] = temp[11] - Yr;
                    if (Math.Abs(ledPart.Spenner[g].b1 / 2 + ledPart.Spenner[g].b2 / 2) < 1)
                    {
                        spor_midt_series.Points.Add(new DataPoint(spor_midt_x_all[i], spor_midt_y_all[i]));
                        ec_series.Points.Add(new DataPoint(ec_x_all[i], ec_y_all[i]));
                        if (spenn_nr != -2 && spenn_nr != -3)  //??
                        {
                            El_series.Points.Add(new DataPoint(El_x_all[i], El_y_all[i]));
                            Er_series.Points.Add(new DataPoint(Er_x_all[i], Er_y_all[i]));
                            el_series.Points.Add(new DataPoint(el_x_all[i], el_y_all[i]));
                            er_series.Points.Add(new DataPoint(er_x_all[i], er_y_all[i]));
                        }
                    }
                }
                if (ledPart.Spenner[g].SpennType != "Fiks linje" && ledPart.Spenner[g].SpennType != "Normal" && ledPart.Spenner[g].SpennType != "Avspenning" 
                    && ledPart.Spenner[g].SpennType != "Veksl_avspenning" && ledPart.Spenner[g].SpennType != "Seksj_avspenning" &&
                    ledPart.Spenner[g].SpennType != "Veksl_5Spn_avsp" && ledPart.Spenner[g].SpennType != "Seksj_5Spn_avsp") //Datapunkter for andre KL i avspenningsfelt
                {
                    ec2_x_all[i] = temp[12] + trase[0].x1; ec2_y_all[i] = temp[13] - Yr;
                    el2_x_all[i] = temp[14] + trase[0].x1; el2_y_all[i] = temp[15] - Yr;
                    er2_x_all[i] = temp[16] + trase[0].x1; er2_y_all[i] = temp[17] - Yr;
                    if (spenn_nr != -2 && spenn_nr != -3)//??
                    {
                        ec2_series.Points.Add(new DataPoint(ec2_x_all[i], ec2_y_all[i]));
                        el2_series.Points.Add(new DataPoint(el2_x_all[i], el2_y_all[i]));
                        er2_series.Points.Add(new DataPoint(er2_x_all[i], er2_y_all[i]));
                    }
                }
            }
            D.Model.Series.Add(spor_midt_series);
            D.Model.Series.Add(El_series);
            D.Model.Series.Add(Er_series);
            D.Model.Series.Add(ec_series);
            D.Model.Series.Add(el_series);
            D.Model.Series.Add(er_series);
            D.Model.Series.Add(ec2_series);
            D.Model.Series.Add(el2_series);
            D.Model.Series.Add(er2_series);
        }
        public void PlotCurves_trase(PlotView D, TraseLedd[] trase, LedPart ledPart, int n)
        {
            D.Model = new PlotModel { Title = String.Concat("Trasens Plot fra ", Convert.ToString(trase[0].x1), " til ", Convert.ToString(trase[n-1].x2)) };
            FunctionSeries spor_midt_series = new FunctionSeries();
            step = 0.1;
            N = Convert.ToInt32((trase[n - 1].x2 - trase[0].x1) / step) + 1;//
            spor_midt_x_all = new double[N]; spor_midt_y_all = new double[N];
            temp = new double[2];
            double Xr; double Yr; double ϴr;
            Xr = 0; Yr = 0; ϴr = 0;  // (Xr,Yr) Start punkt og start referanse til traseplot
            x = 0 * trase[0].x1;
            for (int i = 0; i < N; i++)
            {
                temp = Point_functions_trase(trase, n, x, Xr, Yr, -ϴr);
                spor_midt_x_all[i] = temp[0] + trase[0].x1; spor_midt_y_all[i] = temp[1];
                spor_midt_series.Points.Add(new DataPoint(spor_midt_x_all[i], spor_midt_y_all[i]));
                x = x + step;
            }
            D.Model.Series.Add(spor_midt_series);
        }
    }
    public class Utligger
    {
        public double L1;       public double L2;   // Spennlengder
        public double ϴT;       //Tangentvinkel
        public double ϴ1;       public double ϴ2;   // Spennlengde vinkel
        public double Δϴ1;       public double Δϴ2; // Vende vinkel i hver spennlengde
        public double T1;       public double T2;   // Strekkkraft i spennlengder
        public double b;        public double Lu;   //Zigzak og utliggerens lengde
        public double Fd;       //Normal strekkkraft på utliggeren
        public double Fv;       //KL vektkraft på utliggeren
        public double Fw;       //Vinklerett KL vindkraft på utliggeren
        public double Fx; public double Fy; public double Fz; public double Mx; //Utligger last
        public double Px1;          public double Py1; // Spormidt koordinat
        public double Pxd;          public double Pyd; // KL festepunkt koordinat (zigzakens posisjon)
        public double Pxm;          public double Pym; // Mastens koordinat
        //Varibler for termisk forskyvning
        public double dL1;      public double dL2;   // Spennlengder
        public double dϴ1;      public double dϴ2;   // Spennlengde vinkel
        public double dT1;      public double dT2;   // Strekkkraft i spennlengder
        public Utligger()
        {
            L1 = 65; L2 = 65;
            ϴ1 = 0; ϴ2 = 0; ϴT = 0;
            Δϴ1 = 0; Δϴ2 = 0;
            T1 = 10e4; T2 = 10e4;
            b = -0.3; Lu = 3.5;
            Fd = 0; Fv = 0; Fw = 0; dL1 = 0; dL2 = 0; dϴ1 = 0; dϴ2 = 0; dT1 = 0; dT2 = 0;
            Fx = 0; Fy = 0; Fz = 0; Mx = 0;
        }
        public void Pxy_Calc()
        {
            Pxd = Px1 - b * Math.Sin(ϴT); Pyd = Py1 - b * Math.Cos(ϴT);
            Pxm = Px1 - Lu * Math.Sin(ϴT); Pym = Py1 - Lu * Math.Cos(ϴT);
        }
        public double Fd_Calc()
        {
            return Fd;
        }
        public void Last_Calc()
        {
            //;
        }
    }
    public class Mast
    {
        public double Px1;      public double Py1; // Spormidt koordinat
        public double Pxd;      public double Pyd; // KL festepunkt koordinat (zigzakens posisjon)
        public double Pxm;      public double Pym; // Mastens koordinat
        public double sgn;      // Mastens plassering ift spormidt
        public double Lu;       public double ϴT;
        public void Pxy_Calc()
        {
            Pxm = Px1 + Lu * Math.Sin(ϴT); Pym = Py1 + Lu * Math.Cos(ϴT);
        }
    }
}
